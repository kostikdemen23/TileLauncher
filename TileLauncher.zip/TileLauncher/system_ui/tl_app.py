#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Главное приложение App: экраны, навбар, цикл."""
from __future__ import annotations

import sys
import time
import traceback
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pygame

from tl_core import *
from tl_keyboard import VirtualKeyboard, read_clipboard
from tl_widgets import (
    BaseScreen, ConfirmDialog, TextInput, TouchButton, ScrollList,
)
from tl_home import TileScreen, Tile, TileSize, TileGroup
from tl_files import (
    RunScreen, FileExplorerScreen, ViewerScreen, ImageScreen,
    GalleryScreen, EditorScreen, ConsoleScreen, LogsScreen,
)
from tl_time import TimeScreen
from tl_music import MusicScreen
from tl_system import (
    RecentScreen, FolderScreen, PluginHostScreen, MarketScreen,
    WallpaperScreen, ScreenSettingsScreen, AppsManageScreen,
    SettingsScreen, InfoScreen, AboutScreen, EnvScreen, ReadmeScreen,
)

class App:
    def __init__(self) -> None:
        pygame.init()

        size = None
        try:
            info = pygame.display.Info()
            cw = getattr(info, "current_w", 0) or 0
            ch = getattr(info, "current_h", 0) or 0
            if cw >= 200 and ch >= 200:
                size = (cw, ch)
        except Exception:
            pass

        if size is None:
            size = (480, 800)

        pygame.display.set_caption(f"{APP_NAME} {APP_VERSION}")

        screen_ok = False
        for try_size in [size, (720, 1280), (480, 800), (400, 600)]:
            try:
                self.screen = pygame.display.set_mode(try_size)
                screen_ok = True
                break
            except Exception:
                continue

        if not screen_ok:
            print("Не удалось создать окно pygame")
            sys.exit(1)

        # Android/Pydroid: сразу запрет soft-input
        try:
            pygame.key.stop_text_input()
        except Exception:
            pass
        try:
            self.force_hide_keyboard()
        except Exception:
            pass

        self.clock = pygame.time.Clock()
        self._font_cache: Dict[Tuple[str, int, bool], pygame.font.Font] = {}

        self._fps_last_update = 0.0
        self._fps_display = 0

        self.settings = Settings(SETTINGS_FILE)
        apply_theme(self.settings.get("theme", "dark"))
        self.vk = VirtualKeyboard()
        self.vk.app = self
        self.text_focus: Optional[Any] = None
        self.last_run_script: Optional[Path] = TARGET_SCRIPT

        self.recent_screens: List[Tuple[str, str]] = []
        self.max_recent = 10
        self.screen_history: List[str] = []  # стек для кнопки «назад»
        self._nav_swipe_y: Optional[int] = None
        self.shade_open = False

        self.dialog: Optional[ConfirmDialog] = None

        self.tile_screen = TileScreen(self)
        self.run_screen = RunScreen(self)
        self.explorer_screen = FileExplorerScreen(self)
        self.viewer_screen = ViewerScreen(self)
        self.image_screen = ImageScreen(self)
        self.gallery_screen = GalleryScreen(self)
        self.editor_screen = EditorScreen(self)
        self.console_screen = ConsoleScreen(self)
        self.logs_screen = LogsScreen(self)
        self.settings_screen = SettingsScreen(self)
        self.apps_screen = AppsManageScreen(self)
        self.market_screen = MarketScreen(self)
        self.plugin_host = PluginHostScreen(self)
        self.folder_screen = FolderScreen(self)
        self.wallpaper_screen = WallpaperScreen(self)
        self.screen_settings_screen = ScreenSettingsScreen(self)
        self.info_screen = InfoScreen(self)
        self.about_screen = AboutScreen(self)
        self.env_screen = EnvScreen(self)
        self.readme_screen = ReadmeScreen(self)
        self.time_screen = TimeScreen(self)
        self.music_screen = MusicScreen(self)
        self.recent_screen = RecentScreen(self)

        self.screens = {
            "menu": self.tile_screen,
            "run": self.run_screen,
            "explorer": self.explorer_screen,
            "viewer": self.viewer_screen,
            "image": self.image_screen,
            "gallery": self.gallery_screen,
            "editor": self.editor_screen,
            "console": self.console_screen,
            "logs": self.logs_screen,
            "settings": self.settings_screen,
            "apps": self.apps_screen,
            "market": self.market_screen,
            "plugin": self.plugin_host,
            "folder": self.folder_screen,
            "wallpaper": self.wallpaper_screen,
            "screen": self.screen_settings_screen,
            "info": self.info_screen,
            "about": self.about_screen,
            "env": self.env_screen,
            "readme": self.readme_screen,
            "time": self.time_screen,
            "music": self.music_screen,
            "recent": self.recent_screen,
        }

        self.current_screen = "menu"
        self.running = True
        self.show_toast: Optional[Tuple[str, float, Tuple[int, int, int]]] = None
        self._needs_redraw = True
        self._system_input_active = False

        if self.settings.get("android_auto", False):
            try:
                self._set_orientation(landscape=True)
            except Exception:
                pass

        LOG.info("APP", f"Запуск {APP_NAME} {APP_VERSION}")

    # ------------------------------------------------------------------ #
    SCREEN_LABELS = {
        "menu": "Главное меню",
        "run": "Выполнение",
        "explorer": "Проводник",
        "viewer": "Просмотр",
        "image": "Изображение",
        "gallery": "Галерея",
        "editor": "Python 3.13",
        "console": "Консоль",
        "logs": "Логи",
        "settings": "Настройки",
        "apps": "Приложения",
        "wallpaper": "Обои",
        "screen": "Экран",
        "info": "Сведения",
        "about": "О программе",
        "env": "Проверка окружения",
        "readme": "README",
        "time": "Время",
        "music": "Музыка",
        "market": "Tile market",
        "plugin": "Плагин",
        "folder": "Папка",
        "recent": "Недавние",
    }

    def _record_recent(self, name: str) -> None:
        # Главный экран и служебные не считаются «приложением»
        if name in ("recent", "menu", "info"):
            return
        label = self.SCREEN_LABELS.get(name, name)
        self.recent_screens = [
            (n, l) for (n, l) in self.recent_screens if n != name
        ]
        self.recent_screens.insert(0, (name, label))
        if len(self.recent_screens) > self.max_recent:
            self.recent_screens = self.recent_screens[:self.max_recent]

    # ------------------------------------------------------------------ #
    def set_text_focus(self, target: Any) -> None:
        self.text_focus = target
        self.vk.show()
        # Системную клавиатуру Android НЕ открываем (Pydroid)
        # только встроенная VirtualKeyboard
        self._stop_system_input()
        try:
            pygame.key.stop_text_input()
        except Exception:
            pass
        self._needs_redraw = True

    def clear_text_focus(self) -> None:
        self.text_focus = None
        try:
            self.vk.hide()
        except Exception:
            pass
        self._stop_system_input()
        # принудительно ещё раз (Pydroid иногда игнорирует первый вызов)
        try:
            pygame.key.stop_text_input()
        except Exception:
            pass
        self._system_input_active = False
        self._needs_redraw = True

    def _start_system_input(self) -> None:
        # намеренно пусто: start_text_input открывает системную клавиатуру
        self._system_input_active = False
        try:
            pygame.key.stop_text_input()
        except Exception:
            pass

    def _stop_system_input(self) -> None:
        self.force_hide_keyboard()

    def _android_activity(self):
        """Текущая Android Activity (Pydroid / SDL / Kivy)."""
        try:
            from jnius import autoclass
        except Exception:
            return None
        candidates = (
            "org.libsdl.app.SDLActivity",
            "org.kivy.android.PythonActivity",
            "org.renpy.android.PythonActivity",
            "ru.iiec.pydroid3.PyDroid",
            "ru.iiec.pydroid3.MainActivity",
        )
        for name in candidates:
            try:
                cls = autoclass(name)
                for attr in ("mSingleton", "mActivity", "activity"):
                    act = getattr(cls, attr, None)
                    if act is not None:
                        return act
            except Exception:
                continue
        try:
            from jnius import autoclass
            AT = autoclass("android.app.ActivityThread")
            return AT.currentApplication()
        except Exception:
            return None

    def force_hide_keyboard(self) -> None:
        """Принудительно скрыть системную клавиатуру."""
        self._system_input_active = False
        for _ in range(3):
            try:
                pygame.key.stop_text_input()
            except Exception:
                pass
        try:
            if hasattr(self, "vk") and self.vk is not None and self.text_focus is None:
                self.vk.hide()
        except Exception:
            pass
        # Главное: режим окна Android — клавиатура всегда скрыта
        try:
            from jnius import autoclass
            activity = self._android_activity()
            if activity is None:
                return
            # SOFT_INPUT_STATE_ALWAYS_HIDDEN = 3
            # SOFT_INPUT_ADJUST_NOTHING = 48 (0x30)
            mode = 3 | 48
            try:
                window = activity.getWindow()
                window.setSoftInputMode(mode)
            except Exception:
                pass
            try:
                Context = autoclass("android.content.Context")
                imm = activity.getSystemService(Context.INPUT_METHOD_SERVICE)
                view = activity.getWindow().getDecorView()
                token = view.getWindowToken()
                # 0 = hide, HIDE_IMPLICIT_ONLY=1, HIDE_NOT_ALWAYS=2
                imm.hideSoftInputFromWindow(token, 0)
                imm.hideSoftInputFromWindow(token, 2)
                view.clearFocus()
            except Exception:
                pass
            try:
                # убрать фокус с decor view
                activity.getWindow().getDecorView().setFocusable(False)
                activity.getWindow().getDecorView().setFocusableInTouchMode(False)
            except Exception:
                pass
        except Exception:
            pass

    # ------------------------------------------------------------------ #
    def font(self, kind: str, size: int, bold: bool = False) -> pygame.font.Font:
        key = (kind, size, bold)
        cached = self._font_cache.get(key)
        if cached is not None:
            return cached

        if kind == "mono":
            names = ["DejaVu Sans Mono", "Droid Sans Mono", "Roboto Mono",
                     "Courier New", "Consolas"]
        else:
            names = ["Roboto", "Droid Sans", "DejaVu Sans", "Arial"]

        f = None
        for name in names:
            try:
                f = pygame.font.SysFont(name, size, bold=bold)
                if f:
                    break
            except Exception:
                continue
        if f is None:
            f = pygame.font.Font(None, size)
        self._font_cache[key] = f
        return f

    def _set_orientation(self, landscape: bool) -> None:
        """Переключение портрет / альбом (Android Auto)."""
        try:
            info = pygame.display.Info()
            cw = getattr(info, "current_w", 0) or 0
            ch = getattr(info, "current_h", 0) or 0
        except Exception:
            cw, ch = self.screen.get_size()
        if cw < 200 or ch < 200:
            cw, ch = self.screen.get_size()
        a, b = max(cw, ch), min(cw, ch)
        size = (a, b) if landscape else (b, a)
        try:
            self.screen = pygame.display.set_mode(size)
        except Exception:
            try:
                self.screen = pygame.display.set_mode(size, pygame.RESIZABLE)
            except Exception as e:
                LOG.error("UI", f"orientation: {e}")
                return
        self._font_cache.clear()
        if hasattr(self, "tile_screen"):
            try:
                self.tile_screen._bg_surface = None
                self.tile_screen.rebuild()
            except Exception:
                pass
        if hasattr(self, "screens"):
            for scr in self.screens.values():
                if hasattr(scr, "on_resize"):
                    try:
                        scr.on_resize()
                    except Exception:
                        pass
        self._needs_redraw = True

    def apply_android_auto(self, enabled: bool) -> None:
        """Режим Android Auto: альбомная ориентация и широкая сетка."""
        self.settings.set("android_auto", bool(enabled))
        self._set_orientation(landscape=bool(enabled))
        if enabled:
            # удобнее для авто: больше столбцов
            try:
                self.settings.set("grid_cols", 6)
            except Exception:
                pass
            self.toast("Android Auto: альбомный режим", SUCCESS)
        else:
            self.toast("Обычный режим", ACCENT)
        try:
            self.tile_screen.rebuild()
        except Exception:
            pass
        self._needs_redraw = True

    def show_screen(self, name: str, *, record_history: bool = True) -> None:
        try:
            self.clear_text_focus()
            self.force_hide_keyboard()
        except Exception:
            pass
        if name not in self.screens:
            return
        prev = getattr(self, "current_screen", None)
        if (record_history and prev and prev != name
                and prev not in ("recent",)
                and name != "recent"):
            hist = getattr(self, "screen_history", None)
            if hist is None:
                self.screen_history = []
            if not self.screen_history or self.screen_history[-1] != prev:
                self.screen_history.append(prev)
            if len(self.screen_history) > 30:
                self.screen_history = self.screen_history[-30:]
        self.current_screen = name
        if name not in ("editor", "console", "explorer", "settings", "run"):
            self.clear_text_focus()
        if name == "settings":
            self.settings_screen._build_items()
        if name != "recent":
            self._record_recent(name)
        self._needs_redraw = True

    def back_to_menu(self) -> None:
        self.show_screen("menu")

    def current(self) -> BaseScreen:
        return self.screens[self.current_screen]

    def toast(self, message: str, color: Tuple[int, int, int] = ACCENT,
              duration: float = 2.0) -> None:
        self.show_toast = (message, time.time() + duration, color)
        self._needs_redraw = True

    # ------------------------------------------------------------------ #
    def _nav_rects(self) -> Dict[str, pygame.Rect]:
        w, h = self.screen.get_size()
        top = h - NAV_BAR_H
        third = w // 3
        return {
            "back": pygame.Rect(0, top, third, NAV_BAR_H),
            "home": pygame.Rect(third, top, third, NAV_BAR_H),
            "recent": pygame.Rect(2 * third, top, w - 2 * third, NAV_BAR_H),
        }

    def _draw_nav_bar(self) -> None:
        w, h = self.screen.get_size()
        rects = self._nav_rects()
        bar_y = h - NAV_BAR_H

        bar_surf = pygame.Surface((w, NAV_BAR_H), pygame.SRCALPHA)
        bar_surf.fill((0, 0, 0, 190))
        self.screen.blit(bar_surf, (0, bar_y))

        pygame.draw.line(self.screen, (70, 80, 100),
                         (0, bar_y), (w, bar_y), 1)

        size = 20

        cx, cy = rects["back"].center
        pts = [
            (cx + size // 2, cy - size),
            (cx + size // 2, cy + size),
            (cx - size, cy),
        ]
        pygame.draw.polygon(self.screen, NAV_ICON, pts, 3)

        cx, cy = rects["home"].center
        pygame.draw.circle(self.screen, NAV_ICON, (cx, cy), size, 3)

        cx, cy = rects["recent"].center
        half = size - 2
        pygame.draw.rect(self.screen, NAV_ICON,
                         pygame.Rect(cx - half, cy - half,
                                     half * 2, half * 2), 3)

        self._draw_fps_indicator()

    def is_developer_mode(self) -> bool:
        return bool(self.settings.get("developer_mode", False))

    def _draw_fps_indicator(self) -> None:
        now = time.time()
        if now - self._fps_last_update >= 0.5:
            self._fps_last_update = now
            try:
                self._fps_display = int(self.clock.get_fps())
            except Exception:
                self._fps_display = 0
            # авто Dev-режим при USB
            if self.settings.get("dev_auto_usb", True):
                usb = read_usb_connected()
                prev = getattr(self, "_usb_was", None)
                self._usb_was = usb
                if usb and not self.settings.get("developer_mode", False):
                    self.settings.set("developer_mode", True)
                    self.toast("USB → режим разработчика", ACCENT)

        fps = self._fps_display
        w, h = self.screen.get_size()

        if fps >= 40:
            color = (150, 220, 150)
        elif fps >= 24:
            color = (220, 210, 140)
        else:
            color = (220, 140, 140)

        font = self.font("mono", 11, bold=True)
        if self.is_developer_mode():
            ch = read_charge_status()
            usb = "USB" if read_usb_connected() else "—"
            bat = read_battery_percent()
            bat_s = f"{bat}%" if bat is not None else "?"
            text = f"DEV  FPS:{fps}  {bat_s}  {ch[:8]}  {usb}"
            color = (120, 200, 255)
        else:
            text = f"FPS: {fps}"
        surf = font.render(text, True, color)

        pad_x = 10
        pad_y = 6
        x = w - surf.get_width() - pad_x
        y = h - NAV_BAR_H - surf.get_height() - pad_y

        bg = pygame.Surface((surf.get_width() + 12,
                             surf.get_height() + 6), pygame.SRCALPHA)
        bg.fill((0, 0, 0, 170))
        self.screen.blit(bg, (x - 6, y - 3))
        self.screen.blit(surf, (x, y))

    def _handle_nav_tap(self, pos: Tuple[int, int]) -> bool:
        rects = self._nav_rects()
        if rects["back"].collidepoint(pos):
            self._nav_back()
            return True
        if rects["home"].collidepoint(pos):
            self.show_screen("menu")
            return True
        if rects["recent"].collidepoint(pos):
            self.show_screen("recent")
            return True
        return False

    def _nav_bar_contains(self, pos: Tuple[int, int]) -> bool:
        w, h = self.screen.get_size()
        return pos[1] >= h - NAV_BAR_H

    def _nav_back(self) -> None:
        """Треугольник: одно действие назад по стеку экранов."""
        if self.dialog and self.dialog.active:
            self.dialog.active = False
            self.dialog = None
            self._needs_redraw = True
            return
        if self.current_screen == "menu":
            self.request_quit()
            return
        # плагины / вложенные экраны — сначала в меню или предыдущий
        hist = getattr(self, "screen_history", None) or []
        while hist:
            prev = hist.pop()
            if prev == self.current_screen:
                continue
            if prev in self.screens:
                self.show_screen(prev, record_history=False)
                return
        # стек пуст — на рабочий стол
        self.show_screen("menu", record_history=False)

    # ------------------------------------------------------------------ #
    def request_quit(self) -> None:
        if self.settings.get("confirm_exit", True):
            self.dialog = ConfirmDialog(
                self,
                "Выход",
                "Вы действительно хотите закрыть приложение?\n"
                "Несохранённые данные будут потеряны.",
                self._do_quit,
            )
        else:
            self._do_quit()

    def _do_quit(self) -> None:
        self.dialog = None
        self.running = False

    # ------------------------------------------------------------------ #
    def on_open_editor(self) -> None:
        empty = True
        if TARGET_SCRIPT.exists():
            try:
                content = TARGET_SCRIPT.read_text(encoding="utf-8").strip()
                empty = not content
            except Exception:
                empty = True
        if TARGET_SCRIPT.exists() and not empty:
            self.editor_screen.open_file(TARGET_SCRIPT)
            self.show_screen("editor")
            return
        # пустой или нет файла — диалог
        def create_new():
            self.editor_screen.path = TARGET_SCRIPT
            self.editor_screen.lines = [
                "# Новый скрипт",
                "print('Hello, TILE OS!')",
                "",
            ]
            self.editor_screen.cursor_x = 0
            self.editor_screen.cursor_y = 0
            self.editor_screen.dirty = True
            self.editor_screen.status = "target.py (новый)"
            self.show_screen("editor")

        def open_other():
            self.explorer_screen.cwd = PROJECT_DIR
            self.explorer_screen.refresh()
            self.show_screen("explorer")
            self.toast("Выберите .py файл", ACCENT)

        self.dialog = ConfirmDialog(
            self,
            "Python 3.13",
            "target.py пуст или отсутствует.\n"
            "Создать новый файл?\n"
            "(Нет — открыть другой .py)",
            create_new,
        )
        # при «Нет» — open_other через no... ConfirmDialog only has yes action
        # сохраняем callback для no
        original_no = None

        def handle_yes():
            create_new()

        self.dialog = ConfirmDialog(
            self, "Python 3.13",
            "target.py пуст или отсутствует.\nСоздать новый?",
            handle_yes,
        )
        # Подменяем обработку «Нет» — после закрытия диалога откроем проводник
        _old_handle = self.dialog.handle_event

        def _handle(event):
            if not self.dialog or not self.dialog.active:
                return False
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                for key, rect in self.dialog.btn_rects.items():
                    if rect.collidepoint(event.pos):
                        if key == "yes":
                            self.dialog.active = False
                            handle_yes()
                            return True
                        if key == "no":
                            self.dialog.active = False
                            open_other()
                            return True
            return _old_handle(event)

        self.dialog.handle_event = _handle  # type: ignore

    def on_open_folder(self) -> None:
        self.show_screen("explorer")

    def on_open_documents(self) -> None:
        if ANDROID_DOCUMENTS.exists():
            self.explorer_screen.cwd = ANDROID_DOCUMENTS
        else:
            self.explorer_screen.cwd = PROJECT_DIR
        self.explorer_screen.refresh()
        self.show_screen("explorer")

    def on_open_downloads(self) -> None:
        if ANDROID_DOWNLOADS.exists():
            self.explorer_screen.cwd = ANDROID_DOWNLOADS
        else:
            self.explorer_screen.cwd = PROJECT_DIR
        self.explorer_screen.refresh()
        self.show_screen("explorer")

    def on_open_console(self) -> None:
        self.show_screen("console")
        self.console_screen.input.focus()

    def on_show_logs(self) -> None:
        self.show_screen("logs")

    def on_settings(self) -> None:
        self.show_screen("settings")

    def on_about(self) -> None:
        self.show_screen("about")

    def on_check_env(self) -> None:
        self.show_screen("env")

    def on_open_readme(self) -> None:
        self.show_screen("readme")

    def on_open_time(self) -> None:
        self.show_screen("time")

    def on_open_market(self) -> None:
        self.market_screen.refresh()
        self.show_screen("market")

    def open_folder(self, tag: str) -> None:
        self.folder_screen.open_folder(tag)
        self.show_screen("folder")

    def launch_market_app(self, path: str) -> None:
        """Запуск .py из маркета: плагин (UI лаунчера) или subprocess."""
        p = Path(path).expanduser()
        try:
            p = p.resolve()
        except Exception:
            pass
        if not p.exists():
            alt = MARKET_DIR / Path(path).name
            if alt.exists():
                p = alt
            else:
                self.toast(f"Файл не найден: {p.name}", ERROR)
                LOG.error("MARKET", f"missing: {path}")
                return
        if p.suffix.lower() != ".py":
            self.viewer_screen.open(p)
            self.show_screen("viewer")
            return

        # 1) Плагин уровня лаунчера — без Python-в-Python
        if is_plugin_script(p):
            ok = self.plugin_host.load(p)
            if ok:
                self.show_screen("plugin")
                self.toast(getattr(self.plugin_host.plugin, "title", p.stem), SUCCESS)
                return
            self.toast("Плагин не загрузился — консольный запуск", WARNING)

        # 2) Обычный скрипт — консоль RunScreen
        if file_uses_pygame_display(p) and not is_plugin_script(p):
            self.toast(
                "Свой pygame-окна нет: сделайте create_plugin() или консоль",
                WARNING, 3.5)
        self.run_screen.start(p)
        self.show_screen("run")
        LOG.info("MARKET", f"Запуск → {p}")

    def on_open_music(self) -> None:
        self.show_screen("music")

    def on_open_gallery(self) -> None:
        self.gallery_screen.open_gallery()
        self.show_screen("gallery")

    def on_quit(self) -> None:
        self.request_quit()

    # ------------------------------------------------------------------ #
    def handle_events(self) -> None:
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                self.request_quit()
                continue

            if self.dialog and self.dialog.active:
                if self.dialog.handle_event(event):
                    self._needs_redraw = True
                    continue

            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                # жест свайпа только если НЕ нажали на кнопку навбара
                self._nav_btn_pressed = False
                if self._nav_bar_contains(event.pos):
                    rects = self._nav_rects()
                    hit_btn = any(r.collidepoint(event.pos)
                                  for r in rects.values())
                    if hit_btn:
                        self._nav_btn_pressed = True
                        self._nav_swipe_y = None
                    else:
                        self._nav_swipe_y = event.pos[1]
                if self.shade_open and event.pos[1] > self.screen.get_height() // 3:
                    self.shade_open = False
                    self._needs_redraw = True
                if self._handle_nav_tap(event.pos):
                    self._nav_btn_pressed = True
                    self._nav_swipe_y = None
                    self._needs_redraw = True
                    continue

            if event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                if getattr(self, "_nav_btn_pressed", False):
                    self._nav_btn_pressed = False
                    self._nav_swipe_y = None
                    # не открывать «недавние» после нажатия треугольника/круга
                    continue
                if self._nav_swipe_y is not None:
                    dy = event.pos[1] - self._nav_swipe_y
                    self._nav_swipe_y = None
                    if dy < -40:
                        self.show_screen("recent")
                        self._needs_redraw = True
                        continue
                    if dy > 40:
                        self.shade_open = True
                        self._needs_redraw = True
                        continue

            if self.vk.visible and self.vk.handle_event(event):
                self._needs_redraw = True
                continue

            if event.type == pygame.TEXTINPUT:
                if self.text_focus is not None:
                    if hasattr(self.text_focus, "apply_text_input"):
                        self.text_focus.apply_text_input(event.text)
                    else:
                        cur = self.current()
                        if hasattr(cur, "apply_text_input"):
                            cur.apply_text_input(event.text)
                    self._needs_redraw = True
                continue
            if event.type == pygame.TEXTEDITING:
                continue

            # Backspace с системной/экранной клавиатуры
            if event.type == pygame.KEYDOWN and event.key == pygame.K_BACKSPACE:
                if self.text_focus is not None and hasattr(self.text_focus, "backspace"):
                    try:
                        self.text_focus.backspace()
                        self._needs_redraw = True
                        continue
                    except Exception:
                        pass

            try:
                self.current().handle_event(event)
            except Exception as e:
                dbg(f"handle_event error в {self.current_screen}:", e)
                LOG.error("UI", f"handle_event {self.current_screen}: {e}")

            self._needs_redraw = True

    def update(self, dt: float) -> None:
        try:
            self.current().update(dt)
        except Exception:
            pass
        if self.current_screen in ("editor", "run", "time", "menu",
                                   "music", "recent", "settings",
                                   "viewer"):
            self._needs_redraw = True

    def draw(self) -> None:
        try:
            self.current().draw(self.screen)
            if self.vk.visible:
                self.vk.draw(self.screen)
            self._draw_nav_bar()
            if self.shade_open:
                self._draw_shade()

            if self.dialog:
                self.dialog.draw(self.screen)

            self._draw_toast()
            pygame.display.flip()
        except Exception:
            traceback.print_exc()
            LOG.error("UI", traceback.format_exc())
        self._needs_redraw = False

    def _draw_shade(self) -> None:
        """Шторка уведомлений (свайп вниз по навбару)."""
        w, h = self.screen.get_size()
        sh = h // 3
        panel = pygame.Surface((w, sh), pygame.SRCALPHA)
        panel.fill((20, 24, 32, 230))
        self.screen.blit(panel, (0, 0))
        pygame.draw.line(self.screen, PANEL_BORDER, (0, sh), (w, sh), 1)
        font = self.font("ui", 16, bold=True)
        self.screen.blit(font.render("Шторка", True, TEXT_BRIGHT), (16, 16))
        small = self.font("ui", 13)
        bat = read_battery_percent()
        city = read_weather_cache()
        lines = [
            datetime.datetime.now().strftime("%H:%M:%S  %d.%m.%Y"),
            f"Батарея: {bat}%" if bat is not None else "Батарея: н/д",
            f"Регион погоды: {city}" if city else "Погода: откройте weather в маркете",
            "Свайп вверх по навбару — недавние",
            "Тап ниже — закрыть",
        ]
        y = 50
        for line in lines:
            self.screen.blit(small.render(line, True, TEXT_DIM), (16, y))
            y += 26

    def _draw_toast(self) -> None:
        if not self.show_toast:
            return
        message, expire, color = self.show_toast
        if time.time() >= expire:
            self.show_toast = None
            return
        w, h = self.screen.get_size()
        font = self.font("ui", 13)
        text = truncate_text(message, font, w - 60)
        surf = font.render(text, True, (255, 255, 255))
        pad = 12
        box_w = surf.get_width() + pad * 2
        box_h = surf.get_height() + pad
        vk_h = self.vk.rect.height if self.vk.visible else 0
        box = pygame.Rect((w - box_w) // 2,
                          h - box_h - 40 - vk_h - NAV_BAR_H,
                          box_w, box_h)
        pygame.draw.rect(self.screen, color, box, border_radius=6)
        self.screen.blit(surf, (box.x + pad, box.y + pad // 2))

    def run(self) -> int:
        self.text_focus = None
        try:
            self.vk.hide()
        except Exception:
            pass
        self.force_hide_keyboard()
        for _ in range(5):
            self.force_hide_keyboard()
        last = time.time()
        try:
            while self.running:
                now = time.time()
                dt = min(0.1, now - last)
                last = now

                self.handle_events()
                self.update(dt)

                # принудительное скрытие системной клавиатуры
                if self.current_screen == "menu":
                    self.text_focus = None
                if self.text_focus is None:
                    try:
                        pygame.key.stop_text_input()
                    except Exception:
                        pass
                    self._system_input_active = False
                    # тяжёлый Android hide — раз в 0.4 с
                    if not hasattr(self, "_kb_force_t"):
                        self._kb_force_t = 0.0
                    self._kb_force_t += dt
                    if self._kb_force_t >= 0.4:
                        self._kb_force_t = 0.0
                        self.force_hide_keyboard()

                # menu не перерисовываем каждый кадр — только по флагу
                # (часы раз/сек, жесты, анимация страниц)
                busy = self.current_screen in (
                    "run", "editor", "time", "music", "plugin", "recent")
                if (self._needs_redraw or busy or self.show_toast or self.dialog):
                    self.draw()

                fps = int(self.settings.get("fps", FPS))
                fps = max(10, min(120, fps))
                self.clock.tick(fps)
        except KeyboardInterrupt:
            pass
        finally:
            self.shutdown()
        return 0

    def shutdown(self) -> None:
        LOG.info("APP", "Завершение работы")
        try:
            self.music_screen.save_state()
        except Exception:
            pass
        try:
            self.run_screen.stop()
        except Exception:
            pass
        try:
            pygame.mixer.music.stop()
        except Exception:
            pass
        try:
            self.settings.save()
        except Exception:
            pass
        try:
            self._stop_system_input()
        except Exception:
            pass
        pygame.quit()
