#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Музыкальный плеер."""
from __future__ import annotations

import os
import time
from pathlib import Path
from typing import Any, List, Optional, Tuple

import pygame

from tl_core import *
from tl_widgets import BaseScreen, TouchButton, ScrollList

# ============================================================================
# МУЗЫКА
# ============================================================================

class MusicScreen(BaseScreen):
    def __init__(self, app: "App") -> None:
        super().__init__(app)
        self.files: List[str] = []
        self.names: List[str] = []
        self.order: List[int] = []
        self.current = -1
        self.is_playing = False
        self.track_duration = 0.0
        self.play_offset = 0.0  # база после seek (get_pos сбрасывается)
        self.repeat_mode = 0
        self.shuffle = False
        self.view = "main"
        self.buttons: List[Tuple[pygame.Rect, str]] = []
        self.progress_rect = pygame.Rect(0, 0, 1, 1)
        self.dragging_progress = False
        self.playlist_scroll = 0
        self.toast_text = ""
        self.toast_until = 0.0

        self.playlist_btn_up: Optional[pygame.Rect] = None
        self.playlist_btn_down: Optional[pygame.Rect] = None
        self.aa_mode = False  # Android Auto UI
        self.volume = 0.7
        try:
            pygame.mixer.music.set_volume(self.volume)
        except Exception:
            pass

        self._saved_path: Optional[str] = None
        self._saved_pos: float = 0.0
        self._restore_state()

        self._scan()
        self._apply_saved_track()

        try:
            pygame.mixer.init()
        except Exception as e:
            LOG.error("MUSIC", f"mixer init: {e}")

    def play_file(self, path: Path) -> None:
        path_str = str(path)
        try:
            real = os.path.realpath(path_str)
        except Exception:
            real = path_str
        real_index = None
        for i, f in enumerate(self.files):
            try:
                if f == path_str or os.path.realpath(f) == real:
                    real_index = i
                    break
            except Exception:
                if f == path_str:
                    real_index = i
                    break
        if real_index is None:
            # не дублировать по имени+размеру
            try:
                sz = path.stat().st_size
            except OSError:
                sz = -1
            for i, (f, n) in enumerate(zip(self.files, self.names)):
                if n.lower() == path.name.lower():
                    try:
                        if os.path.getsize(f) == sz:
                            real_index = i
                            break
                    except OSError:
                        pass
        if real_index is None:
            self.files.insert(0, path_str)
            self.names.insert(0, path.name)
            self._update_order()
            real_index = 0
            LOG.info("MUSIC", f"Добавлен в очередь: {path.name}")

        try:
            idx_in_order = self.order.index(real_index)
        except ValueError:
            idx_in_order = 0

        self._start_track(idx_in_order)
        self.view = "main"

    def _restore_state(self) -> None:
        try:
            if MUSIC_STATE_FILE.exists():
                data = json.loads(MUSIC_STATE_FILE.read_text(encoding="utf-8"))
                self._saved_path = data.get("path")
                self._saved_pos = float(data.get("pos", 0.0))
                self.repeat_mode = int(data.get("repeat", 0))
                self.shuffle = bool(data.get("shuffle", False))
                LOG.info("MUSIC", f"Состояние прочитано: {data}")
        except Exception as e:
            LOG.warn("MUSIC", f"Не удалось прочитать состояние: {e}")

    def save_state(self) -> None:
        try:
            path = None
            if 0 <= self.current < len(self.order):
                real = self.order[self.current]
                if 0 <= real < len(self.files):
                    path = self.files[real]
            data = {
                "path": path,
                "pos": self._current_position(),
                "repeat": self.repeat_mode,
                "shuffle": self.shuffle,
            }
            MUSIC_STATE_FILE.write_text(
                json.dumps(data, ensure_ascii=False, indent=2),
                encoding="utf-8",
            )
            LOG.info("MUSIC", f"Состояние сохранено: {data}")
        except Exception as e:
            LOG.warn("MUSIC", f"Не удалось сохранить состояние: {e}")

    def _current_position(self) -> float:
        """Абсолютная позиция в треке (учитывает seek)."""
        try:
            if self.current >= 0:
                pos = pygame.mixer.music.get_pos() / 1000.0
                if pos < 0:
                    pos = 0.0
                return min(self.track_duration or 1e9,
                           self.play_offset + pos)
        except Exception:
            pass
        return self.play_offset

    def _apply_saved_track(self) -> None:
        if not self._saved_path or not self.files:
            return
        try:
            real = self.files.index(self._saved_path)
        except ValueError:
            return
        try:
            idx = self.order.index(real)
        except ValueError:
            idx = 0
        self.current = idx
        path = self.files[real]
        try:
            pygame.mixer.music.load(path)
            if self._saved_pos > 1.0:
                pygame.mixer.music.play(start=self._saved_pos)
                pygame.mixer.music.pause()
                self.play_offset = self._saved_pos
            else:
                self.play_offset = 0.0
            self.track_duration = self._duration(path)
            self.is_playing = False
            LOG.info("MUSIC", f"Восстановлен трек: {self.names[real]} "
                             f"@{self._saved_pos:.1f}s")
        except Exception as e:
            LOG.error("MUSIC", f"Восстановление: {e}")

    def _scan(self) -> None:
        items = scan_music()
        self.files = [p for p, _ in items]
        self.names = [n for _, n in items]
        self._update_order()
        LOG.info("MUSIC", f"Найдено треков: {len(self.files)}")

    def _update_order(self) -> None:
        self.order = list(range(len(self.files)))
        if self.shuffle:
            import random
            random.shuffle(self.order)

    def _toast(self, msg: str, duration: float = 2.0) -> None:
        self.toast_text = msg
        self.toast_until = time.time() + duration

    def _start_track(self, index: int) -> None:
        if not self.files or index < 0 or index >= len(self.order):
            return
        self.current = index
        real = self.order[index]
        path = self.files[real]
        try:
            pygame.mixer.music.load(path)
            pygame.mixer.music.play()
            self.play_offset = 0.0
            self.is_playing = True
            self.track_duration = self._duration(path)
            LOG.info("MUSIC", f"Играет: {self.names[real]}")
            self._toast(f"Играет: {self.names[real][:40]}", 2.5)
        except Exception as e:
            LOG.error("MUSIC", f"Ошибка запуска {path}: {e}")
            self._toast(f"Ошибка: {e}", 3.0)
            self._next_track()

    def _duration(self, path: str) -> float:
        try:
            snd = pygame.mixer.Sound(path)
            return float(snd.get_length())
        except Exception:
            return 0.0

    def _play_pause(self) -> None:
        if not self.files:
            self._toast("Треки не найдены")
            return
        if self.current < 0:
            self._start_track(0)
            return
        if self.is_playing:
            pygame.mixer.music.pause()
            self.is_playing = False
        else:
            pygame.mixer.music.unpause()
            self.is_playing = True

    def _next_track(self) -> None:
        if not self.files:
            return
        if self.repeat_mode == 2 and self.current >= 0:
            self._start_track(self.current)
            return
        nxt = self.current + 1
        if nxt >= len(self.order):
            if self.repeat_mode == 0:
                pygame.mixer.music.stop()
                self.is_playing = False
                self.current = -1
                self._toast("Конец плейлиста")
                return
            nxt = 0
        self._start_track(nxt)

    def _prev_track(self) -> None:
        if not self.files:
            return
        prv = self.current - 1
        if prv < 0:
            prv = len(self.order) - 1
        self._start_track(prv)

    def _cycle_repeat(self) -> None:
        self.repeat_mode = (self.repeat_mode + 1) % 3
        labels = ["По очереди", "Повтор плейлиста", "Повтор трека"]
        self._toast(f"Повтор: {labels[self.repeat_mode]}")

    def _toggle_shuffle(self) -> None:
        self.shuffle = not self.shuffle
        self._update_order()
        self._toast(f"Случайно: {'ON' if self.shuffle else 'OFF'}")

    def _seek(self, fraction: float) -> None:
        if self.current < 0 or self.track_duration <= 0:
            return
        try:
            pos = max(0.0, min(1.0, fraction)) * self.track_duration
            pygame.mixer.music.play(start=pos)
            # get_pos() после play(start=) идёт с нуля — храним базу
            self.play_offset = pos
            self.is_playing = True
        except Exception as e:
            LOG.error("MUSIC", f"seek: {e}")

    def handle_event(self, event: pygame.event.Event) -> None:
        super().handle_event(event)

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_ESCAPE:
                if self.view == "playlist":
                    self.view = "main"
                else:
                    self.app.back_to_menu()
                return
            if event.key == pygame.K_SPACE:
                self._play_pause()
            elif event.key == pygame.K_RIGHT:
                self._next_track()
            elif event.key == pygame.K_LEFT:
                self._prev_track()

        if self.aa_mode:
            self._handle_aa(event)
        elif self.view == "main":
            self._handle_main(event)
        else:
            self._handle_playlist(event)

    def _handle_main(self, event: pygame.event.Event) -> None:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for rect, action in self.buttons:
                if rect.collidepoint(event.pos):
                    self._do_action(action)
                    return
            if self.progress_rect.collidepoint(event.pos):
                self.dragging_progress = True
                frac = (event.pos[0] - self.progress_rect.x) / \
                    max(1, self.progress_rect.width)
                self._seek(frac)

        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging_progress = False

        elif event.type == pygame.MOUSEMOTION and self.dragging_progress:
            if self.progress_rect.width > 0:
                frac = (event.pos[0] - self.progress_rect.x) / \
                    self.progress_rect.width
                self._seek(frac)

    def _handle_playlist(self, event: pygame.event.Event) -> None:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.playlist_btn_up and \
                    self.playlist_btn_up.collidepoint(event.pos):
                self.playlist_scroll = max(0, self.playlist_scroll - 5)
                return
            if self.playlist_btn_down and \
                    self.playlist_btn_down.collidepoint(event.pos):
                self.playlist_scroll += 5
                return

            for rect, action in self.buttons:
                if rect.collidepoint(event.pos):
                    if action.startswith("pick:"):
                        idx = int(action.split(":", 1)[1])
                        self._start_track(idx)
                        self.view = "main"
                    else:
                        self._do_action(action)
                    return
        elif event.type == pygame.MOUSEWHEEL:
            self.playlist_scroll -= event.y * 3
            self.playlist_scroll = max(0, self.playlist_scroll)

    def _do_action(self, action: str) -> None:
        if action == "play":
            self._play_pause()
        elif action == "next":
            self._next_track()
        elif action == "prev":
            self._prev_track()
        elif action == "playlist":
            self.view = "playlist"
            self.playlist_scroll = 0
        elif action == "repeat":
            self._cycle_repeat()
        elif action == "shuffle":
            self._toggle_shuffle()
        elif action == "rescan":
            self._scan()
            self._toast(f"Найдено: {len(self.files)}")
        elif action == "back":
            self.app.back_to_menu()
        elif action == "close_playlist":
            self.view = "main"
        elif action == "aa_on":
            self.aa_mode = True
            self.view = "main"
            self._toast("Android Auto UI")
        elif action == "aa_off":
            self.aa_mode = False
            self._toast("Обычный плеер")
        elif action.startswith("vol:"):
            try:
                self.volume = max(0.0, min(1.0, float(action.split(":")[1])))
                pygame.mixer.music.set_volume(self.volume)
            except Exception:
                pass

    def update(self, dt: float) -> None:
        if self.is_playing and self.current >= 0:
            try:
                if not pygame.mixer.music.get_busy():
                    self._next_track()
            except Exception:
                pass

    def draw(self, surface: pygame.Surface) -> None:
        if self.aa_mode:
            self._draw_aa(surface)
        else:
            surface.fill(PANEL_BG)
            if self.view == "main":
                self._draw_main(surface)
            else:
                self._draw_playlist(surface)
        self._draw_toast(surface)
        self._needs_redraw = False

    def _draw_main(self, surface: pygame.Surface) -> None:
        w, h = surface.get_size()
        self.buttons.clear()

        # фон-градиент
        for yy in range(0, h - NAV_BAR_H, 3):
            t = yy / max(1, h - NAV_BAR_H)
            col = lerp_color((18, 12, 28), (28, 18, 40), t)
            pygame.draw.rect(surface, col, (0, yy, w, 3))

        title_font = self.app.font("ui", 22, bold=True)
        title = title_font.render("Музыка", True, TEXT_BRIGHT)
        surface.blit(title, (16, 12))

        count_font = self.app.font("ui", 11)
        c = count_font.render(f"{len(self.files)} треков", True, TEXT_DIM)
        surface.blit(c, (16 + title.get_width() + 12, 20))

        if self.current >= 0:
            real = self.order[self.current]
            name = self.names[real]
        else:
            name = "Нет трека"
        nf = self.app.font("ui", 16, bold=True)
        name = truncate_text(name, nf, w - 32)
        ns = nf.render(name, True, TEXT_BRIGHT)
        surface.blit(ns, ((w - ns.get_width()) // 2, 52))

        cover_size = min(w - 80, max(120, h // 3 - 20))
        cover_rect = pygame.Rect((w - cover_size) // 2, 85,
                                 cover_size, cover_size)
        # тень
        pygame.draw.rect(surface, (0, 0, 0),
                         cover_rect.move(4, 6), border_radius=16)
        # обложка с градиентом
        for i in range(cover_size):
            t = i / max(1, cover_size)
            col = lerp_color((60, 20, 50), (30, 40, 90), t)
            pygame.draw.line(surface, col,
                             (cover_rect.x, cover_rect.y + i),
                             (cover_rect.right, cover_rect.y + i))
        pygame.draw.rect(surface, MUSIC_ACCENT, cover_rect,
                         width=2, border_radius=16)
        note_font = self.app.font("ui", max(48, cover_size // 3), bold=True)
        note = note_font.render("music", True, (255, 100, 140))
        surface.blit(note, note.get_rect(center=cover_rect.center))

        prog_y = cover_rect.bottom + 28
        prog_h = 10
        prog_x = 28
        prog_w = w - 56
        self.progress_rect = pygame.Rect(prog_x, prog_y, prog_w, prog_h)
        pygame.draw.rect(surface, (40, 30, 50),
                         self.progress_rect, border_radius=5)

        pos = self._current_position() if self.current >= 0 else 0.0

        frac = 0.0
        if self.track_duration > 0:
            frac = max(0.0, min(1.0, pos / self.track_duration))
            fill_w = int(prog_w * frac)
            if fill_w > 0:
                pygame.draw.rect(surface, MUSIC_ACCENT,
                                 pygame.Rect(prog_x, prog_y, fill_w, prog_h),
                                 border_radius=5)
            # ползунок
            kx = prog_x + fill_w
            pygame.draw.circle(surface, (255, 255, 255),
                               (kx, prog_y + prog_h // 2), 8)
            pygame.draw.circle(surface, MUSIC_ACCENT,
                               (kx, prog_y + prog_h // 2), 5)

        time_font = self.app.font("mono", 12)
        cur_m, cur_s = divmod(int(pos), 60)
        tot_m, tot_s = divmod(int(self.track_duration), 60)
        cur_surf = time_font.render(f"{cur_m:02d}:{cur_s:02d}",
                                    True, TEXT_DIM)
        tot_surf = time_font.render(f"{tot_m:02d}:{tot_s:02d}",
                                    True, TEXT_DIM)
        surface.blit(cur_surf, (prog_x, prog_y + 16))
        surface.blit(tot_surf,
                     (prog_x + prog_w - tot_surf.get_width(), prog_y + 16))

        ctrl_y = prog_y + 50
        btn_size = 60
        gap = 20
        total_w = 3 * btn_size + 2 * gap
        start_x = (w - total_w) // 2

        prev_rect = pygame.Rect(start_x, ctrl_y, btn_size, btn_size)
        self._draw_button(surface, prev_rect, "<<", MUSIC_PANEL)
        self.buttons.append((prev_rect, "prev"))

        play_rect = pygame.Rect(start_x + btn_size + gap, ctrl_y - 6,
                                btn_size + 12, btn_size + 12)
        self._draw_button(surface, play_rect,
                          "||" if self.is_playing else ">",
                          MUSIC_ACCENT, big=True)
        self.buttons.append((play_rect, "play"))

        next_rect = pygame.Rect(start_x + 2 * (btn_size + gap),
                                ctrl_y, btn_size, btn_size)
        self._draw_button(surface, next_rect, ">>", MUSIC_PANEL)
        self.buttons.append((next_rect, "next"))

        bottom_y = h - 62 - NAV_BAR_H
        b_h = 44
        b_w = (w - 32 - 3 * 6) // 4
        x = 16
        for label, action, color in [
            ("Плейлист", "playlist", MUSIC_PANEL),
            (f"REP {self.repeat_mode}", "repeat", MUSIC_PANEL),
            (f"SHF {'ON' if self.shuffle else 'OFF'}", "shuffle",
             MUSIC_PANEL),
            ("Выход", "back", (170, 60, 60)),
        ]:
            rect = pygame.Rect(x, bottom_y, b_w, b_h)
            self._draw_button(surface, rect, label, color, small=True)
            self.buttons.append((rect, action))
            x += b_w + 6

        # кнопка Android Auto — справа посередине, только если вкл. в настройках
        if self.app.settings.get("android_auto", False):
            aa_w, aa_h = 44, 120
            aa_rect = pygame.Rect(w - aa_w - 8, (h - NAV_BAR_H - aa_h) // 2,
                                  aa_w, aa_h)
            pygame.draw.rect(surface, (0, 120, 215), aa_rect, border_radius=12)
            af = self.app.font("ui", 11, bold=True)
            # вертикальный текст
            lines = ["A", "A", "→"]
            ly = aa_rect.y + 16
            for line in ("to", "AA"):
                s = af.render(line, True, (255, 255, 255))
                surface.blit(s, (aa_rect.centerx - s.get_width() // 2, ly))
                ly += 22
            self.buttons.append((aa_rect, "aa_on"))

    def _draw_playlist(self, surface: pygame.Surface) -> None:
        w, h = surface.get_size()
        self.buttons.clear()

        title_font = self.app.font("ui", 22, bold=True)
        title = title_font.render("Плейлист", True, TEXT_BRIGHT)
        surface.blit(title, (16, 12))

        back_rect = pygame.Rect(w - 100, 12, 88, 38)
        self._draw_button(surface, back_rect, "Назад", MUSIC_PANEL,
                          small=True)
        self.buttons.append((back_rect, "close_playlist"))

        list_top = 60
        list_bottom = h - 20 - NAV_BAR_H
        row_h = 42
        visible_rows = (list_bottom - list_top) // row_h

        total = len(self.order)
        max_scroll = max(0, total - visible_rows)
        self.playlist_scroll = max(0, min(self.playlist_scroll, max_scroll))

        row_font = self.app.font("ui", 13)
        y = list_top
        for idx in range(self.playlist_scroll,
                         min(total, self.playlist_scroll + visible_rows)):
            real = self.order[idx]
            if real < 0 or real >= len(self.names):
                continue
            row = pygame.Rect(10, y, w - 20, row_h - 4)
            if idx == self.current:
                pygame.draw.rect(surface, (60, 30, 60), row,
                                 border_radius=6)
                pygame.draw.rect(surface, MUSIC_ACCENT, row,
                                 width=2, border_radius=6)
            elif idx % 2 == 1:
                pygame.draw.rect(surface, ROW_ALT, row, border_radius=6)

            name = truncate_text(self.names[real], row_font, w - 60)
            color = MUSIC_ACCENT if idx == self.current else TEXT_BRIGHT
            ns = row_font.render(f"{idx+1:>3}. {name}", True, color)
            surface.blit(ns, (row.x + 12, row.y + 8))

            self.buttons.append((row, f"pick:{idx}"))
            y += row_h

        if total == 0:
            msg_font = self.app.font("ui", 13)
            msg = msg_font.render(
                "Треки не найдены в Music / Download / sdcard",
                True, TEXT_DIM
            )
            surface.blit(msg, (30, list_top + 20))

        arrow_w, arrow_h = 60, 66
        gap = 12
        cx = w - arrow_w - 12
        cy_center = (list_top + list_bottom) // 2

        up_rect = pygame.Rect(cx, cy_center - arrow_h - gap // 2,
                              arrow_w, arrow_h)
        down_rect = pygame.Rect(cx, cy_center + gap // 2,
                                arrow_w, arrow_h)
        self.playlist_btn_up = up_rect
        self.playlist_btn_down = down_rect

        label_font = self.app.font("ui", 10, bold=True)
        lbl = label_font.render("СПИСОК", True, TEXT_DIM)
        surface.blit(lbl,
                     (up_rect.x + (up_rect.w - lbl.get_width()) // 2,
                      up_rect.y - 16))

        pygame.draw.rect(surface, MUSIC_PANEL, up_rect, border_radius=10)
        pygame.draw.rect(surface, MUSIC_ACCENT, up_rect, width=2,
                         border_radius=10)
        big_font = self.app.font("ui", 36, bold=True)
        up_sym = big_font.render("^", True, (255, 255, 255))
        surface.blit(up_sym, up_sym.get_rect(center=up_rect.center))

        pygame.draw.rect(surface, MUSIC_PANEL, down_rect, border_radius=10)
        pygame.draw.rect(surface, MUSIC_ACCENT, down_rect, width=2,
                         border_radius=10)
        down_sym = big_font.render("v", True, (255, 255, 255))
        surface.blit(down_sym,
                     down_sym.get_rect(center=down_rect.center))

        if total > visible_rows:
            pos_text = f"{self.playlist_scroll + 1}-" \
                       f"{min(total, self.playlist_scroll + visible_rows)}" \
                       f"/{total}"
            pos_font = self.app.font("mono", 10)
            pos_surf = pos_font.render(pos_text, True, TEXT_DIM)
            pos_x = down_rect.x + (down_rect.w -
                                   pos_surf.get_width()) // 2
            surface.blit(pos_surf, (pos_x, down_rect.bottom + 6))

    def _draw_button(self, surface, rect, label, color,
                     big=False, small=False):
        pygame.draw.rect(surface, color, rect, border_radius=10)
        if big:
            font = self.app.font("ui", 28, bold=True)
        elif small:
            font = self.app.font("ui", 12, bold=True)
        else:
            font = self.app.font("ui", 18, bold=True)
        surf = font.render(label, True, (255, 255, 255))
        surface.blit(surf, surf.get_rect(center=rect.center))

    def _handle_aa(self, event: pygame.event.Event) -> None:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for rect, action in self.buttons:
                if rect.collidepoint(event.pos):
                    if action.startswith("pick:"):
                        idx = int(action.split(":", 1)[1])
                        self._start_track(idx)
                    else:
                        self._do_action(action)
                    return
            if self.progress_rect.collidepoint(event.pos):
                self.dragging_progress = True
                frac = (event.pos[0] - self.progress_rect.x) / \
                    max(1, self.progress_rect.width)
                self._seek(frac)
            # volume slider
            vr = getattr(self, "volume_rect", None)
            if vr and vr.collidepoint(event.pos):
                frac = 1.0 - (event.pos[1] - vr.y) / max(1, vr.height)
                self.volume = max(0.0, min(1.0, frac))
                try:
                    pygame.mixer.music.set_volume(self.volume)
                except Exception:
                    pass
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging_progress = False
        elif event.type == pygame.MOUSEMOTION and self.dragging_progress:
            if self.progress_rect.width > 0:
                frac = (event.pos[0] - self.progress_rect.x) / \
                    self.progress_rect.width
                self._seek(frac)
        elif event.type == pygame.MOUSEWHEEL:
            self.playlist_scroll = max(0, self.playlist_scroll - event.y * 2)

    def _draw_aa(self, surface: pygame.Surface) -> None:
        """Светлый интерфейс в стиле Android Auto / car display."""
        w, h = surface.get_size()
        self.buttons.clear()
        BG = (248, 250, 252)
        CARD = (255, 255, 255)
        BLUE = (0, 120, 215)
        TEXT_D = (30, 34, 40)
        MUTED = (120, 130, 145)
        surface.fill(BG)

        # header
        brand_f = self.app.font("ui", 16, bold=True)
        surface.blit(brand_f.render("Tile Music", True, TEXT_D), (20, 12))
        exit_r = pygame.Rect(w - 100, 8, 88, 36)
        pygame.draw.rect(surface, (230, 235, 240), exit_r, border_radius=10)
        ef = self.app.font("ui", 12, bold=True)
        surface.blit(ef.render("Назад", True, TEXT_D),
                     ef.render("Назад", True, TEXT_D).get_rect(center=exit_r.center))
        self.buttons.append((exit_r, "aa_off"))

        # layout: left art, right controls (landscape-friendly)
        landscape = w > h
        if landscape:
            art_size = min(h - 80 - NAV_BAR_H, w // 3)
            art_x, art_y = 24, 56
            right_x = art_x + art_size + 28
            right_w = w - right_x - 70
        else:
            art_size = min(w - 80, 180)
            art_x = (w - art_size) // 2
            art_y = 52
            right_x = 20
            right_w = w - 40

        # cover
        art = pygame.Rect(art_x, art_y, art_size, art_size)
        pygame.draw.rect(surface, (220, 228, 236), art, border_radius=18)
        for i in range(art_size):
            t = i / max(1, art_size)
            col = (
                int(120 + 80 * t),
                int(160 + 40 * (1 - t)),
                int(200 - 40 * t),
            )
            pygame.draw.line(surface, col, (art.x, art.y + i),
                             (art.right - 1, art.y + i))
        pygame.draw.rect(surface, (200, 210, 220), art, 2, border_radius=18)
        note = self.app.font("ui", max(40, art_size // 3), bold=True).render(
            "music", True, (255, 255, 255))
        surface.blit(note, note.get_rect(center=art.center))

        # track title under art (portrait) or left bottom
        if self.current >= 0:
            real = self.order[self.current]
            title = self.names[real]
        else:
            title = "Нет трека"
        tf = self.app.font("ui", 18, bold=True)
        ts = tf.render(truncate_text(title, tf, art_size + 20), True, TEXT_D)
        if landscape:
            surface.blit(ts, (art_x, art.bottom + 10))
            sf = self.app.font("ui", 13).render(
                f"{self.current + 1}/{len(self.files)} треков", True, MUTED)
            surface.blit(sf, (art_x, art.bottom + 36))
        else:
            surface.blit(ts, ((w - ts.get_width()) // 2, art.bottom + 8))

        # Now Playing block
        if landscape:
            np_y = 56
        else:
            np_y = art.bottom + 50
        nf = self.app.font("ui", 14, bold=True)
        surface.blit(nf.render("Now Playing", True, TEXT_D), (right_x, np_y))

        pos = self._current_position() if self.current >= 0 else 0.0
        frac = (pos / self.track_duration) if self.track_duration > 0 else 0.0
        frac = max(0.0, min(1.0, frac))

        prog = pygame.Rect(right_x, np_y + 28, max(120, right_w - 10), 8)
        self.progress_rect = prog
        pygame.draw.rect(surface, (210, 218, 228), prog, border_radius=4)
        if frac > 0:
            pygame.draw.rect(surface, BLUE,
                             pygame.Rect(prog.x, prog.y, int(prog.w * frac), prog.h),
                             border_radius=4)
        pygame.draw.circle(surface, BLUE,
                           (prog.x + int(prog.w * frac), prog.centery), 7)

        mono = self.app.font("mono", 11)
        cm, cs = divmod(int(pos), 60)
        tm, ts_ = divmod(int(self.track_duration), 60)
        surface.blit(mono.render(f"{cm}:{cs:02d}", True, MUTED),
                     (prog.x, prog.bottom + 4))
        tot = mono.render(f"{tm}:{ts_:02d}", True, MUTED)
        surface.blit(tot, (prog.right - tot.get_width(), prog.bottom + 4))

        # controls
        cy = prog.bottom + 36
        gap = 18
        sizes = [44, 44, 64, 44, 44]
        labels = ["SHF", "<<", "||" if self.is_playing else ">", ">>", "REP"]
        actions = ["shuffle", "prev", "play", "next", "repeat"]
        total = sum(sizes) + gap * (len(sizes) - 1)
        sx = right_x + max(0, (right_w - total) // 2)
        for i, (sz, lab, act) in enumerate(zip(sizes, labels, actions)):
            r = pygame.Rect(sx, cy + (64 - sz) // 2, sz, sz)
            col = BLUE if act == "play" else (230, 235, 242)
            tc = (255, 255, 255) if act == "play" else TEXT_D
            pygame.draw.rect(surface, col, r, border_radius=sz // 2)
            bf = self.app.font("ui", 16 if act == "play" else 12, bold=True)
            bs = bf.render(lab, True, tc)
            surface.blit(bs, bs.get_rect(center=r.center))
            self.buttons.append((r, act))
            sx += sz + gap

        # Up Next list
        list_y = cy + 80
        surface.blit(nf.render("Up Next", True, TEXT_D), (right_x, list_y))
        list_y += 28
        row_h = 36
        max_rows = max(3, (h - list_y - NAV_BAR_H - 16) // row_h)
        total_tr = len(self.order)
        self.playlist_scroll = max(0, min(self.playlist_scroll,
                                          max(0, total_tr - max_rows)))
        for i in range(self.playlist_scroll,
                       min(total_tr, self.playlist_scroll + max_rows)):
            real = self.order[i]
            if real < 0 or real >= len(self.names):
                continue
            row = pygame.Rect(right_x, list_y, right_w - 8, row_h - 4)
            if i == self.current:
                pygame.draw.rect(surface, (220, 236, 255), row, border_radius=10)
            name = truncate_text(f"{i + 1}. {self.names[real]}",
                                 self.app.font("ui", 13), right_w - 60)
            col = BLUE if i == self.current else TEXT_D
            surface.blit(self.app.font("ui", 13).render(name, True, col),
                         (row.x + 12, row.y + 8))
            self.buttons.append((row, f"pick:{i}"))
            list_y += row_h

        # volume vertical right
        vr = pygame.Rect(w - 36, 70, 18, min(180, h // 3))
        self.volume_rect = vr
        pygame.draw.rect(surface, (220, 226, 234), vr, border_radius=8)
        fill_h = int(vr.h * self.volume)
        pygame.draw.rect(surface, BLUE,
                         pygame.Rect(vr.x, vr.bottom - fill_h, vr.w, fill_h),
                         border_radius=8)
        surface.blit(self.app.font("mono", 10).render(
            f"{int(self.volume * 100)}%", True, MUTED),
            (vr.x - 8, vr.bottom + 4))

    def _draw_toast(self, surface):
        if time.time() >= self.toast_until:
            return
        font = self.app.font("ui", 13)
        surf = font.render(self.toast_text, True, (255, 255, 255))
        pad = 12
        box = pygame.Rect(0, 0, surf.get_width() + pad * 2,
                          surf.get_height() + pad)
        box.centerx = surface.get_width() // 2
        box.bottom = surface.get_height() - 90 - NAV_BAR_H
        pygame.draw.rect(surface, (200, 60, 120), box, border_radius=8)
        surface.blit(surf, (box.x + pad, box.y + pad // 2))


