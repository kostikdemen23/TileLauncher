#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Системные экраны: настройки, маркет, недавние, плагины, обои…"""
from __future__ import annotations

import importlib.util
import json
import time
import traceback
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import pygame

from tl_core import *
from tl_widgets import BaseScreen, TouchButton, TextInput, ScrollList

# ============================================================================
# НЕДАВНИЕ
# ============================================================================

class RecentScreen(BaseScreen):
    def __init__(self, app):
        super().__init__(app)
        self.buttons: List[Tuple[pygame.Rect, str]] = []
        self.close_rect: Optional[pygame.Rect] = None
        self._swipe_name: Optional[str] = None
        self._swipe_start_x = 0
        self._swipe_dx = 0
        self._swipe_y = 0

    def _close_all(self) -> None:
        self.app.recent_screens.clear()
        try:
            self.app.run_screen.stop()
        except Exception:
            pass
        try:
            if self.app.music_screen.is_playing:
                pygame.mixer.music.stop()
                self.app.music_screen.is_playing = False
        except Exception:
            pass
        self.app.clear_text_focus()
        self.app.toast("Все закрыто", SUCCESS)
        self.app.show_screen("menu")
        LOG.info("RECENT", "Закрыты все недавние")

    def _close_one(self, name: str) -> None:
        self.app.recent_screens = [
            (n, l) for (n, l) in self.app.recent_screens if n != name
        ]
        if name == "run":
            try:
                self.app.run_screen.stop()
            except Exception:
                pass
        if name == "music":
            try:
                if self.app.music_screen.is_playing:
                    pygame.mixer.music.stop()
                    self.app.music_screen.is_playing = False
            except Exception:
                pass
        self.app.toast("Закрыто", SUCCESS)
        self._swipe_name = None
        self._swipe_dx = 0

    def handle_event(self, event):
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.close_rect and self.close_rect.collidepoint(event.pos):
                self._close_all()
                return
            self._swipe_name = None
            self._swipe_dx = 0
            for rect, name in self.buttons:
                if rect.collidepoint(event.pos):
                    self._swipe_name = name
                    self._swipe_start_x = event.pos[0]
                    self._swipe_y = rect.y
                    return
            self.app.back_to_menu()
        elif event.type == pygame.MOUSEMOTION and self._swipe_name:
            self._swipe_dx = event.pos[0] - self._swipe_start_x
            if self._swipe_dx < 0:
                self._swipe_dx = 0
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self._swipe_name:
                if self._swipe_dx > 80:
                    self._close_one(self._swipe_name)
                elif self._swipe_dx < 20:
                    self.app.show_screen(self._swipe_name)
                self._swipe_name = None
                self._swipe_dx = 0

    def update(self, dt):
        pass

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(PANEL_BG)

        title_font = self.app.font("ui", 22, bold=True)
        title = title_font.render("Недавние", True, TEXT_BRIGHT)
        surface.blit(title, (16, 12))

        hint_font = self.app.font("ui", 11)
        hint = hint_font.render("свайп вправо — закрыть", True, TEXT_DIM)
        surface.blit(hint, (16 + title.get_width() + 12, 20))

        recent = self.app.recent_screens
        self.buttons = []

        # Крестик выше (над навбаром с отступом)
        btn_size = 56
        cx = w // 2
        cy = h - NAV_BAR_H - 56
        self.close_rect = pygame.Rect(cx - btn_size // 2, cy - btn_size // 2,
                                      btn_size, btn_size)
        pygame.draw.circle(surface, (160, 50, 50), (cx, cy), btn_size // 2)
        pygame.draw.circle(surface, (220, 90, 90), (cx, cy), btn_size // 2, 2)
        x_font = self.app.font("ui", 28, bold=True)
        x_surf = x_font.render("×", True, (255, 255, 255))
        surface.blit(x_surf, x_surf.get_rect(center=(cx, cy - 2)))

        if not recent:
            msg_font = self.app.font("ui", 14)
            msg = msg_font.render("Пока ничего не открывалось",
                                  True, TEXT_DIM)
            surface.blit(msg, (30, 100))
            return

        card_h = 64
        card_gap = 10
        top = 60
        card_font = self.app.font("ui", 15, bold=True)
        sub_font = self.app.font("ui", 11)
        num_font = self.app.font("mono", 14, bold=True)
        bottom_limit = h - NAV_BAR_H - 100

        for i, (name, label) in enumerate(recent[:10]):
            y = top + i * (card_h + card_gap)
            if y + card_h > bottom_limit:
                break
            dx = self._swipe_dx if name == self._swipe_name else 0
            rect = pygame.Rect(10 + dx, y, w - 20, card_h)

            if dx > 40:
                pygame.draw.rect(surface, (120, 40, 40),
                                 pygame.Rect(10, y, min(dx, w - 20), card_h),
                                 border_radius=10)
                close_lbl = self.app.font("ui", 12, bold=True).render(
                    "Закрыть", True, (255, 200, 200))
                surface.blit(close_lbl, (20, y + 22))

            pygame.draw.rect(surface, PANEL_BG, rect, border_radius=10)
            pygame.draw.rect(surface, PANEL_BORDER, rect,
                             width=1, border_radius=10)

            num = num_font.render(f"{i+1}", True, ACCENT)
            surface.blit(num, (rect.x + 16, rect.y + 22))

            ns = card_font.render(label, True, TEXT_BRIGHT)
            surface.blit(ns, (rect.x + 56, rect.y + 14))

            id_surf = sub_font.render(name, True, TEXT_DIM)
            surface.blit(id_surf, (rect.x + 56, rect.y + 38))

            self.buttons.append((pygame.Rect(10, y, w - 20, card_h), name))


# ============================================================================
# ПАПКА НА РАБОЧЕМ СТОЛЕ
# ============================================================================

class FolderScreen(BaseScreen):
    def __init__(self, app):
        super().__init__(app)
        self.folder_tag = ""
        self.title = "Папка"
        self.items: List[Dict[str, Any]] = []
        self.row_rects: List[Tuple[pygame.Rect, Dict[str, Any]]] = []
        self.buttons = [
            TouchButton("Назад", app.back_to_menu,
                        color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 80, 36)),
        ]

    def open_folder(self, tag: str) -> None:
        self.folder_tag = tag
        folders = self.app.settings.get("desktop_folders") or []
        folder = next((f for f in folders if f.get("tag") == tag), None)
        self.title = (folder or {}).get("name", "Папка")
        app_tags = list((folder or {}).get("apps") or [])
        by_tag = {a["tag"]: a for a in self.app.tile_screen._all_app_defs()}
        self.items = []
        for t in app_tags:
            if t in by_tag:
                self.items.append(by_tag[t])

    def handle_event(self, event):
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return
        for b in self.buttons:
            if b.handle_event(event):
                return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for rect, info in self.row_rects:
                if rect.collidepoint(event.pos) and info.get("action"):
                    try:
                        info["action"]()
                    except Exception as e:
                        self.app.toast(str(e), ERROR)
                    return

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(PANEL_BG)
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True), animations=anim)
        title = self.app.font("ui", 18, bold=True).render(self.title, True, TEXT_BRIGHT)
        surface.blit(title, (16, 50))
        self.row_rects = []
        y = 90
        lf = self.app.font("ui", 15)
        for i, info in enumerate(self.items):
            rect = pygame.Rect(10, y, w - 20, 48)
            self.row_rects.append((rect, info))
            pygame.draw.rect(surface, ROW_ALT if i % 2 else PANEL_BG, rect, border_radius=8)
            surface.blit(lf.render(info.get("label", "?"), True, TEXT_BRIGHT),
                         (rect.x + 14, rect.y + 12))
            y += 54
        if not self.items:
            surface.blit(self.app.font("ui", 14).render(
                "Папка пуста. Добавьте теги в settings → desktop_folders",
                True, TEXT_DIM), (16, 100))


# ============================================================================
# ПЛАГИН ИЗ МАРКЕТА (уровень лаунчера, без subprocess)
# ============================================================================

class PluginHostScreen(BaseScreen):
    """Хост для приложений market с create_plugin(app)."""

    def __init__(self, app: "App") -> None:
        super().__init__(app)
        self.plugin: Any = None
        self.path: Optional[Path] = None
        self.error: Optional[str] = None
        self.buttons = [
            TouchButton("Назад", self._back,
                        color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 80, 36)),
        ]

    def _back(self) -> None:
        if self.plugin is not None and hasattr(self.plugin, "on_close"):
            try:
                self.plugin.on_close()
            except Exception:
                pass
        self.plugin = None
        self.app.back_to_menu()

    def load(self, path: Path) -> bool:
        self.path = Path(path)
        self.error = None
        self.plugin = None
        try:
            self.plugin = load_market_plugin(self.path, self.app)
            title = getattr(self.plugin, "title", self.path.stem)
            LOG.info("PLUGIN", f"Загружен: {self.path.name} ({title})")
            return True
        except Exception as e:
            self.error = f"{type(e).__name__}: {e}"
            LOG.error("PLUGIN", f"{self.path}: {self.error}\n{traceback.format_exc()}")
            return False

    def handle_event(self, event: pygame.event.Event) -> None:
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            if self.plugin is not None and hasattr(self.plugin, "apply_text_input"):
                if event.type == pygame.TEXTINPUT:
                    try:
                        self.plugin.apply_text_input(event.text)
                    except Exception:
                        pass
            return
        for b in self.buttons:
            if b.handle_event(event):
                return
        if self.plugin is not None and hasattr(self.plugin, "handle_event"):
            try:
                self.plugin.handle_event(event)
            except Exception as e:
                self.error = str(e)
                LOG.error("PLUGIN", f"handle_event: {e}")

    def apply_text_input(self, text: str) -> None:
        if self.plugin is not None and hasattr(self.plugin, "apply_text_input"):
            self.plugin.apply_text_input(text)

    def insert(self, ch: str) -> None:
        pl = self.plugin
        if pl is None:
            return
        if hasattr(pl, "insert"):
            pl.insert(ch)
        elif hasattr(pl, "apply_text_input"):
            pl.apply_text_input(ch)

    def backspace(self) -> None:
        pl = self.plugin
        if pl is None:
            return
        if hasattr(pl, "backspace"):
            pl.backspace()

    def submit(self) -> None:
        pl = self.plugin
        if pl is None:
            return
        if hasattr(pl, "submit"):
            pl.submit()

    def update(self, dt: float) -> None:
        for b in self.buttons:
            b.update(dt)
        if self.plugin is not None and hasattr(self.plugin, "update"):
            try:
                self.plugin.update(dt)
            except Exception as e:
                self.error = str(e)

    def draw(self, surface: pygame.Surface) -> None:
        w, h = surface.get_size()
        if self.plugin is not None and hasattr(self.plugin, "draw"):
            try:
                self.plugin.draw(surface)
            except Exception as e:
                surface.fill(PANEL_BG)
                err = self.app.font("ui", 14).render(f"Ошибка плагина: {e}", True, ERROR)
                surface.blit(err, (16, 60))
        else:
            surface.fill(PANEL_BG)
            msg = self.error or "Плагин не загружен"
            surface.blit(self.app.font("ui", 14).render(msg, True, ERROR), (16, 60))
            if self.path:
                surface.blit(
                    self.app.font("mono", 12).render(str(self.path), True, TEXT_DIM),
                    (16, 90))
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True), animations=anim)


# ============================================================================
# TILE MARKET
# ============================================================================

class MarketScreen(BaseScreen):
    """Магазин приложений в стиле Google Play."""

    HOLD_SEC = 0.45
    CARD_H = 88
    FEATURED_H = 140

    def __init__(self, app):
        super().__init__(app)
        self.query = ""
        self.apps: List[Dict[str, Any]] = []
        self.filtered: List[Dict[str, Any]] = []
        self.row_rects: List[Tuple[pygame.Rect, Dict[str, Any], str]] = []
        self.search = TextInput(
            pygame.Rect(10, 50, 200, 42),
            placeholder="Поиск в Tile Market…",
            on_submit=self._on_search,
            app=app,
        )
        self.buttons = [
            TouchButton("↻", self.refresh,
                        color=(30, 140, 80),
                        rect=pygame.Rect(8, 8, 44, 40)),
            TouchButton("Папка", self._open_folder,
                        color=(70, 80, 100),
                        rect=pygame.Rect(56, 8, 72, 40)),
        ]
        self._hold_info: Optional[Dict[str, Any]] = None
        self._hold_start = 0.0
        self._hold_active = False
        self._add_rect: Optional[pygame.Rect] = None
        self.category = "все"
        self.cat_rects: List[Tuple[pygame.Rect, str]] = []
        self.scroll = 0
        self.max_scroll = 0
        self.drag_y = None
        self.drag_scroll = 0
        self.featured_i = 0
        self.refresh()

    def refresh(self) -> None:
        self.apps = scan_market_apps()
        self._apply_filter()
        self.scroll = 0
        self.app.toast(f"Tile Market · {len(self.apps)}")

    def _apply_filter(self) -> None:
        q = self.query.strip().lower()
        items = list(self.apps)
        if self.category and self.category != "все":
            items = [a for a in items
                     if a.get("category", "утилиты") == self.category]
        if q:
            items = [
                a for a in items
                if q in a["name"].lower()
                or q in str(a.get("description", "")).lower()
                or q in str(a.get("category", "")).lower()
            ]
        self.filtered = items

    def _on_search(self, text: str) -> None:
        self.query = text
        self._apply_filter()
        self.scroll = 0

    def _open_folder(self) -> None:
        try:
            MARKET_DIR.mkdir(parents=True, exist_ok=True)
        except Exception:
            pass
        self.app.explorer_screen.cwd = MARKET_DIR
        self.app.explorer_screen.refresh()
        self.app.show_screen("explorer")

    def _is_on_desktop(self, app_info: Dict[str, Any]) -> bool:
        tag = str(app_info.get("tag") or app_info.get("name") or "")
        path = str(app_info.get("path") or "")
        for item in self.app.settings.get("desktop_apps") or []:
            if not isinstance(item, dict):
                continue
            if item.get("tag") == tag or item.get("path") == path:
                return True
        return False

    def _launch(self, app_info: Dict[str, Any]) -> None:
        path = app_info.get("path") or app_info.get("entry")
        if path:
            self.app.launch_market_app(str(path))

    def _add_to_desktop(self, app_info: Dict[str, Any]) -> None:
        tag = str(app_info.get("tag") or app_info.get("name") or "app")
        name = str(app_info.get("name") or tag)
        path = str(app_info.get("path") or app_info.get("entry") or "")
        if not path:
            self.app.toast("Нет пути", WARNING)
            return
        apps = list(self.app.settings.get("desktop_apps") or [])
        if any(isinstance(a, dict) and (a.get("tag") == tag or a.get("path") == path)
               for a in apps):
            self.app.toast("Уже на рабочем столе", ACCENT)
            return
        apps.append({"tag": tag, "name": name, "path": path})
        self.app.settings.set("desktop_apps", apps)
        try:
            self.app.tile_screen.rebuild()
        except Exception:
            pass
        self.app.toast(f"Установлено: {name}", SUCCESS)

    def handle_event(self, event: pygame.event.Event) -> None:
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            if self.search.active:
                return
            return
        for b in self.buttons:
            if b.handle_event(event):
                return
        if self.search.handle_event(event):
            self.query = self.search.text
            self._apply_filter()
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for r, cat in self.cat_rects:
                if r.collidepoint(event.pos):
                    self.category = cat
                    self._apply_filter()
                    self.scroll = 0
                    self.redraw()
                    return
            # кнопки на карточках
            for rect, info, action in self.row_rects:
                if rect.collidepoint(event.pos):
                    if action == "open":
                        self._launch(info)
                        return
                    if action == "install":
                        self._add_to_desktop(info)
                        return
                    if action == "card":
                        self._hold_info = info
                        self._hold_start = time.time()
                        self._hold_active = False
                        self.drag_y = event.pos[1]
                        self.drag_scroll = self.scroll
                        return
            if self._add_rect and self._add_rect.collidepoint(event.pos):
                if self._hold_info:
                    self._add_to_desktop(self._hold_info)
                return
            self.drag_y = event.pos[1]
            self.drag_scroll = self.scroll
            self._hold_info = None

        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self._hold_info and not self._hold_active:
                if time.time() - self._hold_start < self.HOLD_SEC:
                    self._launch(self._hold_info)
            if self._hold_active and self._add_rect and \
                    self._add_rect.collidepoint(event.pos) and self._hold_info:
                self._add_to_desktop(self._hold_info)
            self._hold_info = None
            self._hold_active = False
            self.drag_y = None

        elif event.type == pygame.MOUSEMOTION and self.drag_y is not None:
            dy = abs(event.pos[1] - self.drag_y)
            if dy > 12:
                self._hold_info = None
            self.scroll = max(0, min(self.max_scroll,
                                     self.drag_scroll + (self.drag_y - event.pos[1])))
            self.redraw()
        elif event.type == pygame.MOUSEWHEEL:
            self.scroll = max(0, min(self.max_scroll,
                                     self.scroll - event.y * 48))
            self.redraw()

    def update(self, dt: float) -> None:
        for b in self.buttons:
            b.update(dt)
        self.search.update(dt)
        if self._hold_info and not self._hold_active:
            if time.time() - self._hold_start >= self.HOLD_SEC:
                self._hold_active = True
                self.redraw()
        # авто-смена featured
        if not hasattr(self, "_feat_t"):
            self._feat_t = 0.0
        self._feat_t += dt
        if self._feat_t > 4.0 and self.filtered:
            self._feat_t = 0.0
            self.featured_i = (self.featured_i + 1) % max(1, min(5, len(self.filtered)))
            self.redraw()

    def _icon_color(self, info: Dict[str, Any]) -> Tuple[int, int, int]:
        if info.get("plugin"):
            return (30, 160, 90)
        if info.get("type") == "folder":
            return (80, 120, 200)
        name = str(info.get("name") or "")
        palette = [
            (66, 133, 244), (219, 68, 55), (244, 180, 0),
            (15, 157, 88), (171, 71, 188), (0, 172, 193),
        ]
        return palette[hash(name) % len(palette)]

    def _fake_rating(self, info: Dict[str, Any]) -> str:
        h = abs(hash(str(info.get("name", "")))) % 15
        stars = 3.5 + (h % 15) / 10.0  # 3.5–5.0
        return f"{stars:.1f}"

    def draw(self, surface: pygame.Surface) -> None:
        w, h = surface.get_size()
        # Play-like светлый фон
        surface.fill((241, 243, 244))
        PLAY_GREEN = (18, 163, 84)
        PLAY_DARK = (32, 33, 36)
        CARD = (255, 255, 255)
        MUTED = (95, 99, 104)

        # top bar
        pygame.draw.rect(surface, CARD, (0, 0, w, 52))
        pygame.draw.line(surface, (218, 220, 224), (0, 52), (w, 52), 1)
        title = self.app.font("ui", 18, bold=True).render(
            "Tile Market", True, PLAY_GREEN)
        surface.blit(title, (190, 14))

        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 13, bold=True), animations=anim)

        # search
        self.search.set_rect(pygame.Rect(12, 60, w - 24, 44))
        # белая капсула
        pygame.draw.rect(surface, CARD, self.search.rect, border_radius=22)
        pygame.draw.rect(surface, (218, 220, 224), self.search.rect, 1, border_radius=22)
        self.search.draw(surface, self.app.font("ui", 14))

        # categories chips
        cats = ["все", "игры", "утилиты", "система"]
        self.cat_rects = []
        cx = 12
        cf = self.app.font("ui", 12, bold=True)
        for cat in cats:
            tw = cf.size(cat)[0] + 28
            r = pygame.Rect(cx, 114, tw, 32)
            active = self.category == cat
            if active:
                pygame.draw.rect(surface, PLAY_GREEN, r, border_radius=16)
                tc = (255, 255, 255)
            else:
                pygame.draw.rect(surface, CARD, r, border_radius=16)
                pygame.draw.rect(surface, (218, 220, 224), r, 1, border_radius=16)
                tc = PLAY_DARK
            surface.blit(cf.render(cat, True, tc), (r.x + 14, r.y + 7))
            self.cat_rects.append((r, cat))
            cx += tw + 8

        content_top = 156
        y = content_top - self.scroll
        self.row_rects = []
        lf = self.app.font("ui", 15, bold=True)
        sf = self.app.font("ui", 12)
        tiny = self.app.font("ui", 11)

        # Featured banner
        if self.filtered:
            fi = self.featured_i % len(self.filtered)
            feat = self.filtered[fi]
            ban = pygame.Rect(12, y, w - 24, self.FEATURED_H)
            if ban.bottom > content_top - 20 and ban.top < h - NAV_BAR_H:
                col = self._icon_color(feat)
                pygame.draw.rect(surface, col, ban, border_radius=18)
                # soft overlay
                overlay = pygame.Surface((ban.w, ban.h), pygame.SRCALPHA)
                overlay.fill((0, 0, 0, 40))
                surface.blit(overlay, ban.topleft)
                surface.blit(self.app.font("ui", 12, bold=True).render(
                    "РЕКОМЕНДУЕМ", True, (255, 255, 255)), (ban.x + 18, ban.y + 16))
                surface.blit(self.app.font("ui", 22, bold=True).render(
                    truncate_text(feat["name"], self.app.font("ui", 22, bold=True), ban.w - 40),
                    True, (255, 255, 255)), (ban.x + 18, ban.y + 42))
                desc = str(feat.get("description") or feat.get("category") or "Приложение Tile")
                surface.blit(sf.render(truncate_text(desc, sf, ban.w - 40), True,
                                       (230, 240, 235)), (ban.x + 18, ban.y + 78))
                # open button on banner
                br = pygame.Rect(ban.right - 110, ban.bottom - 44, 96, 32)
                pygame.draw.rect(surface, (255, 255, 255), br, border_radius=16)
                surface.blit(tiny.render("Открыть", True, col),
                             tiny.render("Открыть", True, col).get_rect(center=br.center))
                self.row_rects.append((br, feat, "open"))
            y += self.FEATURED_H + 18

        # section title
        if y + 20 > content_top - 10:
            surface.blit(lf.render("Все приложения", True, PLAY_DARK), (16, y))
        y += 28

        if not self.filtered:
            surface.blit(sf.render(
                "Нет приложений. Положите .py или папку в market/",
                True, MUTED), (20, max(y, content_top + 40)))

        for info in self.filtered:
            card = pygame.Rect(12, y, w - 24, self.CARD_H)
            if card.bottom >= content_top - 4 and card.top <= h - NAV_BAR_H:
                pygame.draw.rect(surface, CARD, card, border_radius=16)
                # icon
                ic = pygame.Rect(card.x + 12, card.y + 14, 60, 60)
                pygame.draw.rect(surface, self._icon_color(info), ic, border_radius=14)
                icon = str(info.get("icon") or info["name"][:1]).upper()[:2]
                letter = self.app.font("ui", 22, bold=True).render(icon, True, (255, 255, 255))
                surface.blit(letter, letter.get_rect(center=ic.center))

                nx = card.x + 86
                surface.blit(lf.render(
                    truncate_text(info["name"], lf, w - 220), True, PLAY_DARK),
                    (nx, card.y + 14))
                cat = str(info.get("category") or "утилиты")
                kind = {"folder": "Папка", "plugin": "Плагин", "py": "Скрипт"}.get(
                    info.get("type", "py"), "Приложение")
                surface.blit(sf.render(f"{kind} · {cat}", True, MUTED),
                             (nx, card.y + 38))
                rating = self._fake_rating(info)
                surface.blit(tiny.render(f"★ {rating}  ·  {info.get('size', '')}",
                                         True, MUTED), (nx, card.y + 58))

                installed = self._is_on_desktop(info)
                btn_label = "Открыть" if installed else "Установить"
                bw = 100
                br = pygame.Rect(card.right - bw - 14, card.y + (self.CARD_H - 36) // 2,
                                 bw, 36)
                if installed:
                    pygame.draw.rect(surface, (232, 240, 254), br, border_radius=18)
                    pygame.draw.rect(surface, (66, 133, 244), br, 1, border_radius=18)
                    bc = (66, 133, 244)
                    act = "open"
                else:
                    pygame.draw.rect(surface, PLAY_GREEN, br, border_radius=18)
                    bc = (255, 255, 255)
                    act = "install"
                surface.blit(sf.render(btn_label, True, bc),
                             sf.render(btn_label, True, bc).get_rect(center=br.center))
                self.row_rects.append((br, info, act))
                # card area for hold
                self.row_rects.append((card, info, "card"))
            y += self.CARD_H + 10

        self.max_scroll = max(0, y + self.scroll - (h - NAV_BAR_H - 8) - content_top + 160)

        # hold → install bar
        self._add_rect = None
        if self._hold_active and self._hold_info:
            bw, bh = min(w - 40, 340), 52
            self._add_rect = pygame.Rect((w - bw) // 2, h - NAV_BAR_H - bh - 12, bw, bh)
            pygame.draw.rect(surface, PLAY_GREEN, self._add_rect, border_radius=26)
            tf = self.app.font("ui", 14, bold=True)
            ts = tf.render("Установить на рабочий стол", True, (255, 255, 255))
            surface.blit(ts, ts.get_rect(center=self._add_rect.center))

        self._needs_redraw = False


# ============================================================================
# ОБОИ
# ============================================================================
# ============================================================================
# ОБОИ
# ============================================================================

class WallpaperScreen(BaseScreen):
    def __init__(self, app):
        super().__init__(app)
        self.buttons = [
            TouchButton("Назад", app.back_to_menu,
                        color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 80, 36)),
        ]
        self.item_rects: List[Tuple[pygame.Rect, str]] = []

    def handle_event(self, event):
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return
        for b in self.buttons:
            if b.handle_event(event):
                return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for rect, key in self.item_rects:
                if rect.collidepoint(event.pos):
                    self.app.settings.set("wallpaper", key)
                    try:
                        self.app.tile_screen._bg_surface = None
                        self.app.tile_screen.pinch_panel = False
                    except Exception:
                        pass
                    self.app.toast(f"Обои: {key}")
                    self.app.show_screen("menu")
                    return

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(PANEL_BG)
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)
        title = self.app.font("ui", 18, bold=True).render(
            "Обои", True, TEXT_BRIGHT)
        surface.blit(title, (16, 50))
        self.item_rects = []
        y = 90
        cur = self.app.settings.get("wallpaper", "default")
        for key in WALLPAPERS:
            rect = pygame.Rect(12, y, w - 24, 48)
            self.item_rects.append((rect, key))
            grads = WALLPAPERS[key]
            if grads is None:
                c1, c2 = BG_GRAD_TOP, BG_GRAD_BOTTOM
            else:
                c1, c2 = grads
            pygame.draw.rect(surface, c1, rect, border_radius=8)
            pygame.draw.rect(surface, c2,
                             pygame.Rect(rect.centerx, rect.y,
                                         rect.w // 2, rect.h),
                             border_radius=8)
            if key == cur:
                pygame.draw.rect(surface, ACCENT, rect, width=3,
                                 border_radius=8)
            lbl = self.app.font("ui", 14, bold=True).render(
                key, True, (255, 255, 255))
            surface.blit(lbl, (rect.x + 14, rect.y + 14))
            y += 56


# ============================================================================
# НАСТРОЙКИ ЭКРАНА
# ============================================================================

class ScreenSettingsScreen(BaseScreen):
    def __init__(self, app):
        super().__init__(app)
        self.buttons = [
            TouchButton("Назад", app.back_to_menu,
                        color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 80, 36)),
            TouchButton("Правка", self._toggle_edit,
                        color=(60, 120, 180),
                        rect=pygame.Rect(92, 6, 90, 36)),
        ]
        self.row_rects: List[Tuple[pygame.Rect, str]] = []

    def _toggle_edit(self):
        ts = self.app.tile_screen
        ts.edit_mode = not ts.edit_mode
        ts.pinch_panel = False
        self.app.toast(
            "Режим правки: вкл" if ts.edit_mode else "Режим правки: выкл")
        if ts.edit_mode:
            self.app.show_screen("menu")

    def handle_event(self, event):
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return
        for b in self.buttons:
            if b.handle_event(event):
                return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for rect, key in self.row_rects:
                if not rect.collidepoint(event.pos):
                    continue
                if key == "grid":
                    cur = int(self.app.settings.get("grid_cols", 4))
                    nxt = 5 if cur == 4 else 4
                    self.app.settings.set("grid_cols", nxt)
                    self.app.tile_screen.rebuild()
                    self.app.toast(f"Сетка: {nxt} столбцов")
                elif key == "scale":
                    cur = float(self.app.settings.get("icon_scale", 1.0))
                    opts = [0.8, 1.0, 1.2]
                    try:
                        i = opts.index(round(cur, 1))
                    except ValueError:
                        i = 1
                    nxt = opts[(i + 1) % len(opts)]
                    self.app.settings.set("icon_scale", nxt)
                    self.app.tile_screen.rebuild()
                    self.app.toast(f"Размер значков: {int(nxt * 100)}%")
                return

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(PANEL_BG)
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)
        title = self.app.font("ui", 18, bold=True).render(
            "Настройка экрана", True, TEXT_BRIGHT)
        surface.blit(title, (16, 50))
        self.row_rects = []
        items = [
            ("grid", "Сетка",
             f"{self.app.settings.get('grid_cols', 4)} столбцов (4/5)"),
            ("scale", "Размер значков",
             f"{int(float(self.app.settings.get('icon_scale', 1.0)) * 100)}%"),
        ]
        y = 100
        lf = self.app.font("ui", 14)
        vf = self.app.font("mono", 13)
        for key, label, val in items:
            rect = pygame.Rect(8, y, w - 16, 52)
            self.row_rects.append((rect, key))
            pygame.draw.rect(surface, ROW_ALT, rect, border_radius=8)
            surface.blit(lf.render(label, True, TEXT_BRIGHT),
                         (rect.x + 14, rect.y + 8))
            surface.blit(vf.render(val, True, ACCENT),
                         (rect.x + 14, rect.y + 28))
            y += 60
        hint = self.app.font("ui", 12).render(
            "«Правка» — на главном экране удалять и менять размер плиток",
            True, TEXT_DIM)
        surface.blit(hint, (14, y + 10))


# ============================================================================
# УПРАВЛЕНИЕ ПРИЛОЖЕНИЯМИ
# ============================================================================

class AppsManageScreen(BaseScreen):
    """Скрыть/показать приложения, сменить размер плитки."""

    def __init__(self, app):
        super().__init__(app)
        self.rows: List[Dict[str, Any]] = []
        self.row_rects: List[pygame.Rect] = []
        self.buttons = [
            TouchButton("Назад", lambda: app.show_screen("settings"),
                        color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 80, 36)),
        ]
        self._reload()

    def _reload(self) -> None:
        hidden = set(self.app.settings.get("hidden_tiles") or [])
        sizes = self.app.settings.get("tile_sizes") or {}
        defs = self.app.tile_screen._all_app_defs()
        self.rows = []
        for a in sorted(defs, key=lambda x: x["label"].lower()):
            tag = a["tag"]
            protected = is_protected_tag(tag)
            is_hidden = tag in hidden and not protected
            sz = sizes.get(tag, {"cols": a["cols"], "rows": a["rows"]})
            self.rows.append({
                "tag": tag,
                "label": a["label"],
                "protected": protected,
                "hidden": is_hidden,
                "cols": int(sz.get("cols", a["cols"])),
                "rows": int(sz.get("rows", a["rows"])),
            })

    def _toggle_hide(self, tag: str) -> None:
        if is_protected_tag(tag):
            self.app.toast("Системное — нельзя удалить", WARNING)
            return
        hidden = list(self.app.settings.get("hidden_tiles") or [])
        if tag in hidden:
            hidden = [t for t in hidden if t != tag]
            self.app.toast("Установлено", SUCCESS)
        else:
            hidden.append(tag)
            self.app.toast("Удалено с экрана", SUCCESS)
        self.app.settings.set("hidden_tiles", hidden)
        self.app.tile_screen.rebuild()
        self._reload()

    def _cycle_size(self, tag: str) -> None:
        sizes = dict(self.app.settings.get("tile_sizes") or {})
        cur = sizes.get(tag, {"cols": 1, "rows": 1})
        presets = [(1, 1), (2, 1), (1, 2), (2, 2)]
        try:
            idx = presets.index((cur.get("cols", 1), cur.get("rows", 1)))
        except ValueError:
            idx = 0
        nc, nr = presets[(idx + 1) % len(presets)]
        sizes[tag] = {"cols": nc, "rows": nr}
        self.app.settings.set("tile_sizes", sizes)
        self.app.tile_screen.rebuild()
        self._reload()
        self.app.toast(f"Размер {nc}×{nr}")

    def handle_event(self, event):
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return
        for b in self.buttons:
            if b.handle_event(event):
                return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for i, rect in enumerate(self.row_rects):
                if not rect.collidepoint(event.pos):
                    continue
                row = self.rows[i]
                # левая половина — hide, правая — size
                if event.pos[0] < rect.centerx:
                    self._toggle_hide(row["tag"])
                else:
                    self._cycle_size(row["tag"])
                return

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(PANEL_BG)
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)

        title = self.app.font("ui", 18, bold=True).render(
            "Приложения", True, TEXT_BRIGHT)
        surface.blit(title, (16, 48))
        hint = self.app.font("ui", 11).render(
            "слева — удалить/установить · справа — размер", True, TEXT_DIM)
        surface.blit(hint, (16, 72))

        y = 100
        row_h = 48
        self.row_rects = []
        lf = self.app.font("ui", 14)
        sf = self.app.font("mono", 12)
        for i, row in enumerate(self.rows):
            rect = pygame.Rect(6, y, w - 12, row_h - 4)
            self.row_rects.append(rect)
            if i % 2:
                pygame.draw.rect(surface, ROW_ALT, rect, border_radius=6)
            status = "сист." if row["protected"] else (
                "скрыто" if row["hidden"] else "на экране")
            color = WARNING if row["protected"] else (
                ERROR if row["hidden"] else SUCCESS)
            ls = lf.render(row["label"], True, TEXT_BRIGHT)
            surface.blit(ls, (rect.x + 12, rect.y + 12))
            st = sf.render(status, True, color)
            surface.blit(st, (rect.x + 160, rect.y + 14))
            sz = sf.render(f"{row['cols']}×{row['rows']}", True, ACCENT)
            surface.blit(sz, (rect.right - sz.get_width() - 12, rect.y + 14))
            y += row_h


# ============================================================================
# НАСТРОЙКИ
# ============================================================================

class SettingsScreen(BaseScreen):
    ROW_H = 50
    ROW_TOP = 56

    def __init__(self, app):
        super().__init__(app)
        self.items: List[Dict[str, Any]] = []
        self.buttons = [
            TouchButton("Назад", app.back_to_menu,
                        color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 80, 36)),
            TouchButton("Сброс", self._reset,
                        color=(170, 60, 60),
                        rect=pygame.Rect(90, 6, 80, 36)),
        ]
        self.row_rects: List[pygame.Rect] = []
        self.edit_input: Optional[TextInput] = None
        self.editing_key: Optional[str] = None
        self._build_items()

    def apply_text_input(self, text: str) -> None:
        if self.edit_input is not None and self.edit_input.active:
            for ch in text:
                self.edit_input.insert(ch)

    def _build_items(self):
        s = self.app.settings
        theme = s.get("theme", "dark")
        self.items = [
            {"key": "fps", "label": "FPS", "type": "int",
             "value": s.get("fps", 30)},
            {"key": "animations", "label": "Анимации", "type": "bool",
             "value": s.get("animations", True)},
            {"key": "confirm_exit", "label": "Спрашивать выход",
             "type": "bool", "value": s.get("confirm_exit", True)},
            {"key": "android_auto", "label": "Android Auto",
             "type": "bool", "value": s.get("android_auto", False)},
            {"key": "developer_mode", "label": "Режим разработчика",
             "type": "bool", "value": s.get("developer_mode", False)},
            {"key": "dev_auto_usb", "label": "Dev-режим при USB",
             "type": "bool", "value": s.get("dev_auto_usb", True)},
            {"key": "editor_tab_size", "label": "Размер таба",
             "type": "int", "value": s.get("editor_tab_size", 4)},
            {"key": "browse_path", "label": "Папка проводника",
             "type": "str", "value": s.get("browse_path", "")},
            {"key": "theme", "label": "Темы", "type": "cycle",
             "value": THEME_LABELS.get(theme, theme),
             "options": list(THEMES.keys())},
            {"key": "sysinfo", "label": "О системе", "type": "action",
             "value": TILE_OS_NAME},
            {"key": "deviceinfo", "label": "О телефоне", "type": "action",
             "value": "сведения"},
            {"key": "apps", "label": "Приложения", "type": "action",
             "value": "управление"},
        ]

    def _cycle_theme(self) -> None:
        keys = list(THEMES.keys())
        cur = self.app.settings.get("theme", "dark")
        try:
            idx = keys.index(cur)
        except ValueError:
            idx = 0
        nxt = keys[(idx + 1) % len(keys)]
        self.app.settings.set("theme", nxt)
        # сброс кэша фона меню
        try:
            self.app.tile_screen._bg_surface = None
        except Exception:
            pass
        self._build_items()
        self.app.toast(f"Тема: {THEME_LABELS.get(nxt, nxt)}")
        self.app._needs_redraw = True

    def _reset(self):
        for k, v in DEFAULT_SETTINGS.items():
            self.app.settings.set(k, v)
        apply_theme(self.app.settings.get("theme", "dark"))
        try:
            self.app.tile_screen._bg_surface = None
        except Exception:
            pass
        self._build_items()
        self.app.toast("Сброшено")

    def _start_edit(self, key: str):
        item = next((i for i in self.items if i["key"] == key), None)
        if not item:
            return
        self.editing_key = key
        self.edit_input = TextInput(
            pygame.Rect(6, self.app.screen.get_height()
                        - (self.app.vk.rect.height if self.app.vk.visible
                           else 0) - 54 - NAV_BAR_H,
                        self.app.screen.get_width() - 12, 46),
            placeholder=str(item["value"]),
            on_submit=self._commit_edit, app=self.app)
        self.edit_input.text = str(item["value"])
        self.edit_input.focus()

    def _commit_edit(self, text: str):
        if not self.editing_key:
            return
        item = next((i for i in self.items if i["key"] == self.editing_key),
                    None)
        if not item:
            self.editing_key = None
            return
        try:
            if item["type"] == "int":
                value = int(text)
            else:
                value = text
        except ValueError:
            self.app.toast("Некорректное значение", ERROR)
            self.editing_key = None
            self.edit_input = None
            self.app.clear_text_focus()
            return
        item["value"] = value
        self.app.settings.set(item["key"], value)
        item["value"] = self.app.settings.get(item["key"])
        self.editing_key = None
        self.edit_input = None
        self.app.clear_text_focus()
        self.app.toast(f"{item['label']} = {item['value']}")
        LOG.info("SETTINGS", f"{item['key']} = {item['value']}")

    def handle_event(self, event):
        super().handle_event(event)

        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return

        if self.edit_input is not None:
            if self.edit_input.handle_event(event):
                return

        for b in self.buttons:
            if b.handle_event(event):
                return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for idx, rect in enumerate(self.row_rects):
                if rect.collidepoint(event.pos):
                    if idx >= len(self.items):
                        return
                    item = self.items[idx]
                    if item["type"] == "bool":
                        new_val = not bool(item["value"])
                        item["value"] = new_val
                        self.app.settings.set(item["key"], new_val)
                        self.app.toast(f"{item['label']}: "
                                       f"{'вкл' if new_val else 'выкл'}")
                        LOG.info("SETTINGS",
                                 f"{item['key']} = {new_val}")
                        if item["key"] == "android_auto":
                            self.app.apply_android_auto(new_val)
                    elif item["type"] == "cycle" and item["key"] == "theme":
                        self._cycle_theme()
                    elif item["type"] == "action":
                        if item["key"] == "sysinfo":
                            self.app.info_screen.open(
                                "О системе", get_system_info())
                            self.app.show_screen("info")
                        elif item["key"] == "deviceinfo":
                            self.app.info_screen.open(
                                "О телефоне", get_device_info())
                            self.app.show_screen("info")
                        elif item["key"] == "apps":
                            self.app.apps_screen._reload()
                            self.app.show_screen("apps")
                    else:
                        self._start_edit(item["key"])
                    return

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)
        if self.edit_input:
            self.edit_input.update(dt)

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(PANEL_BG)
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)

        y = self.ROW_TOP
        label_font = self.app.font("ui", 14)
        value_font = self.app.font("mono", 13)

        self.row_rects = []
        for i, item in enumerate(self.items):
            row = pygame.Rect(6, y, w - 12, self.ROW_H - 6)
            self.row_rects.append(row)

            if i % 2 == 1:
                pygame.draw.rect(surface, ROW_ALT, row, border_radius=6)

            ls = label_font.render(item["label"], True, TEXT_BRIGHT)
            surface.blit(ls, (row.x + 12, row.y + 10))

            if item["type"] == "bool":
                val = "вкл" if item["value"] else "выкл"
                color = SUCCESS if item["value"] else ERROR
            else:
                val = str(item["value"])
                color = TEXT_DIM
            vs = value_font.render(truncate_text(val, value_font, 200),
                                   True, color)
            surface.blit(vs, (row.right - vs.get_width() - 12, row.y + 12))

            y += self.ROW_H

        hint_font = self.app.font("ui", 11)
        hint = hint_font.render(
            "Тап по строке — переключить или изменить",
            True, TEXT_DIM
        )
        surface.blit(hint, (14, y + 12))

        if self.edit_input is not None:
            vk_h = self.app.vk.rect.height if self.app.vk.visible else 0
            input_rect = pygame.Rect(6, h - vk_h - 54 - NAV_BAR_H,
                                     w - 12, 46)
            self.edit_input.set_rect(input_rect)
            self.edit_input.draw(surface, self.app.font("mono", 14))


# ============================================================================
# ИНФО (О системе / О телефоне)
# ============================================================================

class InfoScreen(BaseScreen):
    def __init__(self, app):
        super().__init__(app)
        self.title = ""
        self.rows: List[Tuple[str, str]] = []
        self.scroll = 0
        self.buttons = [
            TouchButton("Назад", lambda: app.show_screen("settings"),
                        color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 80, 36)),
            TouchButton("Обновить", self._reload,
                        color=(60, 120, 180),
                        rect=pygame.Rect(92, 6, 100, 36)),
        ]
        self._mode = "system"

    def open(self, title: str, rows: List[Tuple[str, str]]) -> None:
        self.title = title
        self.rows = rows
        self.scroll = 0
        self._mode = "system" if "систем" in title.lower() else "device"

    def _reload(self) -> None:
        if self._mode == "system":
            self.rows = get_system_info()
        else:
            self.rows = get_device_info()
        self.app.toast("Обновлено")

    def handle_event(self, event):
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return
        for b in self.buttons:
            if b.handle_event(event):
                return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.dragging = True
            self.drag_start_y = event.pos[1]
            self.drag_start_scroll = self.scroll
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            dy = event.pos[1] - self.drag_start_y
            if abs(dy) > 6:
                self.scroll = max(0, self.drag_start_scroll - dy)

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(PANEL_BG)
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)

        title_font = self.app.font("ui", 18, bold=True)
        t = title_font.render(self.title, True, TEXT_BRIGHT)
        surface.blit(t, (16, 50))

        key_font = self.app.font("ui", 13)
        val_font = self.app.font("mono", 12)
        row_h = 36
        top = 90
        bottom = h - NAV_BAR_H - 10
        visible = max(1, (bottom - top) // row_h)
        max_scroll = max(0, (len(self.rows) - visible) * row_h)
        self.scroll = max(0, min(self.scroll, max_scroll))

        prev = surface.get_clip()
        surface.set_clip(pygame.Rect(0, top, w, bottom - top))
        y = top - self.scroll
        for i, (key, val) in enumerate(self.rows):
            if y + row_h < top:
                y += row_h
                continue
            if y > bottom:
                break
            if i % 2 == 1:
                pygame.draw.rect(surface, ROW_ALT,
                                 pygame.Rect(6, y, w - 12, row_h - 4),
                                 border_radius=4)
            ks = key_font.render(key, True, TEXT_DIM)
            surface.blit(ks, (16, y + 8))
            vs = val_font.render(truncate_text(str(val), val_font, w // 2),
                                 True, TEXT_BRIGHT)
            surface.blit(vs, (w - vs.get_width() - 16, y + 8))
            y += row_h
        surface.set_clip(prev)


# ============================================================================
# О ПРОГРАММЕ
# ============================================================================

class AboutScreen(BaseScreen):
    def __init__(self, app):
        super().__init__(app)
        self.buttons = [
            TouchButton("Назад", app.back_to_menu,
                        color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 80, 36)),
        ]

    def handle_event(self, event):
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return
        for b in self.buttons:
            if b.handle_event(event):
                return

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(PANEL_BG)
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)

        title_font = self.app.font("ui", 24, bold=True)
        t = title_font.render(APP_NAME, True, TEXT_BRIGHT)
        surface.blit(t, (16, 60))

        lines = [
            f"Система: {TILE_OS_NAME}",
            f"Лаунчер: {APP_VERSION}",
            "",
            f"Python: {sys.version.split()[0]}",
            f"pygame: {pygame.version.ver}",
            f"Платформа: {sys.platform}",
            f"Android: {IS_ANDROID}",
            f"Проект: {PROJECT_DIR}",
            "",
            "В RunScreen:",
            "  поле ввода → отправка строк в input()",
            "  кнопка Отправить",
        ]
        font = self.app.font("ui", 12)
        y = 110
        for line in lines:
            s = font.render(line, True, TEXT_BRIGHT)
            surface.blit(s, (16, y))
            y += 20


# ============================================================================
# ПРОВЕРКА ОКРУЖЕНИЯ
# ============================================================================

class EnvScreen(BaseScreen):
    def __init__(self, app):
        super().__init__(app)
        self.checks = []
        self.buttons = [
            TouchButton("Назад", app.back_to_menu,
                        color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 80, 36)),
            TouchButton("Повтор", self._run,
                        color=(60, 140, 100),
                        rect=pygame.Rect(90, 6, 90, 36)),
        ]
        self._run()

    def _run(self):
        self.checks = []
        add = lambda n, ok, d: self.checks.append(
            {"name": n, "ok": ok, "detail": d})

        add("Python", True, sys.version.split()[0])
        add("pygame", True, pygame.version.ver)
        add("Платформа", True, sys.platform)
        add("Android", IS_ANDROID, str(IS_ANDROID))
        add("Хранилище", ANDROID_STORAGE.exists(), str(ANDROID_STORAGE))
        add("Download", ANDROID_DOWNLOADS.exists(), str(ANDROID_DOWNLOADS))
        add("DCIM", ANDROID_DCIM.exists(), str(ANDROID_DCIM))
        add("Documents", ANDROID_DOCUMENTS.exists(), str(ANDROID_DOCUMENTS))

        try:
            import pyperclip  # noqa
            add("pyperclip", True, "доступен")
        except ImportError:
            add("pyperclip", False, "pip install pyperclip")

        try:
            test = PROJECT_DIR / ".test_write"
            test.write_text("ok", encoding="utf-8")
            test.unlink()
            add("Запись", True, str(PROJECT_DIR))
        except Exception as e:
            add("Запись", False, str(e))

    def handle_event(self, event):
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return
        for b in self.buttons:
            if b.handle_event(event):
                return

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(PANEL_BG)
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)

        name_font = self.app.font("ui", 13, bold=True)
        detail_font = self.app.font("mono", 11)
        y = 54
        for check in self.checks:
            tag = "OK" if check["ok"] else "FAIL"
            color = SUCCESS if check["ok"] else ERROR
            tag_surf = name_font.render(tag, True, color)
            surface.blit(tag_surf, (10, y))

            ns = name_font.render(check["name"], True, TEXT_BRIGHT)
            surface.blit(ns, (60, y))

            detail = truncate_text(check["detail"], detail_font, w - 70)
            ds = detail_font.render(detail, True, TEXT_DIM)
            surface.blit(ds, (60, y + 18))
            y += 42


# ============================================================================
# README
# ============================================================================

class ReadmeScreen(BaseScreen):
    def __init__(self, app):
        super().__init__(app)
        self.lines = []
        self.buttons = [
            TouchButton("Назад", app.back_to_menu,
                        color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 80, 36)),
            TouchButton("Обновить", self._load,
                        color=(60, 120, 180),
                        rect=pygame.Rect(90, 6, 100, 36)),
        ]
        self._ensure()
        self._load()

    def _ensure(self):
        readme = PROJECT_DIR / "README.md"
        if not readme.exists():
            try:
                readme.write_text(
                    f"# {APP_NAME}\n\nВерсия {APP_VERSION}\n\n"
                    "## Что нового\n\n"
                    "* Поле ввода stdin в RunScreen — input() работает.\n"
                    "* Кнопка Отправить в RunScreen.\n",
                    encoding="utf-8")
            except Exception:
                pass

    def _load(self):
        try:
            readme = PROJECT_DIR / "README.md"
            if readme.exists():
                text = readme.read_text(encoding="utf-8")
                self.lines = text.split("\n")
            else:
                self.lines = ["README.md не найден"]
        except Exception as e:
            self.lines = [f"Ошибка: {e}"]

    def handle_event(self, event):
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return
        for b in self.buttons:
            if b.handle_event(event):
                return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.dragging = True
            self.drag_start_y = event.pos[1]
            self.drag_start_scroll = self.scroll
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            dy = event.pos[1] - self.drag_start_y
            if abs(dy) > 6:
                self.scroll = max(0, self.drag_start_scroll - dy)

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(PANEL_BG)
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)

        body = pygame.Rect(6, 50, w - 12, h - 56 - NAV_BAR_H)
        pygame.draw.rect(surface, (14, 16, 22), body, border_radius=6)

        font = self.app.font("mono", 12)
        line_h = font.get_linesize()
        visible = body.height // line_h
        total = len(self.lines)
        self.max_scroll = max(0, total - visible)
        self.scroll = min(self.scroll, self.max_scroll)

        start = self.scroll
        end = min(total, start + visible + 1)
        prev_clip = surface.get_clip()
        surface.set_clip(body.inflate(-6, -6))

        y = body.y + 6
        for i in range(start, end):
            line = self.lines[i]
            color = ACCENT if line.startswith("#") else TEXT_BRIGHT
            text = truncate_text(line, font, body.width - 20)
            s = font.render(text, True, color)
            surface.blit(s, (body.x + 10, y))
            y += line_h
        surface.set_clip(prev_clip)


