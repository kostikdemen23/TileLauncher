#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Виртуальная клавиатура и буфер обмена."""
from __future__ import annotations

from typing import Any, List, Tuple

import pygame

from tl_core import NAV_BAR_H, PANEL_BORDER, TEXT_BRIGHT, WARNING, SUCCESS, dbg

# ============================================================================
# ВИРТУАЛЬНАЯ КЛАВИАТУРА
# ============================================================================


def read_clipboard() -> str:
    """Текст из буфера обмена (Android / pygame / tk)."""
    # 1) Android ClipboardManager
    try:
        from jnius import autoclass
        activity = None
        for name in (
            "org.libsdl.app.SDLActivity",
            "org.kivy.android.PythonActivity",
            "org.renpy.android.PythonActivity",
        ):
            try:
                cls = autoclass(name)
                activity = getattr(cls, "mSingleton", None) or getattr(cls, "mActivity", None)
                if activity is not None:
                    break
            except Exception:
                continue
        if activity is not None:
            Context = autoclass("android.content.Context")
            cm = activity.getSystemService(Context.CLIPBOARD_SERVICE)
            clip = cm.getPrimaryClip()
            if clip is not None and clip.getItemCount() > 0:
                item = clip.getItemAt(0)
                # coerceToText needs context
                txt = item.coerceToText(activity)
                if txt is not None:
                    return str(txt)
                if item.getText() is not None:
                    return str(item.getText())
    except Exception:
        pass
    # 2) pygame 2 (если есть)
    try:
        if hasattr(pygame, "scrap") and pygame.scrap.get_init():
            data = pygame.scrap.get(pygame.SCRAP_TEXT)
            if data:
                if isinstance(data, bytes):
                    return data.decode("utf-8", errors="ignore")
                return str(data)
    except Exception:
        pass
    try:
        pygame.scrap.init()
        data = pygame.scrap.get(pygame.SCRAP_TEXT)
        if data:
            if isinstance(data, bytes):
                return data.decode("utf-8", errors="ignore")
            return str(data)
    except Exception:
        pass
    # 3) tkinter
    try:
        import tkinter as tk
        r = tk.Tk()
        r.withdraw()
        txt = r.clipboard_get()
        r.destroy()
        return str(txt)
    except Exception:
        pass
    return ""


class VirtualKeyboard:
    """Клавиатура как на Android: RU / EN / символы."""

    def __init__(self) -> None:
        self.app = None
        self.rect = pygame.Rect(0, 0, 1, 1)
        self.visible = False
        self.btn_rects: List[Tuple[pygame.Rect, str]] = []
        self.key_h = 46
        self.key_gap = 6
        self.layout = "ru"  # ru | en | sym
        self.shift = False

    def show(self) -> None:
        self.visible = True

    def hide(self) -> None:
        self.visible = False

    def _letter_rows(self) -> List[List[str]]:
        if self.layout == "ru":
            rows = [
                list("1234567890"),
                list("йцукенгшщзхъ"),
                list("фывапролджэ"),
                list("ячсмитьбю"),
            ]
        elif self.layout == "en":
            rows = [
                list("1234567890"),
                list("qwertyuiop"),
                list("asdfghjkl"),
                list("zxcvbnm"),
            ]
        else:  # sym
            rows = [
                list("1234567890"),
                list("@#₽%&-+()"),
                list("*\"':;!/?"),
                list("=<>[]{}"),
            ]
        if self.shift and self.layout in ("ru", "en"):
            rows = [[c.upper() if c.isalpha() else c for c in row] for row in rows]
        return rows

    def handle_event(self, event: pygame.event.Event) -> bool:
        if not self.visible:
            return False
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for rect, key in self.btn_rects:
                if rect.collidepoint(event.pos):
                    self._press(key)
                    return True
            if self.rect.collidepoint(event.pos):
                return True
        return False

    def _press(self, key: str) -> None:
        if self.app is None:
            return
        if key == "SYM":
            self.layout = "sym"
            self.shift = False
            self.app._needs_redraw = True
            return
        if key == "LANG":
            if self.layout == "sym":
                self.layout = "ru"
            else:
                order = ["ru", "en"]
                try:
                    i = order.index(self.layout)
                except ValueError:
                    i = 0
                self.layout = order[(i + 1) % 2]
            self.shift = False
            self.app._needs_redraw = True
            return
        if key == "SHIFT":
            self.shift = not self.shift
            self.app._needs_redraw = True
            return
        target = self.app.text_focus
        if target is None:
            # если фокус на plugin host — пробуем plugin
            try:
                cur = self.app.screens.get(self.app.current_screen)
                if cur is not None and hasattr(cur, "plugin") and cur.plugin is not None:
                    target = cur.plugin
            except Exception:
                pass
        if target is None:
            return
        try:
            if key == "BACK":
                if hasattr(target, "backspace"):
                    target.backspace()
                elif hasattr(target, "apply_text_input"):
                    pass
            elif key == "ENTER":
                if hasattr(target, "submit"):
                    target.submit()
                elif hasattr(target, "on_submit") and callable(target.on_submit):
                    target.on_submit(getattr(target, "text", ""))
            elif key == "SPACE":
                self._insert(target, " ")
            elif key == "PASTE":
                clip = read_clipboard()
                if not clip:
                    try:
                        self.app.toast("Буфер пуст", WARNING)
                    except Exception:
                        pass
                else:
                    # ограничение длины
                    clip = clip.replace("\x00", "")[:4000]
                    self._insert(target, clip)
                    try:
                        self.app.toast(f"Вставлено {len(clip)} симв.", SUCCESS)
                    except Exception:
                        pass
            elif key == ",":
                self._insert(target, ",")
            elif key == ".":
                self._insert(target, ".")
            else:
                ch = key
                if self.layout in ("ru", "en") and len(ch) == 1 and ch.isalpha():
                    ch = ch.upper() if self.shift else ch.lower()
                self._insert(target, ch)
                if self.shift and self.layout in ("ru", "en"):
                    self.shift = False
                    self.app._needs_redraw = True
        except Exception as e:
            dbg("VK press error:", e)
        try:
            self.app._needs_redraw = True
        except Exception:
            pass

    def _insert(self, target: Any, ch: str) -> None:
        if hasattr(target, "insert"):
            target.insert(ch)
        elif hasattr(target, "apply_text_input"):
            target.apply_text_input(ch)
        elif hasattr(target, "text"):
            target.text = str(getattr(target, "text", "")) + ch

    def draw(self, surface: pygame.Surface) -> None:
        if not self.visible or self.app is None:
            return
        w, h = surface.get_size()
        letter_rows = self._letter_rows()
        # 4 ряда букв + 1 ряд спец
        n_rows = len(letter_rows) + 1
        pad_x = 5
        pad_y = 6
        total_h = n_rows * (self.key_h + self.key_gap) + pad_y * 2
        self.rect = pygame.Rect(0, h - total_h - NAV_BAR_H, w, total_h)

        # светлый фон как на системной клавиатуре
        pygame.draw.rect(surface, (210, 214, 220), self.rect)
        pygame.draw.line(surface, (180, 184, 190),
                         (0, self.rect.y), (w, self.rect.y), 1)

        self.btn_rects.clear()
        font = self.app.font("ui", 17, bold=True)
        sfont = self.app.font("ui", 13, bold=True)

        def draw_key(x, y, kw, label, code, wide=False):
            rect = pygame.Rect(int(x), int(y), int(kw), self.key_h)
            # цвета
            if code == "ENTER":
                bg, fg = (66, 133, 244), (255, 255, 255)
            elif code == "PASTE":
                bg, fg = (80, 140, 100), (255, 255, 255)
            elif code in ("BACK", "SHIFT") and (code != "SHIFT" or self.shift):
                bg = (160, 165, 175) if code == "BACK" else ((120, 160, 220) if self.shift else (160, 165, 175))
                fg = (30, 30, 30)
            elif code in ("LANG", "SYM", "SHIFT", "BACK"):
                bg, fg = (160, 165, 175), (30, 30, 30)
            else:
                bg, fg = (245, 246, 248), (20, 20, 20)
            pygame.draw.rect(surface, bg, rect, border_radius=8)
            # тень
            pygame.draw.rect(surface, (190, 194, 200), rect, 1, border_radius=8)
            if code == "SHIFT":
                text = "SHIFT"
            elif code == "BACK":
                text = "BACK"
            elif code == "ENTER":
                text = "ENTER"
            elif code == "PASTE":
                text = "Вставить"
            elif code == "LANG":
                text = {"ru": "РУС", "en": "ENG", "sym": "ABC"}[self.layout]
            elif code == "SPACE":
                text = {"ru": "Русский", "en": "English", "sym": " "}[self.layout]
            elif code == "SYM":
                text = "#1?"
            else:
                text = label
            f = sfont if code in ("LANG", "SYM", "SPACE", "SHIFT", "BACK", "ENTER", "PASTE") else font
            ts = f.render(text, True, fg)
            surface.blit(ts, ts.get_rect(center=rect.center))
            self.btn_rects.append((rect, code if code else label))
            return rect

        y = self.rect.y + pad_y
        for row in letter_rows:
            n = len(row)
            avail = w - 2 * pad_x - (n - 1) * self.key_gap
            kw = avail / n
            # для рядов с shift/back — отдельная логика ниже только для last letter row
            is_last_letters = (row is letter_rows[-1] and self.layout != "sym")
            if is_last_letters:
                # ⇧ + буквы + ⌫
                side = max(48, w * 0.12)
                mid_n = len(row)
                mid_avail = w - 2 * pad_x - 2 * side - (mid_n + 1) * self.key_gap
                mkw = mid_avail / max(1, mid_n)
                x = pad_x
                draw_key(x, y, side, "⇧", "SHIFT")
                x += side + self.key_gap
                for ch in row:
                    draw_key(x, y, mkw, ch, ch)
                    x += mkw + self.key_gap
                draw_key(x, y, side, "⌫", "BACK")
            else:
                x = pad_x
                for ch in row:
                    draw_key(x, y, kw, ch, ch)
                    x += kw + self.key_gap
            y += self.key_h + self.key_gap

        # нижний ряд: #1? | LANG | , | SPACE | . | 📋 | ↵
        side = max(40, w * 0.10)
        enter_w = max(48, w * 0.12)
        paste_w = max(44, w * 0.11)
        comma_w = max(32, w * 0.07)
        space_w = w - 2 * pad_x - 2 * side - 2 * comma_w - paste_w - enter_w - 6 * self.key_gap
        space_w = max(space_w, 48)
        x = pad_x
        draw_key(x, y, side, "#1?", "SYM" if self.layout != "sym" else "LANG")
        x += side + self.key_gap
        draw_key(x, y, side, "LANG", "LANG")
        x += side + self.key_gap
        draw_key(x, y, comma_w, ",", ",")
        x += comma_w + self.key_gap
        draw_key(x, y, space_w, "SPACE", "SPACE")
        x += space_w + self.key_gap
        draw_key(x, y, comma_w, ".", ".")
        x += comma_w + self.key_gap
        draw_key(x, y, paste_w, "Вст", "PASTE")
        x += paste_w + self.key_gap
        draw_key(x, y, enter_w, "↵", "ENTER")


