#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""UI-виджеты: диалог, поле ввода, кнопки, списки, BaseScreen."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any, Callable, Dict, List, Optional, Tuple

import pygame

from tl_core import (
    ACCENT, ERROR, LOG, NAV_BAR_H, PANEL_BG, PANEL_BORDER, ROW_ALT,
    TEXT_BRIGHT, TEXT_DIM, WARNING, dbg, shade, truncate_text,
)

# ============================================================================
# ДИАЛОГ ПОДТВЕРЖДЕНИЯ
# ============================================================================

class ConfirmDialog:
    def __init__(self, app: "App", title: str, message: str,
                 on_yes: Callable[[], None]) -> None:
        self.app = app
        self.title = title
        self.message = message
        self.on_yes = on_yes
        self.active = True
        self.btn_rects: Dict[str, pygame.Rect] = {}

    def handle_event(self, event: pygame.event.Event) -> bool:
        if not self.active:
            return False

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for key, rect in self.btn_rects.items():
                if rect.collidepoint(event.pos):
                    if key == "yes":
                        self.active = False
                        try:
                            self.on_yes()
                        except Exception as e:
                            LOG.error("UI", f"dialog yes: {e}")
                    elif key == "no":
                        self.active = False
                    return True
            return True

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_RETURN:
                self.active = False
                try:
                    self.on_yes()
                except Exception as e:
                    LOG.error("UI", f"dialog yes: {e}")
                return True
            if event.key == pygame.K_ESCAPE:
                self.active = False
                return True
            return True

        if event.type in (pygame.MOUSEBUTTONUP, pygame.MOUSEMOTION,
                          pygame.TEXTINPUT, pygame.TEXTEDITING):
            return True
        return False

    def draw(self, surface: pygame.Surface) -> None:
        if not self.active:
            return
        w, h = surface.get_size()
        overlay = pygame.Surface((w, h), pygame.SRCALPHA)
        overlay.fill((0, 0, 0, 170))
        surface.blit(overlay, (0, 0))

        box_w, box_h = min(520, w - 40), 230
        box = pygame.Rect((w - box_w) // 2, (h - box_h) // 2, box_w, box_h)
        pygame.draw.rect(surface, (30, 34, 44), box, border_radius=12)
        pygame.draw.rect(surface, ACCENT, box, width=2, border_radius=12)

        title_font = self.app.font("ui", 20, bold=True)
        ts = title_font.render(self.title, True, TEXT_BRIGHT)
        surface.blit(ts, (box.x + 24, box.y + 22))

        msg_font = self.app.font("ui", 14)
        y = box.y + 68
        for line in self.message.split("\n"):
            ms = msg_font.render(line, True, TEXT_DIM)
            surface.blit(ms, (box.x + 24, y))
            y += 22

        self.btn_rects.clear()
        btn_font = self.app.font("ui", 14, bold=True)

        yes_text = btn_font.render("Да", True, (255, 255, 255))
        yes_w = yes_text.get_width() + 40
        yes_rect = pygame.Rect(box.right - yes_w - 24, box.bottom - 62,
                               yes_w, 44)
        pygame.draw.rect(surface, (60, 140, 100), yes_rect, border_radius=8)
        surface.blit(yes_text, yes_text.get_rect(center=yes_rect.center))
        self.btn_rects["yes"] = yes_rect

        no_text = btn_font.render("Нет", True, (255, 255, 255))
        no_w = no_text.get_width() + 40
        no_rect = pygame.Rect(yes_rect.x - no_w - 12, box.bottom - 62,
                              no_w, 44)
        pygame.draw.rect(surface, (90, 100, 130), no_rect, border_radius=8)
        surface.blit(no_text, no_text.get_rect(center=no_rect.center))
        self.btn_rects["no"] = no_rect


# ============================================================================
# TEXT INPUT
# ============================================================================

class TextInput:
    def __init__(self, rect: pygame.Rect, placeholder: str = "",
                 on_submit: Optional[Callable[[str], None]] = None,
                 app: "App" = None) -> None:
        self.rect = rect
        self.placeholder = placeholder
        self.on_submit = on_submit
        self.app = app
        self.text = ""
        self.active = False
        self.caret_blink = 0.0

    def set_rect(self, rect: pygame.Rect) -> None:
        self.rect = rect

    def insert(self, ch: str) -> None:
        self.text += ch

    def backspace(self) -> None:
        self.text = self.text[:-1]

    def submit(self) -> None:
        if self.on_submit:
            self.on_submit(self.text)

    def focus(self) -> None:
        self.active = True
        if self.app is not None:
            self.app.set_text_focus(self)

    def unfocus(self) -> None:
        self.active = False
        if self.app is not None:
            if self.app.text_focus is self:
                self.app.clear_text_focus()

    def apply_text_input(self, text: str) -> None:
        self.text += text

    def handle_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.focus()
                return True

        if not self.active:
            return False

        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return True

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_BACKSPACE:
                self.backspace()
                return True
            if event.key == pygame.K_RETURN:
                self.submit()
                return True
        return False

    def update(self, dt: float) -> None:
        self.caret_blink = (self.caret_blink + dt) % 1.0

    def draw(self, surface: pygame.Surface, font: pygame.font.Font) -> None:
        bg = (26, 30, 40) if not self.active else (30, 36, 50)
        border = CARET if self.active else PANEL_BORDER
        pygame.draw.rect(surface, bg, self.rect, border_radius=6)
        pygame.draw.rect(surface, border, self.rect, width=2, border_radius=6)

        inner = self.rect.inflate(-16, -8)
        if self.text:
            display = truncate_text(self.text, font, inner.width - 20)
            ts = font.render(display, True, TEXT_BRIGHT)
            surface.blit(ts, (inner.x, inner.y +
                              (inner.height - ts.get_height()) // 2))
            if self.active and self.caret_blink < 0.5:
                cx = inner.x + ts.get_width() + 2
                cy = inner.y + 4
                ch = inner.height - 8
                pygame.draw.rect(surface, CARET, (cx, cy, 2, ch))
        else:
            ps = font.render(self.placeholder, True, TEXT_DIM)
            surface.blit(ps, (inner.x, inner.y +
                              (inner.height - ps.get_height()) // 2))
            if self.active and self.caret_blink < 0.5:
                pygame.draw.rect(surface, CARET,
                                 (inner.x, inner.y + 4, 2, inner.height - 8))


# ============================================================================
# TOUCH BUTTON
# ============================================================================

@dataclass
class TouchButton:
    label: str
    action: Callable[[], None]
    color: Tuple[int, int, int] = ACCENT
    rect: pygame.Rect = field(default_factory=lambda: pygame.Rect(0, 0, 0, 0))
    pressed: float = 0.0

    def handle_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                self.pressed = 1.0
                try:
                    self.action()
                except Exception as e:
                    dbg("Button error:", e)
                    LOG.error("UI", f"Button {self.label}: {e}")
                return True
        return False

    def update(self, dt: float) -> None:
        if self.pressed > 0:
            self.pressed = max(0.0, self.pressed - dt * 5)

    def draw(self, surface: pygame.Surface, font: pygame.font.Font,
             animations: bool = True) -> None:
        if self.label in ("Назад", "←"):
            return
        color = self.color
        if animations and self.pressed > 0:
            color = shade(color, 0.8)
        pygame.draw.rect(surface, color, self.rect, border_radius=8)
        text = truncate_text(self.label, font, self.rect.width - 16)
        ts = font.render(text, True, (255, 255, 255))
        surface.blit(ts, ts.get_rect(center=self.rect.center))


# ============================================================================
# SCROLL LIST
# ============================================================================

class ScrollList:
    def __init__(self) -> None:
        self.rect = pygame.Rect(0, 0, 1, 1)
        self.items: List[Dict[str, Any]] = []
        self.row_h = 44
        self.scroll = 0
        self.max_scroll = 0
        self.selected = 0
        self.dragging = False
        self.drag_start_y = 0
        self.drag_start_scroll = 0
        self.touch_start_y = 0
        self.on_activate: Optional[Callable[[int], None]] = None

    def set_rect(self, rect: pygame.Rect) -> None:
        self.rect = rect
        self.row_h = max(38, min(56, rect.height // 14))
        self._recalc()

    def set_items(self, items: List[Dict[str, Any]]) -> None:
        self.items = items
        self.selected = min(self.selected, max(0, len(items) - 1))
        self._recalc()

    def _recalc(self) -> None:
        content_h = len(self.items) * self.row_h
        self.max_scroll = max(0, content_h - self.rect.height + 6)
        self.scroll = min(self.scroll, self.max_scroll)

    def handle_event(self, event: pygame.event.Event) -> bool:
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.rect.collidepoint(event.pos):
                idx = self._index_at(event.pos)
                if idx is not None:
                    self.selected = idx
                self.drag_start_y = event.pos[1]
                self.drag_start_scroll = self.scroll
                self.touch_start_y = event.pos[1]
                self.dragging = True
                return True
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self.dragging and self.rect.collidepoint(event.pos):
                moved = abs(event.pos[1] - self.touch_start_y)
                if moved < 10:
                    idx = self._index_at(event.pos)
                    if idx is not None and idx == self.selected:
                        if self.on_activate:
                            try:
                                self.on_activate(idx)
                            except Exception as e:
                                dbg("list activate error:", e)
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            dy = event.pos[1] - self.drag_start_y
            if self.max_scroll > 0:
                ratio = self.max_scroll / max(1, self.rect.height)
                self.scroll = max(0, min(self.max_scroll,
                                         self.drag_start_scroll - dy * ratio))
        return False

    def _index_at(self, pos: Tuple[int, int]) -> Optional[int]:
        if not self.rect.collidepoint(pos):
            return None
        local_y = pos[1] - self.rect.y + self.scroll
        idx = local_y // self.row_h
        if 0 <= idx < len(self.items):
            return int(idx)
        return None

    def draw(self, surface: pygame.Surface, row_renderer: Callable) -> None:
        pygame.draw.rect(surface, (14, 16, 22), self.rect, border_radius=6)
        pygame.draw.rect(surface, PANEL_BORDER, self.rect,
                         width=1, border_radius=6)

        prev_clip = surface.get_clip()
        surface.set_clip(self.rect.inflate(-2, -2))

        y = self.rect.y + 4 - self.scroll
        for i, item in enumerate(self.items):
            if y + self.row_h < self.rect.y or y > self.rect.bottom:
                y += self.row_h
                continue
            selected = (i == self.selected)
            if selected:
                pygame.draw.rect(surface, (40, 70, 120),
                                 pygame.Rect(self.rect.x + 2, y,
                                             self.rect.width - 4,
                                             self.row_h))
            elif i % 2 == 1:
                pygame.draw.rect(surface, ROW_ALT,
                                 pygame.Rect(self.rect.x + 2, y,
                                             self.rect.width - 4,
                                             self.row_h))
            try:
                row_renderer(surface, i, item, self.rect.x + 10, y, selected)
            except Exception as e:
                dbg("row_renderer error:", e)
            y += self.row_h

        surface.set_clip(prev_clip)


# ============================================================================
# БАЗОВЫЙ ЭКРАН
# ============================================================================

class BaseScreen:
    def __init__(self, app: "App") -> None:
        self.app = app
        self._needs_redraw = True
        self.scroll = 0
        self.max_scroll = 0
        self.dragging = False
        self.drag_start_y = 0
        self.drag_start_scroll = 0

    def handle_event(self, event: pygame.event.Event) -> None:
        self._needs_redraw = True

    def apply_text_input(self, text: str) -> None:
        pass

    def update(self, dt: float) -> None:
        pass

    def draw(self, surface: pygame.Surface) -> None:
        pass

    def on_resize(self) -> None:
        self._needs_redraw = True

    def redraw(self) -> None:
        self._needs_redraw = True

    def animations_on(self) -> bool:
        return bool(self.app.settings.get("animations", True))


