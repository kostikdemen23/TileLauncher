#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from __future__ import annotations

import calendar
import datetime
import importlib.util
import json
import os
import shutil
import subprocess
import sys
import threading
import time
import traceback
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

DEBUG = False


def dbg(*args) -> None:
    if DEBUG:
        print("[DEBUG]", *args, flush=True)


try:
    import pygame
except ImportError:
    print("Установите pygame: pip install pygame")
    sys.exit(1)


# ============================================================================
# КОНСТАНТЫ
# ============================================================================

APP_NAME = "Tile Launcher"
APP_VERSION = "4.7.188"
TILE_OS_NAME = "TILE OS 4.7.188"

FPS = 30
NAV_BAR_H = 64

ANDROID_STORAGE = Path("/storage/emulated/0")
ANDROID_DOWNLOADS = Path("/storage/emulated/0/Download")
ANDROID_DCIM = Path("/storage/emulated/0/DCIM")
ANDROID_DOCUMENTS = Path("/storage/emulated/0/Documents")

IS_ANDROID = sys.platform == "linux" and ANDROID_STORAGE.exists()

# ----------------------------------------------------------------------------
# ВАЖНО: после переноса в system_ui/ этот файл лежит внутри подпапки,
# поэтому PROJECT_DIR должен указывать на РОДИТЕЛЬСКУЮ папку (TileLauncher),
# а не на system_ui/.
# ----------------------------------------------------------------------------
_ROOT = Path(__file__).resolve().parent          # .../TileLauncher/system_ui
_PROJECT_ROOT = _ROOT.parent                      # .../TileLauncher

if IS_ANDROID:
    PROJECT_DIR = ANDROID_STORAGE / "TileLauncher"
else:
    PROJECT_DIR = _PROJECT_ROOT

try:
    PROJECT_DIR.mkdir(parents=True, exist_ok=True)
except OSError:
    PROJECT_DIR = _PROJECT_ROOT

TARGET_SCRIPT = PROJECT_DIR / "target.py"
SETTINGS_FILE = PROJECT_DIR / "settings.json"
LOG_FILE = PROJECT_DIR / "launcher.log"
CLIPBOARD_FILE = PROJECT_DIR / "clipboard.txt"
MUSIC_STATE_FILE = PROJECT_DIR / "music_state.json"
MARKET_DIR = PROJECT_DIR / "market"
try:
    MARKET_DIR.mkdir(parents=True, exist_ok=True)
except Exception:
    pass

# Цвета (меняются темой)
BG_GRAD_TOP = (30, 34, 44)
BG_GRAD_BOTTOM = (14, 16, 22)
TILE_TEXT = (255, 255, 255)
TEXT_DIM = (170, 180, 200)
TEXT_BRIGHT = (240, 245, 255)
SUCCESS = (90, 200, 120)
ERROR = (230, 90, 90)
WARNING = (240, 190, 80)
ACCENT = (0, 120, 215)
PANEL_BG = (22, 25, 32)
PANEL_BORDER = (55, 60, 75)
ROW_ALT = (30, 34, 44)
SCROLL_FG = (110, 120, 145)
CARET = (100, 180, 255)
NAV_ICON = (220, 225, 240)
TILE_COLORS = [
    (0, 120, 215), (196, 43, 28), (110, 180, 30), (255, 140, 0),
    (140, 60, 160), (0, 160, 160), (200, 60, 120), (60, 100, 180),
    (170, 130, 40), (90, 130, 90),
]

MUSIC_ACCENT = (255, 45, 85)
MUSIC_PANEL = (40, 40, 70)

THEMES = {
    "dark": {
        "BG_GRAD_TOP": (30, 34, 44),
        "BG_GRAD_BOTTOM": (14, 16, 22),
        "TILE_TEXT": (255, 255, 255),
        "TEXT_DIM": (170, 180, 200),
        "TEXT_BRIGHT": (240, 245, 255),
        "PANEL_BG": (22, 25, 32),
        "PANEL_BORDER": (55, 60, 75),
        "ROW_ALT": (30, 34, 44),
        "SCROLL_FG": (110, 120, 145),
        "CARET": (100, 180, 255),
        "NAV_ICON": (220, 225, 240),
        "ACCENT": (0, 120, 215),
        "MUSIC_PANEL": (40, 40, 70),
    },
    "light": {
        "BG_GRAD_TOP": (235, 240, 248),
        "BG_GRAD_BOTTOM": (210, 218, 230),
        "TILE_TEXT": (255, 255, 255),
        "TEXT_DIM": (90, 100, 120),
        "TEXT_BRIGHT": (20, 25, 40),
        "PANEL_BG": (245, 248, 252),
        "PANEL_BORDER": (180, 190, 210),
        "ROW_ALT": (230, 235, 245),
        "SCROLL_FG": (140, 150, 170),
        "CARET": (0, 100, 200),
        "NAV_ICON": (40, 50, 70),
        "ACCENT": (0, 100, 200),
        "MUSIC_PANEL": (200, 210, 230),
    },
    "amoled": {
        "BG_GRAD_TOP": (0, 0, 0),
        "BG_GRAD_BOTTOM": (0, 0, 0),
        "TILE_TEXT": (255, 255, 255),
        "TEXT_DIM": (140, 140, 150),
        "TEXT_BRIGHT": (250, 250, 255),
        "PANEL_BG": (8, 8, 10),
        "PANEL_BORDER": (40, 40, 50),
        "ROW_ALT": (16, 16, 20),
        "SCROLL_FG": (80, 80, 100),
        "CARET": (80, 160, 255),
        "NAV_ICON": (220, 220, 230),
        "ACCENT": (0, 140, 255),
        "MUSIC_PANEL": (20, 20, 35),
    },
}

THEME_LABELS = {"dark": "Тёмная", "light": "Светлая", "amoled": "AMOLED"}


def apply_theme(name: str) -> None:
    """Применяет цветовую тему, обновляя глобальные переменные."""
    global BG_GRAD_TOP, BG_GRAD_BOTTOM, TILE_TEXT, TEXT_DIM, TEXT_BRIGHT
    global PANEL_BG, PANEL_BORDER, ROW_ALT, SCROLL_FG, CARET, NAV_ICON
    global ACCENT, MUSIC_PANEL
    theme = THEMES.get(name, THEMES["dark"])
    BG_GRAD_TOP = theme["BG_GRAD_TOP"]
    BG_GRAD_BOTTOM = theme["BG_GRAD_BOTTOM"]
    TILE_TEXT = theme["TILE_TEXT"]
    TEXT_DIM = theme["TEXT_DIM"]
    TEXT_BRIGHT = theme["TEXT_BRIGHT"]
    PANEL_BG = theme["PANEL_BG"]
    PANEL_BORDER = theme["PANEL_BORDER"]
    ROW_ALT = theme["ROW_ALT"]
    SCROLL_FG = theme["SCROLL_FG"]
    CARET = theme["CARET"]
    NAV_ICON = theme["NAV_ICON"]
    ACCENT = theme["ACCENT"]
    MUSIC_PANEL = theme["MUSIC_PANEL"]

TEXT_EXTS = (
    ".txt", ".md", ".py", ".json", ".csv", ".log", ".xml", ".html",
    ".htm", ".ini", ".cfg", ".yaml", ".yml", ".js", ".ts", ".css",
    ".sh", ".bat", ".c", ".cpp", ".h", ".java", ".kt", ".sql",
    ".rs", ".go", ".rb", ".php", ".pl", ".r", ".swift", ".dart",
    ".toml", ".env", ".gitignore", ".dockerfile", ".makefile",
    ".tex", ".rst", ".org", ".rtf", ".csv", ".tsv",
)
AUDIO_EXTS = (".mp3", ".wav", ".ogg", ".flac", ".m4a", ".aac")
IMAGE_EXTS = (".png", ".jpg", ".jpeg", ".bmp", ".gif", ".webp")
DOC_EXTS = (".pdf", ".doc", ".docx", ".odt", ".ods", ".odp",
            ".xls", ".xlsx", ".ppt", ".pptx", ".epub", ".fb2")


# ============================================================================
# ЛОГИРОВАНИЕ
# ============================================================================

class Logger:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.lock = threading.Lock()
        try:
            self.path.touch(exist_ok=True)
        except OSError:
            pass

    def log(self, source: str, line: str) -> None:
        ts = time.strftime("%Y-%m-%d %H:%M:%S")
        with self.lock:
            try:
                with self.path.open("a", encoding="utf-8") as fh:
                    fh.write(f"[{ts}] [{source}] {line}\n")
            except OSError:
                pass

    def info(self, source: str, line: str) -> None:
        self.log(source, f"INFO: {line}")

    def warn(self, source: str, line: str) -> None:
        self.log(source, f"WARN: {line}")

    def error(self, source: str, line: str) -> None:
        self.log(source, f"ERROR: {line}")

    def clear(self) -> None:
        with self.lock:
            try:
                self.path.write_text("", encoding="utf-8")
            except OSError:
                pass


LOG = Logger(LOG_FILE)


# ============================================================================
# НАСТРОЙКИ
# ============================================================================

DEFAULT_SETTINGS: Dict[str, Any] = {
    "fps": 30,
    "animations": True,
    "confirm_exit": True,
    "editor_tab_size": 4,
    "python_path": sys.executable,
    "browse_path": str(PROJECT_DIR),
    "theme": "dark",
    "hidden_tiles": [],
    "tile_sizes": {},
    "tile_order": [],
    "tile_positions": {},  # tag -> {"col": int, "row": int}
    "desktop_apps": [],  # [{tag, name, path}, ...] из маркета
    "desktop_folders": [],  # [{tag, name, apps: [tag,...]}]
    "grid_cols": 4,
    "icon_scale": 1.0,
    "wallpaper": "default",
    "widgets": True,
    "home_page_count": 1,
    "home_page": 0,
    "android_auto": False,
    "developer_mode": False,
    "dev_auto_usb": True,
}

TILE_SIZE_PRESETS = [
    (1, 1), (1, 2), (2, 1), (2, 2), (3, 1), (3, 2), (3, 3),
]
# Системные нельзя удалить: всё встроенное, кроме Python 3.13 и Консоли
DELETABLE_TAGS = {"IDE", "CMD"}
BUILT_IN_TAGS = {
    "IDE", "CMD", "DOCS", "DL", "LOG", "MUSIC", "SET", "ENV", "FILES", "EXIT",
    "MARKET", "GALLERY",
}


def is_protected_tag(tag: str) -> bool:
    if tag == "EXIT":
        return True
    if tag in DELETABLE_TAGS:
        return False
    return tag in BUILT_IN_TAGS


WALLPAPERS = {
    "default": None,  # градиент темы
    "blue": ((20, 40, 80), (10, 20, 40)),
    "purple": ((40, 20, 60), (20, 10, 30)),
    "green": ((20, 50, 40), (10, 25, 20)),
    "red": ((60, 20, 25), (30, 10, 12)),
    "black": ((0, 0, 0), (0, 0, 0)),
}


class Settings:
    def __init__(self, path: Path) -> None:
        self.path = path
        self.data = dict(DEFAULT_SETTINGS)
        try:
            self.load()
        except Exception:
            pass

    def load(self) -> None:
        if not self.path.exists():
            self.save()
            return
        try:
            with self.path.open("r", encoding="utf-8") as fh:
                raw = json.load(fh)
            if isinstance(raw, dict):
                for k, v in raw.items():
                    if k in DEFAULT_SETTINGS:
                        self.data[k] = v
            self._validate()
        except Exception:
            pass

    def _validate(self) -> None:
        try:
            self.data["fps"] = max(10, min(120, int(self.data.get("fps", 30))))
        except (TypeError, ValueError):
            self.data["fps"] = 30
        try:
            self.data["editor_tab_size"] = max(1, min(8, int(self.data.get("editor_tab_size", 4))))
        except (TypeError, ValueError):
            self.data["editor_tab_size"] = 4
        self.data["animations"] = bool(self.data.get("animations", True))
        self.data["confirm_exit"] = bool(self.data.get("confirm_exit", True))
        if not isinstance(self.data.get("browse_path"), str):
            self.data["browse_path"] = str(PROJECT_DIR)
        if not isinstance(self.data.get("python_path"), str):
            self.data["python_path"] = sys.executable
        t = str(self.data.get("theme", "dark"))
        if t not in THEMES:
            t = "dark"
        self.data["theme"] = t
        if not isinstance(self.data.get("hidden_tiles"), list):
            self.data["hidden_tiles"] = []
        # системные не могут быть скрыты — вернуть Музыку и др.
        self.data["hidden_tiles"] = [
            t for t in self.data["hidden_tiles"]
            if isinstance(t, str) and not is_protected_tag(t)
        ]
        if not isinstance(self.data.get("tile_sizes"), dict):
            self.data["tile_sizes"] = {}
        if not isinstance(self.data.get("tile_order"), list):
            self.data["tile_order"] = []
        if not isinstance(self.data.get("tile_positions"), dict):
            self.data["tile_positions"] = {}
        if not isinstance(self.data.get("desktop_apps"), list):
            self.data["desktop_apps"] = []
        else:
            cleaned = []
            for item in self.data["desktop_apps"]:
                if not isinstance(item, dict):
                    continue
                tag = str(item.get("tag", ""))
                name = str(item.get("name", ""))
                path = str(item.get("path", ""))
                if tag and name and path:
                    cleaned.append({"tag": tag, "name": name, "path": path})
            self.data["desktop_apps"] = cleaned
        if not isinstance(self.data.get("desktop_folders"), list):
            self.data["desktop_folders"] = []
        self.data["widgets"] = bool(self.data.get("widgets", True))
        self.data["android_auto"] = bool(self.data.get("android_auto", False))
        self.data["developer_mode"] = bool(self.data.get("developer_mode", False))
        self.data["dev_auto_usb"] = bool(self.data.get("dev_auto_usb", True))
        try:
            self.data["home_page_count"] = max(1, min(5, int(self.data.get("home_page_count", 1))))
        except (TypeError, ValueError):
            self.data["home_page_count"] = 1
        try:
            self.data["home_page"] = max(0, min(
                self.data["home_page_count"] - 1,
                int(self.data.get("home_page", 0))))
        except (TypeError, ValueError):
            self.data["home_page"] = 0
        try:
            gc = int(self.data.get("grid_cols", 4))
            self.data["grid_cols"] = 5 if gc >= 5 else 4
        except (TypeError, ValueError):
            self.data["grid_cols"] = 4
        try:
            sc = float(self.data.get("icon_scale", 1.0))
            self.data["icon_scale"] = max(0.7, min(1.4, sc))
        except (TypeError, ValueError):
            self.data["icon_scale"] = 1.0
        if self.data.get("wallpaper") not in WALLPAPERS:
            self.data["wallpaper"] = "default"

    def save(self) -> None:
        try:
            self._validate()
            with self.path.open("w", encoding="utf-8") as fh:
                json.dump(self.data, fh, ensure_ascii=False, indent=2)
        except OSError:
            pass

    def get(self, key: str, default: Any = None) -> Any:
        return self.data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        if key == "fps":
            try:
                value = max(10, min(120, int(value)))
            except (TypeError, ValueError):
                value = 30
        elif key == "editor_tab_size":
            try:
                value = max(1, min(8, int(value)))
            except (TypeError, ValueError):
                value = 4
        elif key in ("animations", "confirm_exit", "android_auto",
                     "developer_mode", "dev_auto_usb"):
            value = bool(value)
        elif key == "theme":
            value = str(value)
            if value not in THEMES:
                value = "dark"
            apply_theme(value)
        self.data[key] = value
        self.save()

    def toggle(self, key: str) -> bool:
        new_val = not bool(self.data.get(key, False))
        self.set(key, new_val)
        return new_val


# ============================================================================
# УТИЛИТЫ
# ============================================================================

def lerp_color(a, b, t):
    t = max(0.0, min(1.0, t))
    return (int(a[0] + (b[0] - a[0]) * t),
            int(a[1] + (b[1] - a[1]) * t),
            int(a[2] + (b[2] - a[2]) * t))


def shade(color, factor):
    return (max(0, min(255, int(color[0] * factor))),
            max(0, min(255, int(color[1] * factor))),
            max(0, min(255, int(color[2] * factor))))


def truncate_text(text: str, font: pygame.font.Font, max_w: int) -> str:
    try:
        if font.size(text)[0] <= max_w:
            return text
        ell = "..."
        while text and font.size(text + ell)[0] > max_w:
            text = text[:-1]
        return text + ell
    except Exception:
        return text[:50]


def human_size(num_bytes: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    size = float(num_bytes)
    for u in units:
        if size < 1024 or u == units[-1]:
            return f"{size:.1f} {u}" if u != "B" else f"{int(size)} B"
        size /= 1024
    return f"{num_bytes} B"


def read_battery_percent() -> Optional[int]:
    for name in ("battery", "Battery", "BAT0", "BAT1"):
        p = Path("/sys/class/power_supply") / name / "capacity"
        try:
            if p.exists():
                return int(p.read_text().strip())
        except Exception:
            pass
    return None


def read_charge_status() -> str:
    """Charging / Discharging / Full / Unknown."""
    for name in ("battery", "Battery", "BAT0", "BAT1"):
        p = Path("/sys/class/power_supply") / name / "status"
        try:
            if p.exists():
                s = p.read_text().strip()
                if s:
                    return s
        except Exception:
            pass
    return "Unknown"


def read_usb_connected() -> bool:
    """Кабель USB / зарядка по USB (приблизительно)."""
    base = Path("/sys/class/power_supply")
    for name in ("usb", "USB", "pc_port", "Usb"):
        for fname in ("online", "present"):
            p = base / name / fname
            try:
                if p.exists() and p.read_text().strip() in ("1", "Y", "yes"):
                    return True
            except Exception:
                pass
    # fallback: status Charging + type USB
    for name in ("battery", "Battery"):
        try:
            st = (base / name / "status").read_text().strip().lower()
            typ = ""
            for tname in ("type", "power_now"):
                tp = base / name / tname
                if tp.exists():
                    typ = tp.read_text().strip().lower()
                    break
            if "charging" in st and "usb" in typ:
                return True
        except Exception:
            pass
    return False


def read_weather_cache() -> Optional[str]:
    """Краткий текст погоды из weather_cfg / последнего кэша."""
    for p in (
        MARKET_DIR / "weather_cfg.json",
        PROJECT_DIR / "market" / "weather_cfg.json",
        Path(__file__).resolve().parent / "weather_cfg.json",
    ):
        try:
            if not p.exists():
                continue
            data = json.loads(p.read_text(encoding="utf-8"))
            city = data.get("name") or data.get("city")
            if city:
                return str(city)
        except Exception:
            continue
    return None


def load_market_meta(py_path: Path) -> Dict[str, Any]:
    """Читает app.json рядом с .py или в папке приложения."""
    meta = {
        "name": py_path.stem if py_path.suffix else py_path.name,
        "description": "",
        "category": "утилиты",
        "icon": (py_path.stem if py_path.suffix else py_path.name)[:1].upper(),
        "entry": None,
    }
    candidates = []
    if py_path.is_dir():
        candidates = [
            py_path / "app.json",
            py_path / f"{py_path.name}.json",
        ]
    else:
        candidates = [
            py_path.with_name(py_path.stem + ".json"),
            py_path.with_name("app.json"),
            py_path.parent / "app.json",
            py_path.parent / py_path.stem / "app.json",
        ]
    for cand in candidates:
        try:
            if cand.exists():
                raw = json.loads(cand.read_text(encoding="utf-8"))
                if isinstance(raw, dict):
                    if raw.get("name"):
                        meta["name"] = str(raw["name"])
                    if raw.get("description"):
                        meta["description"] = str(raw["description"])
                    if raw.get("category"):
                        meta["category"] = str(raw["category"]).lower()
                    if raw.get("icon"):
                        meta["icon"] = str(raw["icon"])[:2]
                    if raw.get("entry"):
                        meta["entry"] = str(raw["entry"])
                break
        except Exception:
            continue
    return meta


def resolve_market_entry(folder: Path) -> Optional[Path]:
    """
    Точка входа приложения-папки:
      app.json → entry | main.py | app.py | <имя_папки>.py | *plugin*.py | любой .py
    """
    if not folder.is_dir():
        return None
    meta = load_market_meta(folder)
    if meta.get("entry"):
        cand = folder / meta["entry"]
        if cand.exists() and cand.suffix.lower() == ".py":
            return cand
    for name in ("main.py", "app.py", f"{folder.name}.py"):
        cand = folder / name
        if cand.is_file():
            return cand
    plugins = sorted(folder.glob("*plugin*.py"))
    if plugins:
        return plugins[0]
    pys = sorted(
        p for p in folder.iterdir()
        if p.is_file() and p.suffix.lower() == ".py" and not p.name.startswith(".")
    )
    return pys[0] if pys else None


def scan_market_apps() -> List[Dict[str, Any]]:
    """Сканирует market/: одиночные .py и папки-приложения."""
    apps: List[Dict[str, Any]] = []
    seen_paths = set()
    try:
        MARKET_DIR.mkdir(parents=True, exist_ok=True)
    except Exception:
        pass
    if not MARKET_DIR.is_dir():
        return apps

    def _add(entry: Path, folder: Optional[Path] = None) -> None:
        try:
            key = str(entry.resolve())
        except Exception:
            key = str(entry)
        if key in seen_paths:
            return
        seen_paths.add(key)
        meta_src = folder if folder is not None else entry
        meta = load_market_meta(meta_src)
        if folder is not None and meta["name"] == folder.name:
            # если нет app.json — имя папки
            pass
        plugin = is_plugin_script(entry)
        extra = 0
        if folder is not None:
            try:
                extra = sum(1 for x in folder.iterdir() if x.is_file()) - 1
            except Exception:
                extra = 0
        desc = meta.get("description") or ""
        if folder is not None:
            desc = desc or f"папка · {extra + 1} файл(ов)"
        elif plugin:
            desc = desc or "плагин лаунчера"
        apps.append({
            "name": meta["name"],
            "path": entry,
            "folder": folder,
            "size": human_size(entry.stat().st_size) if entry.exists() else "—",
            "type": "folder" if folder else ("plugin" if plugin else "py"),
            "description": desc,
            "category": meta.get("category", "утилиты"),
            "icon": meta.get("icon", "?"),
            "pygame": file_uses_pygame_display(entry) and not plugin,
            "plugin": plugin,
            "files": extra + 1 if folder else 1,
        })

    try:
        items = sorted(MARKET_DIR.iterdir(), key=lambda x: x.name.lower())
        for p in items:
            if p.name.startswith("."):
                continue
            if p.is_dir():
                entry = resolve_market_entry(p)
                if entry is not None:
                    _add(entry, folder=p)
            elif p.is_file() and p.suffix.lower() == ".py":
                _add(p, folder=None)
    except Exception as e:
        LOG.error("MARKET", f"scan: {e}")
    return apps


def file_uses_pygame_display(path: Path) -> bool:
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")[:8000]
        return "pygame.display.set_mode" in text or "display.set_mode" in text
    except Exception:
        return False


def is_plugin_script(path: Path) -> bool:
    """Плагин лаунчера: есть create_plugin() — работает внутри UI, не subprocess."""
    try:
        text = path.read_text(encoding="utf-8", errors="ignore")[:6000]
        return ("def create_plugin" in text) or ("PLUGIN_APP = True" in text)
    except Exception:
        return False


def load_market_plugin(path: Path, app: "App") -> Any:
    """
    Загружает .py из market как плагин.
    Ожидает: def create_plugin(app) -> объект с handle_event/update/draw.
    """
    path = Path(path)
    mod_name = f"tile_market_{path.stem}_{abs(hash(str(path))) % 10_000_000}"
    spec = importlib.util.spec_from_file_location(mod_name, str(path))
    if spec is None or spec.loader is None:
        raise ImportError(f"Не удалось загрузить: {path}")
    mod = importlib.util.module_from_spec(spec)
    # чтобы плагин мог делать `import pygame` и т.п.
    sys.modules[mod_name] = mod
    spec.loader.exec_module(mod)
    if not hasattr(mod, "create_plugin"):
        raise AttributeError("В файле нет create_plugin(app)")
    plugin = mod.create_plugin(app)
    if plugin is None:
        raise RuntimeError("create_plugin вернул None")
    return plugin


def safe_listdir(path: Path) -> List[Path]:
    try:
        items = list(path.iterdir())
        items.sort(key=lambda p: (not p.is_dir(), p.name.lower()))
        return items
    except (PermissionError, OSError):
        return []


def to_python_path(path_str: str) -> str:
    p = path_str.strip()
    if not p:
        return p
    if not p.startswith("/"):
        p = "/" + p
    while "//" in p:
        p = p.replace("//", "/")
    return p


def copy_to_clipboard(text: str):
    try:
        import pyperclip  # noqa
        pyperclip.copy(text)
        return True
    except Exception:
        pass
    try:
        pygame.scrap.init()
        pygame.scrap.put(pygame.SCRAP_TEXT, text.encode("utf-8"))
        return True
    except Exception:
        pass
    try:
        CLIPBOARD_FILE.write_text(text, encoding="utf-8")
        return "file"
    except Exception:
        pass
    return False


MONTHS_RU = [
    "", "Январь", "Февраль", "Март", "Апрель", "Май", "Июнь",
    "Июль", "Август", "Сентябрь", "Октябрь", "Ноябрь", "Декабрь",
]
WEEKDAYS_RU = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]

MUSIC_DIRS = [
    "/storage/emulated/0/Music",
    "/storage/emulated/0/Download",
    "/storage/emulated/0/Downloads",
    "/storage/emulated/0/Музыка",
    "/sdcard",
    "/sdcard/Music",
]

MUSIC_EXTS = AUDIO_EXTS


def scan_music() -> List[Tuple[str, str]]:
    files: List[Tuple[str, str]] = []
    seen_paths = set()
    seen_keys = set()  # (name_lower, size) — защита от дублей через разные пути
    for d in MUSIC_DIRS:
        if not os.path.isdir(d):
            continue
        try:
            for name in os.listdir(d):
                if not name.lower().endswith(MUSIC_EXTS):
                    continue
                full = os.path.join(d, name)
                try:
                    real = os.path.realpath(full)
                except Exception:
                    real = full
                if real in seen_paths or full in seen_paths:
                    continue
                try:
                    sz = os.path.getsize(full)
                except OSError:
                    sz = -1
                key = (name.lower(), sz)
                if key in seen_keys:
                    continue
                seen_paths.add(real)
                seen_paths.add(full)
                seen_keys.add(key)
                files.append((full, name))
        except (PermissionError, OSError):
            continue
    files.sort(key=lambda x: x[1].lower())
    return files


def is_text_file(path: Path) -> bool:
    return path.suffix.lower() in TEXT_EXTS


def is_audio_file(path: Path) -> bool:
    return path.suffix.lower() in AUDIO_EXTS


def is_image_file(path: Path) -> bool:
    return path.suffix.lower() in IMAGE_EXTS


def is_doc_file(path: Path) -> bool:
    return path.suffix.lower() in DOC_EXTS


def _read_prop(key: str, default: str = "—") -> str:
    """Читает свойство из build.prop / getprop."""
    paths = [
        Path("/system/build.prop"),
        Path("/vendor/build.prop"),
    ]
    for p in paths:
        try:
            if not p.exists():
                continue
            for line in p.read_text(encoding="utf-8", errors="ignore").splitlines():
                if line.startswith(key + "="):
                    return line.split("=", 1)[1].strip() or default
        except Exception:
            pass
    try:
        out = subprocess.check_output(
            ["getprop", key], text=True, stderr=subprocess.DEVNULL, timeout=2
        ).strip()
        if out:
            return out
    except Exception:
        pass
    return default


def get_device_info() -> List[Tuple[str, str]]:
    """Собирает сведения об устройстве."""
    rows: List[Tuple[str, str]] = []

    model = _read_prop("ro.product.model")
    if model == "—":
        model = _read_prop("ro.product.device", platform_machine())
    manufacturer = _read_prop("ro.product.manufacturer", "—")
    brand = _read_prop("ro.product.brand", manufacturer)
    device = _read_prop("ro.product.device", "—")
    name = _read_prop("ro.product.name", device)

    rows.append(("Устройство", f"{brand} {model}".strip()))
    rows.append(("Модель", model))
    rows.append(("Код устройства", device))
    rows.append(("Имя", name))
    rows.append(("Производитель", manufacturer))

    # RAM
    total_ram = 0
    avail_ram = 0
    try:
        with open("/proc/meminfo", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("MemTotal:"):
                    total_ram = int(line.split()[1]) * 1024
                elif line.startswith("MemAvailable:"):
                    avail_ram = int(line.split()[1]) * 1024
                elif line.startswith("MemFree:") and avail_ram == 0:
                    avail_ram = int(line.split()[1]) * 1024
    except Exception:
        pass

    ram_type = _read_prop("ro.boot.hardware.ddr", "—")
    if ram_type == "—":
        ram_type = _read_prop("ro.ram_type", "LPDDR")
    ram_name = _read_prop("ro.boot.hardware.memory", ram_type)

    if total_ram > 0:
        used_ram = max(0, total_ram - avail_ram)
        rows.append(("ОЗУ (тип)", ram_type if ram_type != "—" else "DDR/LPDDR"))
        rows.append(("ОЗУ (название)", ram_name))
        rows.append(("ОЗУ всего", human_size(total_ram)))
        rows.append(("ОЗУ занято", f"{human_size(used_ram)} / {human_size(total_ram)}"))
        rows.append(("ОЗУ свободно", human_size(avail_ram)))
    else:
        rows.append(("ОЗУ", "н/д"))

    # Storage
    try:
        usage = shutil.disk_usage(str(ANDROID_STORAGE if IS_ANDROID else Path("/")))
        rows.append(("Память всего", human_size(usage.total)))
        rows.append(("Память занято",
                     f"{human_size(usage.used)} / {human_size(usage.total)}"))
        rows.append(("Память свободно", human_size(usage.free)))
    except Exception:
        rows.append(("Память", "н/д"))

    return rows


def platform_machine() -> str:
    try:
        import platform as _pl
        return _pl.machine() or "—"
    except Exception:
        return "—"


def get_system_info() -> List[Tuple[str, str]]:
    """Сведения о системе TILE OS / окружении."""
    rows: List[Tuple[str, str]] = []
    rows.append(("Система", TILE_OS_NAME))
    rows.append(("Лаунчер", f"{APP_NAME} {APP_VERSION}"))
    rows.append(("Python", sys.version.split()[0]))
    try:
        rows.append(("pygame", pygame.version.ver))
    except Exception:
        rows.append(("pygame", "—"))
    rows.append(("Платформа", sys.platform))
    rows.append(("Android", "да" if IS_ANDROID else "нет"))
    rows.append(("Архитектура", platform_machine()))
    rows.append(("Каталог проекта", str(PROJECT_DIR)))
    rows.append(("Каталог system_ui", str(_ROOT)))

    android_ver = _read_prop("ro.build.version.release", "—")
    sdk = _read_prop("ro.build.version.sdk", "—")
    if android_ver != "—":
        rows.append(("Android версия", android_ver))
    if sdk != "—":
        rows.append(("SDK", sdk))
    build_id = _read_prop("ro.build.display.id", "—")
    if build_id != "—":
        rows.append(("Сборка Android", build_id))
    return rows