#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Рабочий стол: плитки, жесты, страницы."""
from __future__ import annotations

import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import pygame

from tl_core import *
from tl_widgets import BaseScreen, TouchButton, TextInput

# ============================================================================
# МЕНЮ
# ============================================================================

@dataclass
class TileSize:
    cols: int = 1
    rows: int = 1


@dataclass
class Tile:
    label: str
    color: Tuple[int, int, int]
    size: TileSize
    action: Optional[Callable[[], None]] = None
    tag: str = ""
    subtitle: str = ""
    rect: pygame.Rect = field(default_factory=lambda: pygame.Rect(0, 0, 0, 0))
    press: float = 0.0


@dataclass
class TileGroup:
    title: str
    tiles: List[Tile] = field(default_factory=list)
    rect: pygame.Rect = field(default_factory=lambda: pygame.Rect(0, 0, 0, 0))


class TileScreen(BaseScreen):
    def __init__(self, app: "App") -> None:
        super().__init__(app)
        self.groups: List[TileGroup] = []
        self._bg_surface: Optional[pygame.Surface] = None
        self._bg_size: Tuple[int, int] = (0, 0)
        self.edit_mode = False
        self.pinch_panel = False
        self._fingers: Dict[int, Tuple[float, float]] = {}
        self._pinch_start_dist = 0.0
        self._panel_rects: Dict[str, pygame.Rect] = {}
        self._exit_rect: Optional[pygame.Rect] = None
        # Долгое нажатие → перетаскивание в корзину
        self._hold_tile: Optional[Tile] = None
        self._hold_start = 0.0
        self._dragging_tile: Optional[Tile] = None
        self._drag_pos: Tuple[int, int] = (0, 0)
        self._drag_offset: Tuple[int, int] = (0, 0)
        self._trash_rect: Optional[pygame.Rect] = None
        self._sys_msg: Optional[str] = None
        self._sys_msg_until = 0.0
        self.size_mode = False
        self._size_target: Optional[str] = None  # tag
        self._size_menu_rects: List[Tuple[pygame.Rect, Tuple[int, int]]] = []
        self._reorder_mode = False
        self.search_open = False
        self.search_query = ""
        self._swipe_x0: Optional[int] = None
        self._swipe_y0: Optional[int] = None
        self._page_btn_rect: Optional[pygame.Rect] = None
        self.page_anim_x = 0.0  # смещение контента при смене страницы
        self.page_anim_from = 0.0
        self._last_clock_sec = -1
        self._widget_cache = ("", 0.0)  # text, time
        self._build_groups()
        self._layout()
        try:
            self.app.clear_text_focus()
        except Exception:
            pass

    def _all_app_defs(self) -> List[Dict[str, Any]]:
        """Каталог приложений (системные + с рабочего стола из маркета)."""
        defs: List[Dict[str, Any]] = [
            {"label": "Python 3.13", "color": (0, 120, 215), "cols": 2, "rows": 2,
             "action": self.app.on_open_editor, "tag": "IDE", "subtitle": "target.py"},
            {"label": "Консоль", "color": TILE_COLORS[5], "cols": 1, "rows": 1,
             "action": self.app.on_open_console, "tag": "CMD", "subtitle": ""},
            {"label": "Документы", "color": TILE_COLORS[1], "cols": 2, "rows": 1,
             "action": self.app.on_open_documents, "tag": "DOCS", "subtitle": ""},
            {"label": "Загрузки", "color": TILE_COLORS[2], "cols": 2, "rows": 1,
             "action": self.app.on_open_downloads, "tag": "DL", "subtitle": ""},
            {"label": "Логи", "color": TILE_COLORS[8], "cols": 1, "rows": 1,
             "action": self.app.on_show_logs, "tag": "LOG", "subtitle": ""},
            {"label": "Музыка", "color": MUSIC_ACCENT, "cols": 2, "rows": 2,
             "action": self.app.on_open_music, "tag": "MUSIC", "subtitle": "плеер"},
            {"label": "Tile market", "color": (255, 140, 0), "cols": 2, "rows": 1,
             "action": self.app.on_open_market, "tag": "MARKET", "subtitle": "приложения"},
            {"label": "Настройки", "color": TILE_COLORS[9], "cols": 1, "rows": 1,
             "action": self.app.on_settings, "tag": "SET", "subtitle": ""},
            {"label": "Проверка", "color": TILE_COLORS[4], "cols": 1, "rows": 1,
             "action": self.app.on_check_env, "tag": "ENV", "subtitle": ""},
            {"label": "Проводник", "color": TILE_COLORS[3], "cols": 2, "rows": 1,
             "action": self.app.on_open_folder, "tag": "FILES", "subtitle": ""},
            {"label": "Галерея", "color": (90, 160, 200), "cols": 1, "rows": 1,
             "action": self.app.on_open_gallery, "tag": "GALLERY", "subtitle": "фото"},
        ]
        for item in self.app.settings.get("desktop_apps") or []:
            if not isinstance(item, dict):
                continue
            tag = str(item.get("tag", ""))
            name = str(item.get("name", ""))
            path = str(item.get("path", ""))
            if not tag or not path:
                continue
            # замыкание по path
            def _make_action(p: str):
                return lambda: self.app.launch_market_app(p)
            color = TILE_COLORS[hash(tag) % len(TILE_COLORS)]
            defs.append({
                "label": name or Path(path).stem,
                "color": color,
                "cols": 1,
                "rows": 1,
                "action": _make_action(path),
                "tag": tag,
                "subtitle": "market",
            })
        for folder in self.app.settings.get("desktop_folders") or []:
            if not isinstance(folder, dict):
                continue
            ftag = str(folder.get("tag", ""))
            fname = str(folder.get("name", "Папка"))
            if not ftag:
                continue

            def _open_folder(t=ftag):
                self.app.open_folder(t)

            defs.append({
                "label": fname,
                "color": (90, 100, 130),
                "cols": 2,
                "rows": 1,
                "action": _open_folder,
                "tag": ftag,
                "subtitle": "папка",
            })
        return defs

    def _build_groups(self) -> None:
        hidden = set(self.app.settings.get("hidden_tiles") or [])
        sizes = self.app.settings.get("tile_sizes") or {}
        order = list(self.app.settings.get("tile_order") or [])
        apps = self._all_app_defs()
        by_tag = {a["tag"]: a for a in apps}
        # порядок: сохранённый, затем остальные по алфавиту
        ordered: List[Dict[str, Any]] = []
        seen = set()
        for tag in order:
            if tag in by_tag and tag not in seen:
                ordered.append(by_tag[tag])
                seen.add(tag)
        rest = [a for a in apps if a["tag"] not in seen]
        rest.sort(key=lambda a: a["label"].lower())
        ordered.extend(rest)

        tiles: List[Tile] = []
        for a in ordered:
            if a["tag"] in hidden and not is_protected_tag(a["tag"]):
                continue
            sz = sizes.get(a["tag"])
            if isinstance(sz, dict):
                cols = max(1, min(3, int(sz.get("cols", a["cols"]))))
                rows = max(1, min(3, int(sz.get("rows", a["rows"]))))
            else:
                cols, rows = a["cols"], a["rows"]
            tiles.append(Tile(
                a["label"], a["color"], TileSize(cols, rows),
                action=a["action"], tag=a["tag"], subtitle=a.get("subtitle", ""),
            ))
        self._exit_tile = Tile("Выход", (140, 40, 40), TileSize(1, 1),
                               action=self.app.on_quit, tag="EXIT")
        g = TileGroup("ПРИЛОЖЕНИЯ")
        g.tiles = tiles
        self.groups = [g]

    def rebuild(self) -> None:
        self._build_groups()
        self._layout()
        self._bg_surface = None

    def apply_text_input(self, text: str) -> None:
        if self.search_open:
            self.search_query += text
            self.redraw()

    def insert(self, ch: str) -> None:
        if self.search_open:
            self.search_query += ch
            self.redraw()

    def backspace(self) -> None:
        if self.search_open and self.search_query:
            self.search_query = self.search_query[:-1]
            self.redraw()

    def submit(self) -> None:
        if self.search_open:
            self.search_open = False
            self.app.clear_text_focus()
            q = self.search_query.strip().lower()
            if q and self.groups:
                for t in self.groups[0].tiles:
                    if q in t.label.lower() and t.action:
                        try:
                            t.action()
                        except Exception:
                            pass
                        return
            self.app.toast("Не найдено" if q else "Поиск закрыт")

    def _grid_params(self) -> Tuple[int, int, int, int, int]:
        """margin, gap, base, col_step, max_cols — сетка на всю ширину."""
        w, h = self.app.screen.get_size()
        gap = 10
        side_pad = 16
        grid_cols = max(3, min(6, int(self.app.settings.get("grid_cols", 4))))
        # Android Auto / альбомная — больше столбцов
        if self.app.settings.get("android_auto") or w > h:
            grid_cols = max(grid_cols, 6)
            grid_cols = min(8, grid_cols)
        scale = float(self.app.settings.get("icon_scale", 1.0))
        avail = max(120, w - 2 * side_pad)
        base = int((avail - (grid_cols - 1) * gap) / grid_cols)
        base = max(48, int(base * scale))
        col_step = base + gap
        max_cols = grid_cols
        used = max_cols * base + (max_cols - 1) * gap
        margin = max(side_pad, (w - used) // 2)
        return margin, gap, base, col_step, max_cols

    def _fits(self, occ: List[List[bool]], col: int, row: int,
              tw: int, th: int, max_cols: int) -> bool:
        if col < 0 or row < 0 or col + tw > max_cols:
            return False
        for r in range(row, row + th):
            while len(occ) <= r:
                occ.append([False] * max_cols)
            for c in range(col, col + tw):
                if occ[r][c]:
                    return False
        return True

    def _mark(self, occ: List[List[bool]], col: int, row: int,
              tw: int, th: int, max_cols: int) -> None:
        for r in range(row, row + th):
            while len(occ) <= r:
                occ.append([False] * max_cols)
            for c in range(col, col + tw):
                occ[r][c] = True

    def _find_free(self, occ: List[List[bool]], tw: int, th: int,
                   max_cols: int, prefer: Optional[Tuple[int, int]] = None
                   ) -> Tuple[int, int]:
        """Ищет свободное место без наложения. prefer = (col, row) если свободно."""
        if prefer is not None:
            pc, pr = prefer
            if self._fits(occ, pc, pr, tw, th, max_cols):
                return pc, pr
        max_rows_scan = max(len(occ) + th + 8, 24)
        for r in range(max_rows_scan):
            for c in range(max_cols):
                if self._fits(occ, c, r, tw, th, max_cols):
                    return c, r
        return 0, max(0, len(occ))

    def _layout(self) -> None:
        w, h = self.app.screen.get_size()
        margin, gap, base, col_step, max_cols = self._grid_params()
        self._layout_margin = margin
        self._layout_gap = gap
        self._layout_base = base
        self._layout_col_step = col_step
        self._layout_max_cols = max_cols
        self._layout_origin_y = 130  # место под часы ColorOS

        page = int(self.app.settings.get("home_page", 0) or 0)
        positions = dict(self.app.settings.get("tile_positions") or {})
        new_positions: Dict[str, Dict[str, int]] = dict(positions)
        occ: List[List[bool]] = []

        all_tiles = list(self.groups[0].tiles) if self.groups else []
        # плитки текущей страницы
        pending = []
        for tile in all_tiles:
            pos = positions.get(tile.tag)
            p = 0
            if isinstance(pos, dict):
                try:
                    p = int(pos.get("page", 0))
                except (TypeError, ValueError):
                    p = 0
            if p == page:
                pending.append(tile)

        placed: List[Tile] = []
        still: List[Tile] = []
        for tile in pending:
            tw, th = tile.size.cols, tile.size.rows
            pref = None
            pos = positions.get(tile.tag)
            if isinstance(pos, dict):
                try:
                    pref = (int(pos.get("col", 0)), int(pos.get("row", 0)))
                except (TypeError, ValueError):
                    pref = None
            if pref is not None and self._fits(occ, pref[0], pref[1], tw, th, max_cols):
                col, row = pref
                self._mark(occ, col, row, tw, th, max_cols)
                new_positions[tile.tag] = {"col": col, "row": row, "page": page}
                x = margin + col * col_step
                ty = self._layout_origin_y + row * col_step
                tw_px = tw * base + (tw - 1) * gap
                th_px = th * base + (th - 1) * gap
                tile.rect = pygame.Rect(x, ty, tw_px, th_px)
                placed.append(tile)
            else:
                still.append(tile)

        for tile in still:
            # на странице > 0 новые плитки не авто-раскладываем на главную
            tw, th = tile.size.cols, tile.size.rows
            col, row = self._find_free(occ, tw, th, max_cols)
            self._mark(occ, col, row, tw, th, max_cols)
            new_positions[tile.tag] = {"col": col, "row": row, "page": page}
            x = margin + col * col_step
            ty = self._layout_origin_y + row * col_step
            tw_px = tw * base + (tw - 1) * gap
            th_px = th * base + (th - 1) * gap
            tile.rect = pygame.Rect(x, ty, tw_px, th_px)
            placed.append(tile)

        # остальные страницы — rect вне экрана (не кликабельны)
        for tile in all_tiles:
            if tile in placed:
                continue
            tile.rect = pygame.Rect(-5000, -5000, 1, 1)

        if self.groups:
            self.groups[0].tiles = all_tiles
            max_row = 0
            for t in placed:
                p = new_positions.get(t.tag, {"row": 0})
                max_row = max(max_row, int(p.get("row", 0)) + t.size.rows)
            group_bottom = self._layout_origin_y + max_row * col_step + 12
            self.groups[0].rect = pygame.Rect(
                margin, 56, w - 2 * margin, max(80, group_bottom - 56))
        else:
            group_bottom = 100

        self.app.settings.set("tile_positions", new_positions)
        self._page_tiles = placed

        self._exit_rect = None
        total_h = group_bottom + 50
        self.max_scroll = max(0, total_h - h)
        self._bg_surface = None

    def _cell_at(self, pos: Tuple[int, int]) -> Tuple[int, int]:
        """Экранные координаты → (col, row) сетки."""
        margin = getattr(self, "_layout_margin", 10)
        col_step = getattr(self, "_layout_col_step", 80)
        origin_y = getattr(self, "_layout_origin_y", 86)
        max_cols = getattr(self, "_layout_max_cols", 4)
        px, py = pos[0], pos[1] + self.scroll
        col = int((px - margin) // max(1, col_step))
        row = int((py - origin_y) // max(1, col_step))
        col = max(0, min(max_cols - 1, col))
        row = max(0, row)
        return col, row

    def on_resize(self) -> None:
        self._bg_surface = None
        self._layout()

    def _ensure_background(self, w: int, h: int) -> None:
        wp = self.app.settings.get("wallpaper", "default")
        key = (w, h, wp, self.app.settings.get("theme", "dark"))
        if self._bg_surface is not None and getattr(self, "_bg_key", None) == key:
            return
        self._bg_key = key
        self._bg_size = (w, h)
        bg = pygame.Surface((w, h))
        grads = WALLPAPERS.get(wp)
        if grads is None:
            top, bot = BG_GRAD_TOP, BG_GRAD_BOTTOM
        else:
            top, bot = grads
        for y in range(h):
            t = y / max(1, h - 1)
            color = lerp_color(top, bot, t)
            pygame.draw.line(bg, color, (0, y), (w, y))
        self._bg_surface = bg

    def update(self, dt: float) -> None:
        need = False
        if self.animations_on():
            for g in self.groups:
                for t in g.tiles:
                    if t.press > 0:
                        t.press = max(0.0, t.press - dt * 5)
                        need = True
        else:
            for g in self.groups:
                for t in g.tiles:
                    t.press = 0.0

        # анимация смены страницы
        if abs(self.page_anim_x) > 0.5:
            speed = 12.0
            self.page_anim_x += (0.0 - self.page_anim_x) * min(1.0, speed * dt)
            if abs(self.page_anim_x) < 1.0:
                self.page_anim_x = 0.0
            need = True
        elif self.page_anim_x != 0.0:
            self.page_anim_x = 0.0
            need = True

        # часы — раз в секунду, не каждый кадр
        sec = int(time.time())
        if sec != self._last_clock_sec:
            self._last_clock_sec = sec
            need = True

        if self._hold_tile and self._dragging_tile is None:
            if time.time() - self._hold_start >= 0.45:
                self._dragging_tile = self._hold_tile
                self._reorder_mode = True
                self._sys_msg = None
                need = True

        if self._sys_msg and time.time() > self._sys_msg_until:
            self._sys_msg = None
            need = True

        if self._dragging_tile is not None:
            need = True

        if need:
            self.redraw()

    def _finger_dist(self) -> float:
        if len(self._fingers) < 2:
            return 0.0
        pts = list(self._fingers.values())
        dx = pts[0][0] - pts[1][0]
        dy = pts[0][1] - pts[1][1]
        return (dx * dx + dy * dy) ** 0.5

    def _goto_page(self, page: int) -> None:
        count = int(self.app.settings.get("home_page_count", 1) or 1)
        page = max(0, min(count - 1, page))
        cur = int(self.app.settings.get("home_page", 0) or 0)
        if page == cur:
            return
        w = self.app.screen.get_width()
        # новая страница заезжает слева/справа
        if self.animations_on():
            self.page_anim_x = float(w if page > cur else -w)
        else:
            self.page_anim_x = 0.0
        self.app.settings.set("home_page", page)
        self.scroll = 0
        self.rebuild()
        self.app.toast(f"Страница {page + 1}/{count}")

    def _create_page(self) -> None:
        count = int(self.app.settings.get("home_page_count", 1) or 1)
        if count >= 5:
            self.app.toast("Максимум 5 страниц", WARNING)
            return
        count += 1
        w = self.app.screen.get_width()
        if self.animations_on():
            self.page_anim_x = float(w)
        else:
            self.page_anim_x = 0.0
        self.app.settings.set("home_page_count", count)
        self.app.settings.set("home_page", count - 1)
        self.pinch_panel = False
        self.scroll = 0
        self.rebuild()
        self.app.toast(f"Страница {count} создана", SUCCESS)

    def handle_event(self, event: pygame.event.Event) -> None:
        super().handle_event(event)
        w, h = self.app.screen.get_size()

        # Мультитач: сведение двух пальцев → панель
        if event.type == pygame.FINGERDOWN:
            self._fingers[event.finger_id] = (event.x * w, event.y * h)
            if len(self._fingers) == 2:
                self._pinch_start_dist = self._finger_dist()
                pts = list(self._fingers.values())
                self._pinch_mid_x = (pts[0][0] + pts[1][0]) / 2
        elif event.type == pygame.FINGERUP:
            # после pinch: два пальца свайп влево → создать/следующая
            if len(self._fingers) == 2 and self.pinch_panel:
                pass
            self._fingers.pop(event.finger_id, None)
        elif event.type == pygame.FINGERMOTION:
            self._fingers[event.finger_id] = (event.x * w, event.y * h)
            if len(self._fingers) == 2 and self._pinch_start_dist > 40:
                dist = self._finger_dist()
                if dist < self._pinch_start_dist * 0.7:
                    self.pinch_panel = True
                    self._pinch_start_dist = dist
                    self.redraw()
                # два пальца сдвиг влево/вправо — листание/создание
                pts = list(self._fingers.values())
                mid_x = (pts[0][0] + pts[1][0]) / 2
                start_mid = getattr(self, "_pinch_mid_x", mid_x)
                if self.pinch_panel and mid_x < start_mid - 80:
                    self._pinch_mid_x = mid_x
                    count = int(self.app.settings.get("home_page_count", 1) or 1)
                    cur = int(self.app.settings.get("home_page", 0) or 0)
                    if cur >= count - 1 and count < 5:
                        # на краю — предложить создать (кнопка уже в панели)
                        self.app.toast("Нажмите «Страница» чтобы создать", ACCENT)
                    elif cur < count - 1:
                        self._goto_page(cur + 1)
                elif self.pinch_panel and mid_x > start_mid + 80:
                    self._pinch_mid_x = mid_x
                    cur = int(self.app.settings.get("home_page", 0) or 0)
                    if cur > 0:
                        self._goto_page(cur - 1)

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self._swipe_x0 = event.pos[0]
            self._swipe_y0 = event.pos[1]
            # меню выбора размера
            if self._size_target and self._size_menu_rects:
                for rect, (c, r) in self._size_menu_rects:
                    if rect.collidepoint(event.pos):
                        self._apply_tile_size(self._size_target, c, r)
                        self._size_target = None
                        self.size_mode = False
                        return
                # тап мимо — отмена меню
                self._size_target = None
                return

            # кнопки панели pinch
            if self.pinch_panel:
                for key, rect in self._panel_rects.items():
                    if rect.collidepoint(event.pos):
                        if key == "wallpaper":
                            self.app.show_screen("wallpaper")
                        elif key == "size":
                            self.size_mode = True
                            self._size_target = None
                            self.app.toast("Выберите плитку для размера", ACCENT)
                        elif key == "screen":
                            self.app.show_screen("screen")
                        elif key == "page":
                            self._create_page()
                        elif key == "close":
                            self.pinch_panel = False
                            self.size_mode = False
                            self._size_target = None
                            self.search_open = False
                            self.search_query = ""
                        return

            # Режим размера: тап по плитке → список размеров
            if self.size_mode and not self._dragging_tile:
                tile = self._tile_at(event.pos)
                if tile and tile.tag != "EXIT":
                    self._size_target = tile.tag
                    self.redraw()
                    return

            # После pinch: зажать любую плитку → перетаскивание
            if self.pinch_panel and not self._dragging_tile:
                tile = self._tile_at(event.pos)
                if tile:
                    self._hold_tile = tile
                    self._hold_start = time.time()
                    shifted = tile.rect.move(0, -self.scroll)
                    self._drag_offset = (
                        event.pos[0] - shifted.x,
                        event.pos[1] - shifted.y,
                    )
                    self._drag_pos = event.pos
                    self.dragging = False
                    return

            if self.edit_mode:
                tile = self._tile_at(event.pos)
                if tile and tile.tag not in ("EXIT",):
                    if is_protected_tag(tile.tag):
                        self._cycle_tile_size(tile.tag)
                    else:
                        if event.pos[0] < tile.rect.centerx:
                            self._hide_tile(tile.tag)
                        else:
                            self._cycle_tile_size(tile.tag)
                    return
            self.drag_start_y = event.pos[1]
            self.drag_start_scroll = self.scroll
            self.dragging = True

        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            if self._dragging_tile is not None:
                tile = self._dragging_tile
                if (self._trash_rect and
                        self._trash_rect.collidepoint(event.pos)):
                    if is_protected_tag(tile.tag):
                        self._sys_msg = "Это системное приложение — его нельзя удалить"
                        self._sys_msg_until = time.time() + 2.2
                    else:
                        self._hide_tile(tile.tag)
                        self.app.toast("Удалено", SUCCESS)
                else:
                    target = self._tile_at(event.pos)
                    if target and target is not tile:
                        self._reorder_tiles(tile.tag, target.tag)
                    else:
                        # пустое место — ставим в клетку под пальцем
                        col, row = self._cell_at(event.pos)
                        if self._place_tile_at(tile.tag, col, row):
                            self.app.toast("Позиция сохранена")
                        else:
                            self._save_current_order()
                self._dragging_tile = None
                self._hold_tile = None
                self._reorder_mode = False
                self.redraw()
                return

            if self._hold_tile is not None:
                tile = self._hold_tile
                held = time.time() - self._hold_start
                self._hold_tile = None
                if held < 0.45 and tile.action and not self.edit_mode and not self.size_mode:
                    try:
                        tile.action()
                    except Exception as e:
                        dbg("Tile action error:", e)
                return

            was_dragging = self.dragging
            moved = abs(event.pos[1] - self.drag_start_y) if was_dragging else 0
            self.dragging = False
            # горизонтальный свайп — смена страницы
            if (self._swipe_x0 is not None and not self._dragging_tile
                    and not self.edit_mode and not self.size_mode):
                dx = event.pos[0] - self._swipe_x0
                dy = event.pos[1] - (self._swipe_y0 or event.pos[1])
                self._swipe_x0 = None
                self._swipe_y0 = None
                if abs(dx) > 70 and abs(dx) > abs(dy) * 1.2:
                    cur = int(self.app.settings.get("home_page", 0) or 0)
                    count = int(self.app.settings.get("home_page_count", 1) or 1)
                    if dx < 0 and cur < count - 1:
                        self._goto_page(cur + 1)
                        return
                    if dx > 0 and cur > 0:
                        self._goto_page(cur - 1)
                        return
                    if dx < 0 and cur >= count - 1:
                        self.app.toast("Сведите 2 пальца → «Страница»", ACCENT)
                        return
            self._swipe_x0 = None
            if self.edit_mode or self.size_mode:
                return
            if moved < 10:
                tile = self._tile_at(event.pos)
                if tile and tile.action:
                    if self.animations_on():
                        tile.press = 1.0
                    try:
                        tile.action()
                    except Exception as e:
                        dbg("Tile action error:", e)
                        LOG.error("UI", f"Tile {tile.tag}: {e}")

        elif event.type == pygame.MOUSEMOTION:
            if self._hold_tile and self._dragging_tile is None:
                if abs(event.pos[1] - self._drag_pos[1]) > 12 or \
                        abs(event.pos[0] - self._drag_pos[0]) > 12:
                    # лёгкий сдвиг — всё равно ждём long-press, обновляем позицию
                    self._drag_pos = event.pos
            if self._dragging_tile is not None:
                self._drag_pos = event.pos
                self.redraw()
            elif self.dragging:
                dy = event.pos[1] - self.drag_start_y
                if abs(dy) > 6:
                    self.scroll = max(0, min(self.max_scroll,
                                             self.drag_start_scroll - dy))

    def _tile_at(self, pos: Tuple[int, int]) -> Optional[Tile]:
        px, py = pos
        for g in self.groups:
            for t in g.tiles:
                shifted = t.rect.move(0, -self.scroll)
                if shifted.collidepoint(px, py):
                    return t
        return None

    def _hide_tile(self, tag: str) -> None:
        if is_protected_tag(tag):
            self.app.toast("Это системное приложение — его нельзя удалить", WARNING)
            return
        # плитки из маркета убираем из desktop_apps
        positions = dict(self.app.settings.get("tile_positions") or {})
        positions.pop(tag, None)
        self.app.settings.set("tile_positions", positions)
        if tag.startswith("MKT_"):
            apps = [
                a for a in (self.app.settings.get("desktop_apps") or [])
                if a.get("tag") != tag
            ]
            self.app.settings.set("desktop_apps", apps)
            order = [t for t in (self.app.settings.get("tile_order") or []) if t != tag]
            self.app.settings.set("tile_order", order)
            self.rebuild()
            self.app.toast("Удалено с экрана")
            return
        hidden = list(self.app.settings.get("hidden_tiles") or [])
        if tag not in hidden:
            hidden.append(tag)
            self.app.settings.set("hidden_tiles", hidden)
            self.rebuild()
            self.app.toast("Удалено с экрана")

    def _cycle_tile_size(self, tag: str) -> None:
        sizes = dict(self.app.settings.get("tile_sizes") or {})
        cur = sizes.get(tag, {"cols": 1, "rows": 1})
        try:
            idx = TILE_SIZE_PRESETS.index(
                (int(cur.get("cols", 1)), int(cur.get("rows", 1))))
        except ValueError:
            idx = 0
        nc, nr = TILE_SIZE_PRESETS[(idx + 1) % len(TILE_SIZE_PRESETS)]
        self._apply_tile_size(tag, nc, nr)

    def _apply_tile_size(self, tag: str, cols: int, rows: int) -> None:
        sizes = dict(self.app.settings.get("tile_sizes") or {})
        sizes[tag] = {"cols": max(1, min(3, cols)), "rows": max(1, min(3, rows))}
        self.app.settings.set("tile_sizes", sizes)
        self.rebuild()
        self.app.toast(f"Размер {cols}/{rows}")

    def _save_current_order(self) -> None:
        if not self.groups:
            return
        order = [t.tag for t in self.groups[0].tiles]
        self.app.settings.set("tile_order", order)

    def _place_tile_at(self, drag_tag: str, col: int, row: int) -> bool:
        """Ставит плитку в (col,row), если место свободно (без наложения)."""
        if not self.groups:
            return False
        tile = next((t for t in self.groups[0].tiles if t.tag == drag_tag), None)
        if not tile:
            return False
        max_cols = getattr(self, "_layout_max_cols", 4)
        tw, th = tile.size.cols, tile.size.rows
        if col + tw > max_cols:
            col = max(0, max_cols - tw)

        positions = dict(self.app.settings.get("tile_positions") or {})
        page = int(self.app.settings.get("home_page", 0) or 0)
        # занятость без текущей плитки (только эта страница)
        occ: List[List[bool]] = []
        for t in self.groups[0].tiles:
            if t.tag == drag_tag:
                continue
            p = positions.get(t.tag)
            if not isinstance(p, dict):
                continue
            try:
                if int(p.get("page", 0)) != page:
                    continue
                c0, r0 = int(p.get("col", 0)), int(p.get("row", 0))
            except (TypeError, ValueError):
                continue
            self._mark(occ, c0, r0, t.size.cols, t.size.rows, max_cols)

        if not self._fits(occ, col, row, tw, th, max_cols):
            col, row = self._find_free(occ, tw, th, max_cols, prefer=(col, row))

        positions[drag_tag] = {"col": col, "row": row, "page": page}
        self.app.settings.set("tile_positions", positions)
        # порядок: эта плитка ближе к началу по позиции
        order = [t.tag for t in self.groups[0].tiles]
        if drag_tag in order:
            order.remove(drag_tag)
            # вставить по строке/столбцу
            insert_at = 0
            for i, tag in enumerate(order):
                p = positions.get(tag, {})
                pr, pc = int(p.get("row", 0)), int(p.get("col", 0))
                if (pr, pc) > (row, col):
                    insert_at = i
                    break
                insert_at = i + 1
            order.insert(insert_at, drag_tag)
        self.app.settings.set("tile_order", order)
        self.rebuild()
        return True

    def _reorder_tiles(self, drag_tag: str, target_tag: str) -> None:
        """Перенос на клетку цели (или swap позиций, если цель одна 1×1)."""
        positions = dict(self.app.settings.get("tile_positions") or {})
        tp = positions.get(target_tag)
        if isinstance(tp, dict):
            try:
                col, row = int(tp.get("col", 0)), int(tp.get("row", 0))
            except (TypeError, ValueError):
                col, row = 0, 0
            # освободить клетку цели: цель уйдёт в авто-поиск
            if target_tag in positions:
                del positions[target_tag]
            self.app.settings.set("tile_positions", positions)
            self._place_tile_at(drag_tag, col, row)
            # цель переразместится при rebuild через _find_free
            self.app.toast("Позиция сохранена")
            return
        # fallback — смена порядка в списке
        if not self.groups:
            return
        tags = [t.tag for t in self.groups[0].tiles]
        if drag_tag not in tags or target_tag not in tags:
            return
        tags.remove(drag_tag)
        idx = tags.index(target_tag)
        tags.insert(idx, drag_tag)
        self.app.settings.set("tile_order", tags)
        # сбросить позиции чтобы упаковать заново без наложений
        self.app.settings.set("tile_positions", {})
        self.rebuild()
        self.app.toast("Порядок сохранён")

    def draw(self, surface: pygame.Surface) -> None:
        w, h = surface.get_size()
        self._ensure_background(w, h)
        surface.blit(self._bg_surface, (0, 0))

        # --- шапка ColorOS: крупные часы ---
        now = datetime.datetime.now()
        clock_font = self.app.font("ui", 42, bold=True)
        clock_text = now.strftime("%H:%M")
        clock_surf = clock_font.render(clock_text, True, TEXT_BRIGHT)
        surface.blit(clock_surf, ((w - clock_surf.get_width()) // 2, 10))

        weekdays = ["пн", "вт", "ср", "чт", "пт", "сб", "вс"]
        date_font = self.app.font("ui", 13)
        date_text = f"{weekdays[now.weekday()]}, {now.strftime('%d.%m.%Y')}"
        date_surf = date_font.render(date_text, True, TEXT_DIM)
        surface.blit(date_surf, ((w - date_surf.get_width()) // 2, 58))

        if self.app.settings.get("widgets", True):
            now_t = time.time()
            cached, ts = self._widget_cache
            if not cached or now_t - ts > 30.0:
                parts = []
                bat = read_battery_percent()
                city = read_weather_cache()
                if bat is not None:
                    parts.append(f"{bat}%")
                if city:
                    parts.append(str(city))
                cached = " · ".join(parts)
                self._widget_cache = (cached, now_t)
            if cached:
                wf = self.app.font("ui", 12)
                ws = wf.render(cached, True, TEXT_DIM)
                surface.blit(ws, ((w - ws.get_width()) // 2, 80))

        for g in self.groups:
            for tile in g.tiles:
                if self._dragging_tile is tile:
                    continue
                self._draw_tile(surface, tile)
                if self.edit_mode:
                    r = tile.rect.move(0, -self.scroll)
                    if r.bottom > 0 and r.top < h:
                        mark = self.app.font("ui", 14, bold=True).render(
                            "×", True, (255, 180, 180))
                        surface.blit(mark, (r.right - 18, r.y + 2))

        if self.edit_mode:
            badge = self.app.font("ui", 12, bold=True).render(
                "РЕДАКТИРОВАНИЕ · тап: удалить / размер", True, WARNING)
            surface.blit(badge, (10, h - NAV_BAR_H - 22))

        # Корзина сверху по центру при перетаскивании
        self._trash_rect = None
        if self._dragging_tile is not None:
            tw, th = 160, 44
            tr = pygame.Rect((w - tw) // 2, 8, tw, th)
            self._trash_rect = tr
            over = tr.collidepoint(self._drag_pos)
            col = (180, 40, 40) if over else (120, 50, 50)
            pygame.draw.rect(surface, col, tr, border_radius=12)
            pygame.draw.rect(surface, (255, 120, 120), tr, width=2,
                             border_radius=12)
            tf = self.app.font("ui", 16, bold=True)
            ts = tf.render("Корзина", True, (255, 255, 255))
            surface.blit(ts, ts.get_rect(center=tr.center))

            # призрак иконки
            tile = self._dragging_tile
            gx = self._drag_pos[0] - self._drag_offset[0]
            gy = self._drag_pos[1] - self._drag_offset[1]
            ghost = pygame.Rect(gx, gy, tile.rect.w, tile.rect.h)
            self._draw_coloros_icon(surface, ghost, tile, ghost_mode=True)

        if self._sys_msg:
            mf = self.app.font("ui", 13, bold=True)
            ms = mf.render(self._sys_msg, True, (255, 220, 180))
            bg = pygame.Rect(0, 0, ms.get_width() + 24, ms.get_height() + 16)
            bg.center = (w // 2, 36)
            pygame.draw.rect(surface, (60, 40, 20), bg, border_radius=10)
            surface.blit(ms, ms.get_rect(center=bg.center))

        # индикатор страниц ColorOS
        page = int(self.app.settings.get("home_page", 0) or 0)
        count = int(self.app.settings.get("home_page_count", 1) or 1)
        if count > 1:
            dot_y = h - NAV_BAR_H - 14
            total_w = count * 12 + (count - 1) * 8
            dx0 = (w - total_w) // 2
            for i in range(count):
                r = 5 if i == page else 3
                col = TEXT_BRIGHT if i == page else TEXT_DIM
                pygame.draw.circle(surface, col, (dx0 + i * 20 + 5, dot_y), r)

        # пустая доп. страница
        if page > 0 and not getattr(self, "_page_tiles", None):
            empty = self.app.font("ui", 14).render(
                "Пустая страница — перетащите сюда приложения", True, TEXT_DIM)
            surface.blit(empty, empty.get_rect(
                center=(w // 2 + int(self.page_anim_x), h // 2)))

        # Панель: Обои | Размер | Страница | Экран
        self._panel_rects = {}
        if self.pinch_panel and self._dragging_tile is None and not self._size_target:
            bw, bh = 88, 48
            gap = 6
            keys = [
                ("wallpaper", "Обои", (50, 90, 140)),
                ("size", "Размер", (40, 120, 90) if not self.size_mode else (80, 160, 100)),
                ("page", "Страница", (100, 80, 40)),
                ("screen", "Экран", (70, 70, 120)),
            ]
            total = bw * len(keys) + gap * (len(keys) - 1)
            bx = max(8, (w - total - 50) // 2)
            by = h - NAV_BAR_H - bh - 20
            f = self.app.font("ui", 12, bold=True)
            for i, (key, label, col) in enumerate(keys):
                r = pygame.Rect(bx + i * (bw + gap), by, bw, bh)
                pygame.draw.rect(surface, col, r, border_radius=10)
                ts = f.render(label, True, (255, 255, 255))
                surface.blit(ts, ts.get_rect(center=r.center))
                self._panel_rects[key] = r
            cr = pygame.Rect(w - 50, by, 40, bh)
            pygame.draw.rect(surface, (90, 50, 50), cr, border_radius=8)
            xs = f.render("×", True, (255, 255, 255))
            surface.blit(xs, xs.get_rect(center=cr.center))
            self._panel_rects["close"] = cr

        if self.size_mode and not self._size_target:
            hint = self.app.font("ui", 12, bold=True).render(
                "Выберите плитку — затем размер", True, SUCCESS)
            surface.blit(hint, (10, h - NAV_BAR_H - 72))

        # Список размеров столбиком
        self._size_menu_rects = []
        if self._size_target:
            mw, mh = 120, 40
            my = 70
            mx = (w - mw) // 2
            title = self.app.font("ui", 14, bold=True).render(
                f"Размер: {self._size_target}", True, TEXT_BRIGHT)
            surface.blit(title, title.get_rect(centerx=w // 2, y=48))
            for cols, rows in TILE_SIZE_PRESETS:
                rect = pygame.Rect(mx, my, mw, mh)
                self._size_menu_rects.append((rect, (cols, rows)))
                pygame.draw.rect(surface, (40, 50, 70), rect, border_radius=8)
                pygame.draw.rect(surface, ACCENT, rect, width=1, border_radius=8)
                lab = self.app.font("ui", 15, bold=True).render(
                    f"{cols}/{rows}", True, TEXT_BRIGHT)
                surface.blit(lab, lab.get_rect(center=rect.center))
                my += mh + 6

        self._draw_scrollbar(surface, w, h)
        self._needs_redraw = False

    def _draw_coloros_icon(self, surface, rect, tile, ghost_mode: bool = False):
        """Иконка ColorOS 5: скруглённый квадрат + подпись снизу."""
        label_h = max(16, min(22, rect.h // 5))
        pad = max(4, rect.w // 16)
        # область иконки (квадрат сверху)
        side = min(rect.w - pad * 2, rect.h - label_h - pad * 2)
        side = max(28, side)
        icon = pygame.Rect(0, 0, side, side)
        icon.centerx = rect.centerx
        icon.y = rect.y + pad

        # тень без Surface (быстрее)
        radius = max(12, side // 5)
        if not ghost_mode:
            pygame.draw.rect(surface, (0, 0, 0), icon.move(0, 3), border_radius=radius)
        pygame.draw.rect(surface, tile.color, icon, border_radius=radius)

        # буква / короткий label
        letter = (tile.label or "?").strip()[:1].upper()
        lf = self.app.font("ui", max(16, side // 2), bold=True)
        ls = lf.render(letter, True, (255, 255, 255))
        surface.blit(ls, ls.get_rect(center=icon.center))

        # подпись под иконкой
        lab_font = self.app.font("ui", max(11, label_h - 4))
        text = truncate_text(tile.label or "", lab_font, rect.w - 4)
        ts = lab_font.render(text, True, TEXT_BRIGHT)
        surface.blit(ts, (rect.centerx - ts.get_width() // 2,
                          icon.bottom + 4))

    def _draw_tile(self, surface, tile):
        ox = int(self.page_anim_x)
        rect = tile.rect.move(ox, -self.scroll)
        if rect.bottom < 0 or rect.top > surface.get_height():
            return
        if rect.right < 0 or rect.left > surface.get_width():
            return
        shrink = int(4 * tile.press) if self.animations_on() else 0
        draw_rect = rect.inflate(-shrink, -shrink)
        self._draw_coloros_icon(surface, draw_rect, tile)

    def _draw_scrollbar(self, surface, w, h):
        if self.max_scroll <= 0:
            return
        track_h = h - 80 - NAV_BAR_H
        thumb_h = max(40, int(track_h * h / (h + self.max_scroll)))
        max_y = track_h - thumb_h
        thumb_y = 60 + int(max_y * (self.scroll / self.max_scroll))
        bar = pygame.Rect(w - 6, thumb_y, 4, thumb_h)
        pygame.draw.rect(surface, SCROLL_FG, bar, border_radius=2)


