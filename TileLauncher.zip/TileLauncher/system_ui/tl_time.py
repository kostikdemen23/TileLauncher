#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Часы / время."""
from __future__ import annotations

import calendar
import datetime
import time
from typing import Any, List, Optional, Tuple

import pygame

from tl_core import *
from tl_widgets import BaseScreen, TouchButton

class TimeScreen(BaseScreen):
    def __init__(self, app):
        super().__init__(app)
        self.buttons = [
            TouchButton("Назад", app.back_to_menu,
                        color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 90, 36)),
        ]
        today = datetime.date.today()
        self.view_year = today.year
        self.view_month = today.month
        self._prev_rect = pygame.Rect(30, 200, 50, 40)
        self._next_rect = pygame.Rect(0, 200, 50, 40)
        self._today_rect = pygame.Rect(0, 0, 140, 40)

    def handle_event(self, event):
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return
        for b in self.buttons:
            if b.handle_event(event):
                return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self._prev_rect.collidepoint(event.pos):
                self._change_month(-1)
                return
            if self._next_rect.collidepoint(event.pos):
                self._change_month(1)
                return
            if self._today_rect.collidepoint(event.pos):
                today = datetime.date.today()
                self.view_year = today.year
                self.view_month = today.month
                return

    def _change_month(self, delta):
        m = self.view_month + delta
        y = self.view_year
        if m < 1:
            m = 12
            y -= 1
        elif m > 12:
            m = 1
            y += 1
        self.view_month = m
        self.view_year = y

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(PANEL_BG)
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)

        now = datetime.datetime.now()

        clock_font = self.app.font("mono", 64, bold=True)
        clock_text = now.strftime("%H:%M:%S")
        cs = clock_font.render(clock_text, True, TEXT_BRIGHT)
        surface.blit(cs, ((w - cs.get_width()) // 2, 60))

        date_font = self.app.font("ui", 16)
        date_text = now.strftime("%d.%m.%Y  %H:%M")
        ds = date_font.render(date_text, True, TEXT_DIM)
        surface.blit(ds, ((w - ds.get_width()) // 2, 140))

        cal_y = 200
        title_font = self.app.font("ui", 18, bold=True)
        month_title = f"{MONTHS_RU[self.view_month]} {self.view_year}"
        mt = title_font.render(month_title, True, TEXT_BRIGHT)
        surface.blit(mt, ((w - mt.get_width()) // 2, cal_y))

        arrow_font = self.app.font("ui", 24, bold=True)
        prev_surf = arrow_font.render("<", True, ACCENT)
        next_surf = arrow_font.render(">", True, ACCENT)
        self._prev_rect = pygame.Rect(30, cal_y, 50, 40)
        self._next_rect = pygame.Rect(w - 80, cal_y, 50, 40)
        surface.blit(prev_surf,
                     prev_surf.get_rect(center=self._prev_rect.center))
        surface.blit(next_surf,
                     next_surf.get_rect(center=self._next_rect.center))

        cal = calendar.Calendar(firstweekday=0)
        month_days = list(cal.itermonthdates(self.view_year, self.view_month))

        grid_x = 20
        grid_y = cal_y + 50
        grid_w = w - 40
        cell_w = grid_w // 7
        cell_h = 44

        wd_font = self.app.font("ui", 13, bold=True)
        for i, name in enumerate(WEEKDAYS_RU):
            color = (240, 120, 120) if i >= 5 else TEXT_DIM
            s = wd_font.render(name, True, color)
            x = grid_x + i * cell_w + (cell_w - s.get_width()) // 2
            surface.blit(s, (x, grid_y))

        num_font = self.app.font("mono", 16, bold=True)
        today = datetime.date.today()
        y = grid_y + 28
        for week_start in range(0, len(month_days), 7):
            week = month_days[week_start:week_start + 7]
            for i, day in enumerate(week):
                if day.month != self.view_month:
                    color = (70, 70, 90)
                elif day == today:
                    color = ACCENT
                elif day.weekday() >= 5:
                    color = (240, 120, 120)
                else:
                    color = TEXT_BRIGHT

                cell_rect = pygame.Rect(grid_x + i * cell_w, y,
                                        cell_w, cell_h - 4)
                if day == today:
                    pygame.draw.rect(surface, (30, 60, 110),
                                     cell_rect, border_radius=6)
                    pygame.draw.rect(surface, ACCENT, cell_rect,
                                     width=2, border_radius=6)

                s = num_font.render(str(day.day), True, color)
                x = cell_rect.x + (cell_w - s.get_width()) // 2
                ty = cell_rect.y + (cell_h - 4 - s.get_height()) // 2
                surface.blit(s, (x, ty))
            y += cell_h


