#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Файлы: проводник, редактор, консоль, просмотр, галерея, run."""
from __future__ import annotations

import os
import subprocess
import sys
import threading
import time
import traceback
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional, Tuple

import pygame

from tl_core import *
from tl_widgets import BaseScreen, TouchButton, TextInput, ScrollList

# ============================================================================
# ВЫПОЛНЕНИЕ — с полем ввода stdin
# ============================================================================

class RunScreen(BaseScreen):
    MAX_LINES = 500

    def __init__(self, app: "App") -> None:
        super().__init__(app)
        self.lines: List[Tuple[str, Tuple[int, int, int]]] = []
        self.process: Optional[subprocess.Popen] = None
        self.lock = threading.Lock()
        self.auto_scroll = True
        self.start_time = 0.0
        self.end_time = 0.0
        self.exit_code: Optional[int] = None
        self.running = False
        self.buttons: List[TouchButton] = []
        self.run_start_index = 0
        self.current_script: Optional[Path] = None
        # stdin-поле
        self.stdin_input: Optional[TextInput] = None
        self.stdin_rect = pygame.Rect(0, 0, 1, 1)
        self._build_buttons()

    def _build_buttons(self) -> None:
        bh = 38
        gap = 5
        self.buttons = []
        x = 6
        for label, cb, col, bw in [
            ("Стоп", self.stop, (170, 80, 80), 70),
            ("Очист.", self._clear, (70, 80, 100), 70),
            ("Копир.", self.copy_output, (60, 140, 100), 70),
            ("Отправить", self.send_input, (60, 160, 90), 100),
        ]:
            self.buttons.append(TouchButton(label, cb, color=col,
                                            rect=pygame.Rect(x, 6, bw, bh)))
            x += bw + gap

    # ------------------------------------------------------------------ #
    def send_input(self) -> None:
        """Пишет строку из stdin_input в stdin дочернего процесса."""
        if self.stdin_input is None:
            return

        proc = self.process
        if proc is None or proc.poll() is not None:
            self.app.toast("Процесс не запущен — ввод недоступен", WARNING)
            return

        text = self.stdin_input.text
        try:
            assert proc.stdin is not None
            data = (text + "\n").encode("utf-8", errors="replace")
            proc.stdin.write(data)
            proc.stdin.flush()
            self._append(f">>> {text}", ACCENT)
            LOG.info("RUN", f"stdin: {text}")
        except Exception as e:
            LOG.error("RUN", f"stdin error: {e}")
            self.app.toast(f"Ошибка ввода: {e}", ERROR, 2.5)

        self.stdin_input.text = ""
        self.auto_scroll = True

    def _submit_stdin(self, text: str) -> None:
        """Enter в поле — отправить."""
        self.send_input()

    # ------------------------------------------------------------------ #
    def copy_output(self) -> None:
        with self.lock:
            start = max(0, min(self.run_start_index, len(self.lines)))
            chunk = self.lines[start:]
            text = "\n".join(line for line, _ in chunk)
            total_lines = len(chunk)

        if not text.strip():
            self.app.toast("Нечего копировать", WARNING)
            return

        result = copy_to_clipboard(text)
        if result is True:
            self.app.toast(f"Скопировано {total_lines} строк", SUCCESS)
        elif result == "file":
            self.app.toast(
                f"Сохранено в clipboard.txt ({total_lines} стр.)",
                WARNING, duration=3.0,
            )
        else:
            preview = text[:60].replace("\n", " ")
            self.app.toast(f"Не удалось: {preview}...", ERROR, duration=3.0)

    def _clear(self) -> None:
        with self.lock:
            self.lines.clear()
            self.run_start_index = 0

    def start(self, script_path: Path) -> None:
        self.stop()
        script_path = Path(script_path).expanduser()
        try:
            script_path = script_path.resolve()
        except Exception:
            pass
        self.current_script = script_path

        with self.lock:
            self.lines.clear()
            self.exit_code = None
            self.running = True
            self.scroll = 0
            self.auto_scroll = True
            self.start_time = time.time()
            self.end_time = 0.0

        if not script_path.exists():
            self._append(f"Файл не найден: {script_path}", ERROR)
            with self.lock:
                self.running = False
                self.exit_code = -1
            self.app.toast("Скрипт не найден", ERROR)
            return

        header = f"$ python -u {script_path.name}"
        self._append(header, ACCENT)
        self._append(f"cwd: {script_path.parent}", TEXT_DIM)
        self._append("Ввод: поле внизу → «Отправить» или Enter", TEXT_DIM)
        LOG.info("RUN", header)

        with self.lock:
            self.run_start_index = len(self.lines)

        # автофокус поля ввода
        if self.stdin_input is not None:
            self.stdin_input.active = True
            self.app.set_text_focus(self.stdin_input)

        def worker() -> None:
            try:
                env = os.environ.copy()
                env["PYTHONIOENCODING"] = "utf-8"
                env["PYTHONUNBUFFERED"] = "1"
                env["PYTHONUTF8"] = "1"
                py = self.app.settings.get("python_path") or sys.executable
                if not py or not Path(str(py)).exists():
                    py = sys.executable

                # binary pipes — стабильнее на Android/Pydroid
                self.process = subprocess.Popen(
                    [str(py), "-u", str(script_path)],
                    stdin=subprocess.PIPE,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.STDOUT,
                    bufsize=0,
                    env=env,
                    cwd=str(script_path.parent),
                )
                assert self.process.stdout is not None
                while True:
                    raw = self.process.stdout.readline()
                    if not raw:
                        break
                    if isinstance(raw, bytes):
                        line = raw.decode("utf-8", errors="replace")
                    else:
                        line = str(raw)
                    clean = line.rstrip("\r\n")
                    self._append(clean, TEXT_BRIGHT)
                    try:
                        LOG.log("RUN", clean)
                    except Exception:
                        pass

                code = self.process.wait()
                with self.lock:
                    self.exit_code = code
                    self.running = False
                    self.end_time = time.time()
                if code == 0:
                    self._append(f"OK ({code})", SUCCESS)
                    LOG.info("RUN", f"OK ({code})")
                else:
                    self._append(f"FAIL ({code})", ERROR)
                    LOG.error("RUN", f"FAIL ({code})")
            except Exception as exc:
                self._append(f"Ошибка запуска: {exc}", ERROR)
                LOG.error("RUN", f"{exc}\n{traceback.format_exc()}")
                with self.lock:
                    self.running = False
                    self.exit_code = -1

        threading.Thread(target=worker, daemon=True).start()

    def stop(self) -> None:
        proc = self.process
        if proc and proc.poll() is None:
            try:
                proc.terminate()
                try:
                    proc.wait(timeout=2)
                except subprocess.TimeoutExpired:
                    proc.kill()
            except Exception:
                pass
            self._append("Остановлено", WARNING)
            LOG.info("RUN", "Процесс остановлен")
        with self.lock:
            self.running = False

    def _append(self, line: str, color: Tuple[int, int, int]) -> None:
        with self.lock:
            self.lines.append((line, color))
            if len(self.lines) > self.MAX_LINES:
                removed = len(self.lines) - self.MAX_LINES
                self.lines = self.lines[-self.MAX_LINES:]
                self.run_start_index = max(0, self.run_start_index - removed)

    # ------------------------------------------------------------------ #
    def apply_text_input(self, text: str) -> None:
        """Из App — когда фокус на stdin_input."""
        if self.stdin_input is not None and self.stdin_input.active:
            for ch in text:
                self.stdin_input.insert(ch)

    # ------------------------------------------------------------------ #
    def handle_event(self, event: pygame.event.Event) -> None:
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return

        # Кнопки
        for btn in self.buttons:
            if btn.handle_event(event):
                return

        # Поле ввода
        if self.stdin_input is not None:
            if self.stdin_input.handle_event(event):
                return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.dragging = True
            self.drag_start_y = event.pos[1]
            self.drag_start_scroll = self.scroll
            self.auto_scroll = False
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            dy = event.pos[1] - self.drag_start_y
            if abs(dy) > 6:
                self.scroll = max(0, self.drag_start_scroll - dy)

    def update(self, dt: float) -> None:
        for b in self.buttons:
            b.update(dt)
        if self.stdin_input is not None:
            self.stdin_input.update(dt)

    def draw(self, surface: pygame.Surface) -> None:
        w, h = surface.get_size()
        surface.fill(PANEL_BG)

        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)

        with self.lock:
            running = self.running
            code = self.exit_code
            elapsed = (self.end_time or time.time()) - self.start_time
            total = len(self.lines)
            copied_lines = max(0, total - self.run_start_index)

        status_font = self.app.font("ui", 12)
        if running:
            status, color = f"Работает {elapsed:.1f}s", SUCCESS
        elif code == 0:
            status, color = f"OK {elapsed:.1f}s", SUCCESS
        elif code is None:
            status, color = "Ожидание", TEXT_DIM
        else:
            status, color = f"FAIL {code}", ERROR

        ss = status_font.render(status, True, color)
        surface.blit(ss, (w - ss.get_width() - 8, 16))

        hint_font = self.app.font("ui", 10)
        hint = hint_font.render(f"Копир. -> {copied_lines} стр.",
                                True, TEXT_DIM)
        surface.blit(hint, (w - hint.get_width() - 8, 34))

        # Область вывода — оставляем место для поля ввода
        vk_h = self.app.vk.rect.height if self.app.vk.visible else 0
        input_h = 46
        out_rect = pygame.Rect(6, 52, w - 12,
                               h - 52 - NAV_BAR_H - vk_h - input_h - 10)
        if out_rect.height < 60:
            out_rect.height = 60
        pygame.draw.rect(surface, (10, 12, 16), out_rect, border_radius=6)

        font = self.app.font("mono", 12)
        line_h = font.get_linesize()

        visible = out_rect.height // line_h - 1
        if self.auto_scroll:
            self.scroll = max(0, total - visible)
        max_scroll = max(0, total - visible)
        self.scroll = min(self.scroll, max_scroll)

        start = self.scroll
        end = min(total, start + visible + 1)

        prev_clip = surface.get_clip()
        surface.set_clip(out_rect.inflate(-6, -6))
        y = out_rect.y + 6
        with self.lock:
            n = len(self.lines)
            for i in range(start, end):
                if i >= n:
                    break
                line, color = self.lines[i]
                if i >= self.run_start_index and line.strip():
                    pygame.draw.rect(surface, (40, 70, 120),
                                     pygame.Rect(out_rect.x + 2, y, 3,
                                                 line_h - 2))
                line = truncate_text(line, font, out_rect.width - 24)
                ts = font.render(line, True, color)
                surface.blit(ts, (out_rect.x + 12, y))
                y += line_h
        surface.set_clip(prev_clip)

        # Поле ввода
        input_y = h - NAV_BAR_H - vk_h - input_h - 4
        self.stdin_rect = pygame.Rect(6, input_y, w - 12, input_h)

        if self.stdin_input is None:
            self.stdin_input = TextInput(
                self.stdin_rect,
                placeholder="Ввод для скрипта (input)…",
                on_submit=self._submit_stdin,
                app=self.app,
            )
        else:
            self.stdin_input.set_rect(self.stdin_rect)

        self.stdin_input.draw(surface, self.app.font("mono", 14))


# ============================================================================
# ПРОВОДНИК
# ============================================================================

class FileExplorerScreen(BaseScreen):
    def __init__(self, app: "App") -> None:
        super().__init__(app)
        start = Path(app.settings.get("browse_path", str(PROJECT_DIR)))
        if not start.exists() or not start.is_dir():
            start = PROJECT_DIR
        self.cwd = start
        self.entries: List[Dict[str, Any]] = []
        self.list = ScrollList()
        self.list.on_activate = self._activate
        self.buttons: List[TouchButton] = []
        self.path_input = TextInput(
            pygame.Rect(0, 0, 1, 1),
            placeholder="Путь: /storage/emulated/0",
            on_submit=self._on_path_submit, app=app)
        self.show_path_input = False
        self._build_buttons()
        self.refresh()

    def apply_text_input(self, text: str) -> None:
        if self.path_input.active:
            self.path_input.apply_text_input(text)

    def refresh(self) -> None:
        self.entries = []
        for entry in safe_listdir(self.cwd):
            name = entry.name
            if name.startswith("."):
                continue
            try:
                is_dir = entry.is_dir()
            except OSError:
                is_dir = False
            try:
                stat = entry.stat()
                size = stat.st_size
                mtime = time.strftime("%m-%d %H:%M",
                                      time.localtime(stat.st_mtime))
            except OSError:
                size = 0
                mtime = "--"
            self.entries.append({
                "name": name, "path": entry,
                "is_dir": is_dir, "size": size, "mtime": mtime,
            })
        self.list.set_items(self.entries)

    def _on_path_submit(self, text: str) -> None:
        p = to_python_path(text)
        target = Path(p)
        if target.exists() and target.is_dir():
            self.cwd = target
            self.app.settings.set("browse_path", str(self.cwd))
            self.refresh()
            self.app.toast(f"OK: {self.cwd}")
        else:
            self.app.toast(f"Не найдено: {p}", ERROR)
        self.show_path_input = False
        self.path_input.unfocus()

    def _activate(self, idx: int) -> None:
        if idx >= len(self.entries):
            return
        item = self.entries[idx]
        path: Path = item["path"]

        if item["is_dir"]:
            self.cwd = path
            self.refresh()
            return

        if is_audio_file(path):
            LOG.info("EXPLORER", f"Воспроизведение: {path}")
            self.app.music_screen.play_file(path)
            self.app.show_screen("music")
            return

        if is_image_file(path):
            LOG.info("EXPLORER", f"Изображение: {path}")
            self.app.image_screen.open(path)
            self.app.show_screen("image")
            return

        if path.suffix.lower() == ".py":
            LOG.info("EXPLORER", f"Редактор: {path}")
            self.app.editor_screen.open_file(path)
            self.app.show_screen("editor")
            return

        if is_text_file(path) or is_doc_file(path):
            LOG.info("EXPLORER", f"Просмотр: {path}")
            self.app.viewer_screen.open(path)
            self.app.show_screen("viewer")
            return

        try:
            size_str = human_size(path.stat().st_size)
        except OSError:
            size_str = "?"
        self.app.toast(
            f"{path.name} ({size_str}) — тип не поддержан",
            WARNING, duration=2.5,
        )

    def _build_buttons(self) -> None:
        bh = 38
        gap = 5
        y = 6
        self.buttons = []
        x = 6
        for label, cb, col, bw in [
            ("Вверх", self._up, (90, 100, 130), 80),
            ("SD", self._to_sd, (60, 140, 100), 60),
            ("DL", self.app.on_open_downloads, (60, 140, 100), 60),
            ("DCIM", self._to_dcim, (150, 110, 60), 70),
        ]:
            self.buttons.append(TouchButton(label, cb, color=col,
                                            rect=pygame.Rect(x, y, bw, bh)))
            x += bw + gap

        y2 = y + bh + 4
        x = 6
        for label, cb, col, bw in [
            ("Путь", self._toggle_path_input, (80, 90, 120), 80),
            ("Обновить", self.refresh, (60, 120, 180), 100),
            ("Корень", self._to_root, (90, 100, 130), 90),
        ]:
            self.buttons.append(TouchButton(label, cb, color=col,
                                            rect=pygame.Rect(x, y2, bw, bh)))
            x += bw + gap

    def _up(self) -> None:
        try:
            if self.cwd.parent != self.cwd:
                self.cwd = self.cwd.parent
                self.app.settings.set("browse_path", str(self.cwd))
                self.refresh()
        except Exception:
            pass

    def _to_root(self) -> None:
        self.cwd = Path("/")
        self.app.settings.set("browse_path", str(self.cwd))
        self.refresh()

    def _to_sd(self) -> None:
        if ANDROID_STORAGE.exists():
            self.cwd = ANDROID_STORAGE
            self.app.settings.set("browse_path", str(self.cwd))
            self.refresh()
        else:
            self.app.toast("Нет доступа к SD", ERROR)

    def _to_dcim(self) -> None:
        if ANDROID_DCIM.exists():
            self.cwd = ANDROID_DCIM
            self.app.settings.set("browse_path", str(self.cwd))
            self.refresh()

    def _toggle_path_input(self) -> None:
        self.show_path_input = not self.show_path_input
        if self.show_path_input:
            self.path_input.text = str(self.cwd)
            self.path_input.focus()
        else:
            self.path_input.unfocus()

    def handle_event(self, event: pygame.event.Event) -> None:
        super().handle_event(event)

        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return

        if self.show_path_input:
            if self.path_input.handle_event(event):
                return

        for btn in self.buttons:
            if btn.handle_event(event):
                return

        self.list.handle_event(event)

    def update(self, dt: float) -> None:
        for b in self.buttons:
            b.update(dt)
        self.path_input.update(dt)

    def draw(self, surface: pygame.Surface) -> None:
        w, h = surface.get_size()
        surface.fill(PANEL_BG)

        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)

        path_y = 6 + 38 + 4 + 38 + 4
        path_font = self.app.font("mono", 11)
        path_text = truncate_text(str(self.cwd), path_font, w - 16)
        ps = path_font.render(path_text, True, ACCENT)
        surface.blit(ps, (8, path_y))

        list_top = path_y + path_font.get_linesize() + 4

        if self.show_path_input:
            pi_rect = pygame.Rect(8, list_top, w - 16, 40)
            self.path_input.set_rect(pi_rect)
            self.path_input.draw(surface, self.app.font("mono", 13))
            list_top += 46

        vk_h = self.app.vk.rect.height if self.app.vk.visible else 0
        list_rect = pygame.Rect(8, list_top, w - 16,
                                h - list_top - vk_h - 6 - NAV_BAR_H)
        if list_rect.height < 100:
            list_rect.height = 100

        self.list.set_rect(list_rect)

        def render_row(surface, i, item, x, y, selected):
            name_font = self.app.font("ui", 13)
            meta_font = self.app.font("mono", 10)

            path: Path = item["path"]
            if item["is_dir"]:
                tag = "D"
                tag_color = (255, 220, 120)
            elif is_audio_file(path):
                tag = "A"
                tag_color = (255, 140, 200)
            elif is_image_file(path):
                tag = "I"
                tag_color = (120, 220, 160)
            elif is_doc_file(path):
                tag = "P"
                tag_color = (255, 180, 100)
            elif is_text_file(path):
                tag = "T"
                tag_color = (150, 200, 255)
            else:
                tag = "F"
                tag_color = TEXT_DIM

            ms = meta_font.render(f"[{tag}]", True, tag_color)
            surface.blit(ms, (x, y + 12))

            name = item["name"] + ("/" if item["is_dir"] else "")
            name = truncate_text(name, name_font, list_rect.width - 160)
            if item["is_dir"]:
                color = (255, 220, 120)
            elif is_audio_file(path):
                color = (255, 180, 220)
            elif is_image_file(path):
                color = (160, 255, 190)
            elif is_doc_file(path):
                color = (255, 200, 140)
            elif is_text_file(path):
                color = (180, 220, 255)
            else:
                color = TEXT_BRIGHT
            ns = name_font.render(name, True, color)
            surface.blit(ns, (x + 40, y + 8))

            if not item["is_dir"]:
                size_text = human_size(item["size"])
                ss = meta_font.render(size_text, True, TEXT_DIM)
                surface.blit(ss, (list_rect.right - 90, y + 14))

        self.list.draw(surface, render_row)


# ============================================================================
# ПРОСМОТРЩИК ДОКУМЕНТОВ
# ============================================================================

class ViewerScreen(BaseScreen):
    MAX_CHARS = 500_000

    def __init__(self, app: "App") -> None:
        super().__init__(app)
        self.path: Optional[Path] = None
        self.lines: List[str] = []
        self.title = ""
        self.scroll_line = 0
        self.buttons: List[TouchButton] = []
        self.scroll_btn_up: Optional[pygame.Rect] = None
        self.scroll_btn_down: Optional[pygame.Rect] = None
        self._build_buttons()

    def _build_buttons(self) -> None:
        bh = 38
        gap = 5
        self.buttons = []
        x = 6
        for label, cb, col, bw in [
            ("В редактор", self._open_in_editor, (60, 120, 180), 130),
            ("Обновить", self._reload, (80, 90, 120), 100),
            ("Строка", self._hint, (70, 80, 100), 90),
        ]:
            self.buttons.append(TouchButton(label, cb, color=col,
                                            rect=pygame.Rect(x, 6, bw, bh)))
            x += bw + gap

    def _reload(self) -> None:
        if self.path:
            self.open(self.path)

    def _hint(self) -> None:
        self.app.toast("Свайп для прокрутки")

    def _open_in_editor(self) -> None:
        if self.path:
            self.app.editor_screen.open_file(self.path)
            self.app.show_screen("editor")

    def open(self, path: Path) -> None:
        self.path = path
        self.title = path.name
        self.scroll_line = 0
        try:
            size = path.stat().st_size
        except OSError:
            size = 0

        suffix = path.suffix.lower()
        text = ""

        # PDF — попытка извлечь текст через доступные библиотеки
        if suffix == ".pdf":
            text = self._extract_pdf(path)
            if not text:
                text = (
                    f"[PDF] {path.name}\n"
                    f"Размер: {human_size(size)}\n"
                    f"Путь: {path}\n\n"
                    "Текст из PDF не извлечён.\n"
                    "Установите pypdf или pymupdf для просмотра содержимого:\n"
                    "  pip install pypdf\n"
                    "или откройте файл во внешнем приложении."
                )
            self.lines = text.split("\n")
            LOG.info("VIEWER", f"PDF {path} ({size} B)")
            return

        # Остальные документы (docx и т.п.) — пробуем как текст, иначе инфо
        if is_doc_file(path):
            try:
                raw = path.read_bytes()[: min(size, 200_000)]
                # ищем читаемые куски
                chunks = []
                for enc in ("utf-8", "cp1251", "latin-1"):
                    try:
                        decoded = raw.decode(enc, errors="ignore")
                        readable = "".join(
                            c if c.isprintable() or c in "\n\t\r" else " "
                            for c in decoded
                        )
                        if len(readable.strip()) > 80:
                            chunks.append(readable)
                            break
                    except Exception:
                        continue
                if chunks:
                    text = (
                        f"[Документ] {path.name}\n"
                        f"Тип: {suffix}  Размер: {human_size(size)}\n"
                        f"{'─' * 40}\n"
                        f"{chunks[0][: self.MAX_CHARS]}\n"
                    )
                else:
                    text = (
                        f"[Документ] {path.name}\n"
                        f"Тип: {suffix}  Размер: {human_size(size)}\n"
                        f"Путь: {path}\n\n"
                        "Бинарный формат. Полный просмотр во внешнем приложении."
                    )
            except Exception as e:
                text = f"Ошибка чтения документа: {e}"
            self.lines = text.split("\n")
            LOG.info("VIEWER", f"DOC {path} ({size} B)")
            return

        # Обычный текстовый файл
        try:
            if size > self.MAX_CHARS:
                with path.open("r", encoding="utf-8",
                               errors="replace") as fh:
                    text = fh.read(self.MAX_CHARS)
                text += f"\n\n... [показаны первые {self.MAX_CHARS} байт]"
            else:
                text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            try:
                text = path.read_text(encoding="cp1251")
            except Exception as e:
                self.app.toast(f"Чтение: {e}", ERROR)
                self.lines = [f"Не удалось прочитать файл: {e}"]
                return
        except OSError as e:
            self.app.toast(f"Открытие: {e}", ERROR)
            self.lines = [f"Не удалось открыть файл: {e}"]
            return

        self.lines = text.split("\n") if text else [""]
        LOG.info("VIEWER", f"Открыт {path} ({size} B, {len(self.lines)} строк)")

    def _extract_pdf(self, path: Path) -> str:
        """Пытается извлечь текст из PDF. Возвращает пустую строку при неудаче."""
        # pypdf
        try:
            from pypdf import PdfReader  # type: ignore
            reader = PdfReader(str(path))
            parts = []
            for i, page in enumerate(reader.pages[:40]):
                t = page.extract_text() or ""
                if t.strip():
                    parts.append(f"--- стр. {i + 1} ---\n{t}")
            if parts:
                return "\n\n".join(parts)
        except Exception:
            pass
        # PyMuPDF
        try:
            import fitz  # type: ignore
            doc = fitz.open(str(path))
            parts = []
            for i, page in enumerate(doc):
                if i >= 40:
                    break
                t = page.get_text() or ""
                if t.strip():
                    parts.append(f"--- стр. {i + 1} ---\n{t}")
            doc.close()
            if parts:
                return "\n\n".join(parts)
        except Exception:
            pass
        # pdfminer
        try:
            from pdfminer.high_level import extract_text  # type: ignore
            t = extract_text(str(path), maxpages=40) or ""
            if t.strip():
                return t
        except Exception:
            pass
        return ""

    def handle_event(self, event: pygame.event.Event) -> None:
        super().handle_event(event)

        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.scroll_btn_up and self.scroll_btn_up.collidepoint(event.pos):
                self.scroll_line = max(0, self.scroll_line - 5)
                return
            if self.scroll_btn_down and self.scroll_btn_down.collidepoint(event.pos):
                self.scroll_line += 5
                return

        for btn in self.buttons:
            if btn.handle_event(event):
                return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.dragging = True
            self.drag_start_y = event.pos[1]
            self.drag_start_scroll = self.scroll_line
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            dy = event.pos[1] - self.drag_start_y
            if abs(dy) > 6:
                step = max(1, self.app.font("mono", 12).get_linesize())
                self.scroll_line = max(0, self.drag_start_scroll - dy // step)
        elif event.type == pygame.MOUSEWHEEL:
            self.scroll_line -= event.y * 3
            self.scroll_line = max(0, self.scroll_line)

    def update(self, dt: float) -> None:
        for b in self.buttons:
            b.update(dt)

    def draw(self, surface: pygame.Surface) -> None:
        w, h = surface.get_size()
        surface.fill(PANEL_BG)

        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)

        head_y = 50
        title_font = self.app.font("ui", 14, bold=True)
        t = title_font.render(truncate_text(self.title, title_font, w - 20),
                              True, TEXT_BRIGHT)
        surface.blit(t, (10, head_y))

        info_font = self.app.font("mono", 10)
        info = f"{len(self.lines)} стр."
        isurf = info_font.render(info, True, TEXT_DIM)
        surface.blit(isurf, (w - isurf.get_width() - 10, head_y + 2))

        body = pygame.Rect(6, head_y + 26, w - 12,
                           h - head_y - 32 - NAV_BAR_H)
        pygame.draw.rect(surface, (14, 16, 22), body, border_radius=6)
        pygame.draw.rect(surface, PANEL_BORDER, body, width=1, border_radius=6)

        code_font = self.app.font("mono", 12)
        line_h = code_font.get_linesize()
        visible = max(1, (body.height - 12) // line_h)

        total = len(self.lines)
        max_top = max(0, total - visible)
        self.max_scroll = max_top
        self.scroll_line = max(0, min(self.scroll_line, max_top))

        start = self.scroll_line
        end = min(total, start + visible + 1)

        prev_clip = surface.get_clip()
        surface.set_clip(body.inflate(-6, -6))
        y = body.y + 6
        for i in range(start, end):
            line = self.lines[i]
            num_font = self.app.font("mono", 10)
            num = num_font.render(f"{i+1:>5}", True, (90, 100, 120))
            surface.blit(num, (body.x + 6, y + 2))

            text = truncate_text(line, code_font, body.width - 70)
            color = TEXT_BRIGHT
            stripped = line.lstrip()
            if stripped.startswith("#") or stripped.startswith("//"):
                color = (120, 140, 120)
            elif stripped.startswith(("def ", "class ")):
                color = (140, 200, 255)
            ts = code_font.render(text, True, color)
            surface.blit(ts, (body.x + 60, y))
            y += line_h
        surface.set_clip(prev_clip)

        pos_font = self.app.font("mono", 10)
        pos_text = f"{start + 1}-{min(total, start + visible)}/{total}"
        pos_surf = pos_font.render(pos_text, True, TEXT_DIM)
        surface.blit(pos_surf, (body.right - pos_surf.get_width() - 8,
                                body.y + 4))

        arrow_w, arrow_h = 60, 66
        gap = 12
        cx = w - arrow_w - 12
        cy_center = (body.y + body.bottom) // 2

        up_rect = pygame.Rect(cx, cy_center - arrow_h - gap // 2,
                              arrow_w, arrow_h)
        down_rect = pygame.Rect(cx, cy_center + gap // 2,
                                arrow_w, arrow_h)
        self.scroll_btn_up = up_rect
        self.scroll_btn_down = down_rect

        label_font = self.app.font("ui", 10, bold=True)
        lbl = label_font.render("ТЕКСТ", True, TEXT_DIM)
        surface.blit(lbl, (up_rect.x + (up_rect.w - lbl.get_width()) // 2,
                           up_rect.y - 16))

        pygame.draw.rect(surface, (40, 90, 150), up_rect, border_radius=10)
        pygame.draw.rect(surface, (90, 150, 210), up_rect, width=2,
                         border_radius=10)
        big_font = self.app.font("ui", 36, bold=True)
        up_sym = big_font.render("^", True, (255, 255, 255))
        surface.blit(up_sym, up_sym.get_rect(center=up_rect.center))

        pygame.draw.rect(surface, (40, 90, 150), down_rect, border_radius=10)
        pygame.draw.rect(surface, (90, 150, 210), down_rect, width=2,
                         border_radius=10)
        down_sym = big_font.render("v", True, (255, 255, 255))
        surface.blit(down_sym, down_sym.get_rect(center=down_rect.center))


# ============================================================================
# ПРОСМОТР ИЗОБРАЖЕНИЙ
# ============================================================================

class ImageScreen(BaseScreen):
    def __init__(self, app: "App") -> None:
        super().__init__(app)
        self.path: Optional[Path] = None
        self.title = ""
        self.image: Optional[pygame.Surface] = None
        self.scaled: Optional[pygame.Surface] = None
        self.offset = (0, 0)
        self.scale = 1.0
        self.dragging = False
        self.drag_start = (0, 0)
        self.drag_offset_start = (0, 0)
        self.buttons: List[TouchButton] = []
        self._build_buttons()

    def _build_buttons(self) -> None:
        self.buttons = [
            TouchButton("Назад", self.app.back_to_menu,
                        color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 80, 38)),
            TouchButton("Сброс", self._reset_view,
                        color=(60, 120, 180),
                        rect=pygame.Rect(92, 6, 80, 38)),
        ]

    def _reset_view(self) -> None:
        self.scale = 1.0
        self.offset = (0, 0)
        self._rescale()

    def open(self, path: Path) -> None:
        self.path = path
        self.title = path.name
        self.image = None
        self.scaled = None
        self.scale = 1.0
        self.offset = (0, 0)
        try:
            self.image = pygame.image.load(str(path)).convert_alpha()
            self._rescale()
            LOG.info("IMAGE", f"Открыто {path}")
        except Exception as e:
            LOG.error("IMAGE", f"{e}")
            self.app.toast(f"Не удалось открыть: {e}", ERROR)
            self.image = None

    def _rescale(self) -> None:
        if self.image is None:
            self.scaled = None
            return
        w, h = self.app.screen.get_size()
        avail_w = w - 20
        avail_h = h - 60 - NAV_BAR_H
        iw, ih = self.image.get_size()
        base = min(avail_w / max(1, iw), avail_h / max(1, ih), 1.0)
        final = base * self.scale
        nw = max(1, int(iw * final))
        nh = max(1, int(ih * final))
        try:
            self.scaled = pygame.transform.smoothscale(self.image, (nw, nh))
        except Exception:
            self.scaled = pygame.transform.scale(self.image, (nw, nh))

    def handle_event(self, event: pygame.event.Event) -> None:
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return
        for b in self.buttons:
            if b.handle_event(event):
                return
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.dragging = True
            self.drag_start = event.pos
            self.drag_offset_start = self.offset
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            dx = event.pos[0] - self.drag_start[0]
            dy = event.pos[1] - self.drag_start[1]
            self.offset = (self.drag_offset_start[0] + dx,
                           self.drag_offset_start[1] + dy)
        elif event.type == pygame.MOUSEWHEEL:
            old = self.scale
            self.scale = max(0.2, min(5.0, self.scale + event.y * 0.15))
            if self.scale != old:
                self._rescale()

    def update(self, dt: float) -> None:
        for b in self.buttons:
            b.update(dt)

    def on_resize(self) -> None:
        self._rescale()

    def draw(self, surface: pygame.Surface) -> None:
        w, h = surface.get_size()
        surface.fill((10, 12, 16))
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)

        title_font = self.app.font("ui", 14, bold=True)
        t = title_font.render(truncate_text(self.title, title_font, w - 200),
                              True, TEXT_BRIGHT)
        surface.blit(t, (180, 14))

        if self.scaled is None:
            msg = self.app.font("ui", 14).render(
                "Изображение не загружено", True, TEXT_DIM)
            surface.blit(msg, (20, 80))
            return

        area = pygame.Rect(10, 52, w - 20, h - 52 - NAV_BAR_H - 8)
        prev = surface.get_clip()
        surface.set_clip(area)

        sw, sh = self.scaled.get_size()
        x = area.x + (area.w - sw) // 2 + self.offset[0]
        y = area.y + (area.h - sh) // 2 + self.offset[1]
        surface.blit(self.scaled, (x, y))
        surface.set_clip(prev)

        info = self.app.font("mono", 11).render(
            f"{self.scale:.0%}  свайп — сдвиг, колесо — масштаб",
            True, TEXT_DIM)
        surface.blit(info, (12, h - NAV_BAR_H - 22))


# ============================================================================
# ГАЛЕРЕЯ
# ============================================================================

GALLERY_DIRS = [
    Path("/storage/emulated/0/DCIM"),
    Path("/storage/emulated/0/Pictures"),
    Path("/storage/emulated/0/Download"),
    Path("/storage/emulated/0/TileLauncher"),
]


class GalleryScreen(BaseScreen):
    """Сетка фото + просмотр с листанием."""

    def __init__(self, app: "App") -> None:
        super().__init__(app)
        self.files: List[Path] = []
        self.scroll = 0
        self.max_scroll = 0
        self.dragging = False
        self.drag_y = 0
        self.drag_scroll = 0
        self.mode = "grid"  # grid | view
        self.view_idx = 0
        self.view_image: Optional[pygame.Surface] = None
        self.view_scaled: Optional[pygame.Surface] = None
        self.swipe_x0: Optional[int] = None
        self.thumb_cache: Dict[str, pygame.Surface] = {}
        self.buttons: List[TouchButton] = []
        self._build_buttons()

    def _build_buttons(self) -> None:
        self.buttons = [
            TouchButton("Назад", self._on_back, color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 80, 38)),
            TouchButton("Обновить", self.refresh, color=(60, 120, 180),
                        rect=pygame.Rect(92, 6, 100, 38)),
        ]

    def _on_back(self) -> None:
        if self.mode == "view":
            self.mode = "grid"
            self.view_image = None
            self.view_scaled = None
            self.redraw()
        else:
            self.app.back_to_menu()

    def refresh(self) -> None:
        found: List[Path] = []
        seen = set()
        for root in GALLERY_DIRS:
            if not root.exists():
                continue
            try:
                for p in root.rglob("*"):
                    if not p.is_file():
                        continue
                    if p.suffix.lower() not in IMAGE_EXTS:
                        continue
                    key = str(p.resolve()) if p.exists() else str(p)
                    if key in seen:
                        continue
                    seen.add(key)
                    found.append(p)
                    if len(found) >= 300:
                        break
            except Exception:
                continue
            if len(found) >= 300:
                break
        found.sort(key=lambda x: x.stat().st_mtime if x.exists() else 0,
                   reverse=True)
        self.files = found
        self.scroll = 0
        self.thumb_cache.clear()
        self.app.toast(f"Фото: {len(self.files)}")
        self.redraw()

    def open_gallery(self) -> None:
        self.mode = "grid"
        self.view_idx = 0
        if not self.files:
            self.refresh()

    def _thumb(self, path: Path, size: int) -> Optional[pygame.Surface]:
        key = f"{path}:{size}"
        if key in self.thumb_cache:
            return self.thumb_cache[key]
        try:
            img = pygame.image.load(str(path)).convert()
            iw, ih = img.get_size()
            scale = max(size / max(1, iw), size / max(1, ih))
            nw, nh = max(1, int(iw * scale)), max(1, int(ih * scale))
            img = pygame.transform.smoothscale(img, (nw, nh))
            surf = pygame.Surface((size, size))
            surf.fill((30, 34, 42))
            surf.blit(img, ((size - nw) // 2, (size - nh) // 2))
            if len(self.thumb_cache) > 80:
                self.thumb_cache.clear()
            self.thumb_cache[key] = surf
            return surf
        except Exception:
            return None

    def _open_view(self, idx: int) -> None:
        if not self.files:
            return
        self.view_idx = max(0, min(len(self.files) - 1, idx))
        self.mode = "view"
        path = self.files[self.view_idx]
        try:
            self.view_image = pygame.image.load(str(path)).convert_alpha()
        except Exception as e:
            self.app.toast(str(e), ERROR)
            self.view_image = None
            return
        self._fit_view()
        self.redraw()

    def _fit_view(self) -> None:
        if self.view_image is None:
            self.view_scaled = None
            return
        w, h = self.app.screen.get_size()
        aw, ah = w - 20, h - 70 - NAV_BAR_H
        iw, ih = self.view_image.get_size()
        s = min(aw / max(1, iw), ah / max(1, ih), 1.0)
        nw, nh = max(1, int(iw * s)), max(1, int(ih * s))
        try:
            self.view_scaled = pygame.transform.smoothscale(
                self.view_image, (nw, nh))
        except Exception:
            self.view_scaled = pygame.transform.scale(
                self.view_image, (nw, nh))

    def handle_event(self, event: pygame.event.Event) -> None:
        super().handle_event(event)
        w, h = self.app.screen.get_size()
        for b in self.buttons:
            if b.handle_event(event):
                return
        if self.mode == "view":
            if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
                self.swipe_x0 = event.pos[0]
            elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
                if self.swipe_x0 is not None:
                    dx = event.pos[0] - self.swipe_x0
                    self.swipe_x0 = None
                    if dx < -60:
                        self._open_view(self.view_idx + 1)
                    elif dx > 60:
                        self._open_view(self.view_idx - 1)
            return
        # grid
        cols = 3 if w < h else 5
        gap = 6
        pad = 10
        cell = (w - pad * 2 - gap * (cols - 1)) // cols
        top = 52
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.dragging = True
            self.drag_y = event.pos[1]
            self.drag_scroll = self.scroll
            self.swipe_x0 = event.pos[0]
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            moved = abs(event.pos[1] - self.drag_y) if self.dragging else 0
            self.dragging = False
            if moved < 12:
                x, y = event.pos
                if y < top:
                    return
                col = (x - pad) // max(1, cell + gap)
                row = (y - top + self.scroll) // max(1, cell + gap)
                if 0 <= col < cols:
                    idx = int(row) * cols + int(col)
                    if 0 <= idx < len(self.files):
                        self._open_view(idx)
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            self.scroll = max(0, min(
                self.max_scroll,
                self.drag_scroll + (self.drag_y - event.pos[1])))
            self.redraw()
        elif event.type == pygame.MOUSEWHEEL:
            self.scroll = max(0, min(self.max_scroll,
                                     self.scroll - event.y * 40))
            self.redraw()

    def update(self, dt: float) -> None:
        for b in self.buttons:
            b.update(dt)

    def on_resize(self) -> None:
        if self.mode == "view":
            self._fit_view()

    def draw(self, surface: pygame.Surface) -> None:
        w, h = surface.get_size()
        surface.fill(BG_GRAD_BOTTOM)
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)
        title = self.app.font("ui", 15, bold=True).render(
            "Галерея", True, TEXT_BRIGHT)
        surface.blit(title, (210, 14))

        if self.mode == "view":
            name = self.files[self.view_idx].name if self.files else ""
            surface.blit(self.app.font("ui", 12).render(
                truncate_text(f"{self.view_idx + 1}/{len(self.files)}  {name}",
                              self.app.font("ui", 12), w - 40),
                True, TEXT_DIM), (12, 50))
            if self.view_scaled:
                sw, sh = self.view_scaled.get_size()
                surface.blit(self.view_scaled,
                             ((w - sw) // 2, 70 + (h - 70 - NAV_BAR_H - sh) // 2))
            surface.blit(self.app.font("ui", 12).render(
                "← свайп → листание", True, TEXT_DIM),
                (12, h - NAV_BAR_H - 22))
            return

        cols = 3 if w < h else 5
        gap = 6
        pad = 10
        cell = (w - pad * 2 - gap * (cols - 1)) // cols
        top = 52
        rows = (len(self.files) + cols - 1) // cols
        self.max_scroll = max(0, rows * (cell + gap) - (h - top - NAV_BAR_H - 10))

        y = top - self.scroll
        for i, path in enumerate(self.files):
            col = i % cols
            row = i // cols
            x = pad + col * (cell + gap)
            yy = top + row * (cell + gap) - self.scroll
            if yy + cell < top or yy > h - NAV_BAR_H:
                continue
            thumb = self._thumb(path, cell)
            if thumb:
                surface.blit(thumb, (x, yy))
            else:
                pygame.draw.rect(surface, (40, 48, 60),
                                 pygame.Rect(x, yy, cell, cell),
                                 border_radius=8)
            pygame.draw.rect(surface, PANEL_BORDER,
                             pygame.Rect(x, yy, cell, cell), 1, border_radius=8)

        if not self.files:
            surface.blit(self.app.font("ui", 14).render(
                "Нет фото. Нажмите «Обновить»", True, TEXT_DIM),
                (20, 80))


# ============================================================================
# РЕДАКТОР
# ============================================================================

class EditorScreen(BaseScreen):
    def __init__(self, app: "App") -> None:
        super().__init__(app)
        self.path: Optional[Path] = None
        self.lines: List[str] = [""]
        self.cursor_x = 0
        self.cursor_y = 0
        self.scroll_line = 0
        self.dirty = False
        self.status = ""
        self.blink = 0.0
        self.buttons: List[TouchButton] = []
        self.scroll_btn_up: Optional[pygame.Rect] = None
        self.scroll_btn_down: Optional[pygame.Rect] = None
        self._build_buttons()

    def _build_buttons(self) -> None:
        bh = 38
        gap = 5
        self.buttons = []
        x = 6
        for label, cb, col, bw in [
            ("Сохранить", self.save, (60, 120, 180), 105),
            ("Открыть", self._pick_file, (80, 90, 120), 90),
            ("RUN", self.run_code, (60, 160, 90), 80),
            ("Enter", self._insert_newline, (80, 90, 120), 65),
            ("<-", self._backspace, (170, 80, 80), 50),
        ]:
            self.buttons.append(TouchButton(label, cb, color=col,
                                            rect=pygame.Rect(x, 6, bw, bh)))
            x += bw + gap

    def _pick_file(self) -> None:
        """Предложить открыть .py или создать новый."""
        self.app.explorer_screen.cwd = PROJECT_DIR
        self.app.explorer_screen.refresh()
        self.app.show_screen("explorer")
        self.app.toast("Выберите .py файл", ACCENT)

    def run_code(self) -> None:
        if self.path is None:
            self.path = TARGET_SCRIPT
            self.app.toast("Создан target.py", ACCENT)

        try:
            self.path.write_text("\n".join(self.lines), encoding="utf-8")
            self.dirty = False
            self.status = f"Сохранено и запущено: {self.path.name}"
            LOG.info("EDITOR", f"Сохранён и запущен {self.path}")
        except OSError as exc:
            self.app.toast(f"Сохранение: {exc}", ERROR)
            LOG.error("EDITOR", f"Не удалось сохранить: {exc}")
            return

        self.app.run_screen.start(self.path)
        self.app.show_screen("run")

    def apply_text_input(self, text: str) -> None:
        for ch in text:
            self._insert(ch)

    def open_file(self, path: Path) -> None:
        self.path = path
        try:
            text = path.read_text(encoding="utf-8")
        except UnicodeDecodeError:
            try:
                text = path.read_text(encoding="cp1251")
            except Exception as exc:
                self.app.toast(f"Чтение: {exc}", ERROR)
                return
        except OSError as exc:
            self.app.toast(f"Открытие: {exc}", ERROR)
            return

        self.lines = text.split("\n") if text else [""]
        self.cursor_x = 0
        self.cursor_y = 0
        self.scroll_line = 0
        self.dirty = False
        self.status = path.name
        LOG.info("EDITOR", f"Открыт файл {path}")

    def save(self) -> None:
        if not self.path:
            self.path = TARGET_SCRIPT
        try:
            self.path.write_text("\n".join(self.lines), encoding="utf-8")
            self.dirty = False
            self.status = f"Сохранено: {self.path.name}"
            self.app.toast("Сохранено", SUCCESS)
            LOG.info("EDITOR", f"Сохранён {self.path}")
        except OSError as exc:
            self.app.toast(f"Ошибка: {exc}", ERROR)
            LOG.error("EDITOR", f"Ошибка сохранения: {exc}")

    def _toggle_keyboard(self) -> None:
        if self.app.vk.visible and self.app.text_focus is self:
            self.app.clear_text_focus()
        else:
            self.app.set_text_focus(self)

    def _insert(self, ch: str) -> None:
        line = self.lines[self.cursor_y]
        self.lines[self.cursor_y] = line[:self.cursor_x] + ch + \
            line[self.cursor_x:]
        self.cursor_x += len(ch)
        self.dirty = True

    def _backspace(self) -> None:
        if self.cursor_x > 0:
            line = self.lines[self.cursor_y]
            self.lines[self.cursor_y] = line[:self.cursor_x - 1] + \
                line[self.cursor_x:]
            self.cursor_x -= 1
            self.dirty = True
        elif self.cursor_y > 0:
            prev = self.lines[self.cursor_y - 1]
            cur = self.lines[self.cursor_y]
            self.cursor_x = len(prev)
            self.lines[self.cursor_y - 1] = prev + cur
            del self.lines[self.cursor_y]
            self.cursor_y -= 1
            self.dirty = True

    def _insert_newline(self) -> None:
        line = self.lines[self.cursor_y]
        before = line[:self.cursor_x]
        after = line[self.cursor_x:]
        indent = len(line) - len(line.lstrip(" "))
        if line.rstrip().endswith(":"):
            indent += int(self.app.settings.get("editor_tab_size", 4))
        after = " " * indent + after
        self.lines[self.cursor_y] = before
        self.lines.insert(self.cursor_y + 1, after)
        self.cursor_y += 1
        self.cursor_x = indent
        self.dirty = True

    def insert(self, ch: str) -> None:
        self._insert(ch)

    def backspace(self) -> None:
        self._backspace()

    def submit(self) -> None:
        self._insert_newline()

    def handle_event(self, event: pygame.event.Event) -> None:
        super().handle_event(event)

        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return

        if event.type == pygame.KEYDOWN:
            if event.key == pygame.K_BACKSPACE:
                self._backspace()
                return
            if event.key == pygame.K_RETURN:
                self._insert_newline()
                return
            if event.key == pygame.K_DELETE:
                line = self.lines[self.cursor_y]
                if self.cursor_x < len(line):
                    self.lines[self.cursor_y] = (
                        line[:self.cursor_x] + line[self.cursor_x + 1:])
                    self.dirty = True
                return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.scroll_btn_up and self.scroll_btn_up.collidepoint(event.pos):
                self.scroll_line = max(0, self.scroll_line - 5)
                return
            if self.scroll_btn_down and self.scroll_btn_down.collidepoint(event.pos):
                self.scroll_line += 5
                return

        for btn in self.buttons:
            if btn.handle_event(event):
                return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if event.pos[1] > 50:
                if self.scroll_btn_up and self.scroll_btn_up.collidepoint(event.pos):
                    return
                if self.scroll_btn_down and self.scroll_btn_down.collidepoint(event.pos):
                    return
                self._place_cursor(event.pos)
                self.app.set_text_focus(self)

    def _place_cursor(self, pos: Tuple[int, int]) -> None:
        code_top = 50
        code_left = 48
        font = self.app.font("mono", 12)
        line_h = font.get_linesize()
        if pos[1] < code_top:
            return
        rel_y = pos[1] - code_top + self.scroll_line * line_h
        line_idx = rel_y // line_h
        if 0 <= line_idx < len(self.lines):
            self.cursor_y = int(line_idx)
            line = self.lines[self.cursor_y]
            cx = pos[0] - code_left
            if cx <= 0:
                self.cursor_x = 0
            else:
                idx = 0
                for i, ch in enumerate(line):
                    if font.size(line[:i + 1])[0] > cx:
                        break
                    idx = i + 1
                self.cursor_x = idx

    def update(self, dt: float) -> None:
        self.blink = (self.blink + dt) % 1.0

        vk_h = self.app.vk.rect.height if self.app.vk.visible else 0
        code_h = self.app.screen.get_height() - 50 - vk_h - 6 - NAV_BAR_H
        line_h = self.app.font("mono", 12).get_linesize()
        visible = max(1, (code_h - 12) // line_h)
        max_top = max(0, len(self.lines) - visible)
        self.scroll_line = max(0, min(self.scroll_line, max_top))

        for b in self.buttons:
            b.update(dt)

    def draw(self, surface: pygame.Surface) -> None:
        w, h = surface.get_size()
        surface.fill(PANEL_BG)

        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 11, bold=True),
                   animations=anim)

        vk_h = self.app.vk.rect.height if self.app.vk.visible else 0
        code_rect = pygame.Rect(6, 50, w - 12,
                                h - 50 - vk_h - 6 - NAV_BAR_H)
        if code_rect.height < 80:
            code_rect.height = 80
        pygame.draw.rect(surface, (14, 16, 22), code_rect, border_radius=6)

        code_font = self.app.font("mono", 12)
        line_h = code_font.get_linesize()
        gutter_w = 42

        visible = max(1, (code_rect.height - 12) // line_h)
        if self.cursor_y < self.scroll_line:
            self.scroll_line = self.cursor_y
        elif self.cursor_y >= self.scroll_line + visible:
            self.scroll_line = self.cursor_y - visible + 1

        prev_clip = surface.get_clip()
        surface.set_clip(code_rect.inflate(-4, -4))

        pygame.draw.rect(surface, (20, 22, 30),
                         pygame.Rect(code_rect.x + 4, code_rect.y + 6,
                                     gutter_w, code_rect.height - 12))

        y = code_rect.y + 6
        for i in range(self.scroll_line,
                       min(len(self.lines),
                           self.scroll_line + visible + 1)):
            if i == self.cursor_y:
                pygame.draw.rect(surface, (30, 40, 60),
                                 pygame.Rect(code_rect.x + 4, y,
                                             code_rect.width - 8, line_h))
            num_surf = code_font.render(f"{i+1:>3}", True, (110, 120, 145))
            surface.blit(num_surf, (code_rect.x + 8, y))

            line_text = truncate_text(self.lines[i], code_font,
                                      code_rect.width - gutter_w - 16)
            color = TEXT_BRIGHT
            if self.lines[i].lstrip().startswith("#"):
                color = (120, 140, 120)
            ts = code_font.render(line_text, True, color)
            surface.blit(ts, (code_rect.x + gutter_w + 8, y))
            y += line_h

        if self.app.text_focus is self and self.blink < 0.5:
            cx = code_rect.x + gutter_w + 8
            cy = code_rect.y + 6 + (self.cursor_y - self.scroll_line) * line_h
            prefix = self.lines[self.cursor_y][:self.cursor_x]
            cw = code_font.size(prefix)[0]
            caret = pygame.Rect(cx + cw, cy, 2, line_h)
            if code_rect.collidepoint(caret.topleft):
                pygame.draw.rect(surface, CARET, caret)

        surface.set_clip(prev_clip)

        arrow_w, arrow_h = 64, 72
        gap = 12
        cx = w - arrow_w - 12
        cy_center = (50 + (h - vk_h - 6 - NAV_BAR_H)) // 2

        up_rect = pygame.Rect(cx, cy_center - arrow_h - gap // 2,
                              arrow_w, arrow_h)
        down_rect = pygame.Rect(cx, cy_center + gap // 2,
                                arrow_w, arrow_h)
        self.scroll_btn_up = up_rect
        self.scroll_btn_down = down_rect

        label_font = self.app.font("ui", 10, bold=True)
        lbl = label_font.render("СКРОЛЛ", True, TEXT_DIM)
        surface.blit(lbl, (up_rect.x + (up_rect.w - lbl.get_width()) // 2,
                           up_rect.y - 16))

        pygame.draw.rect(surface, (40, 90, 150), up_rect, border_radius=10)
        pygame.draw.rect(surface, (90, 150, 210), up_rect, width=2,
                         border_radius=10)
        big_font = self.app.font("ui", 40, bold=True)
        up_sym = big_font.render("^", True, (255, 255, 255))
        surface.blit(up_sym, up_sym.get_rect(center=up_rect.center))

        pygame.draw.rect(surface, (40, 90, 150), down_rect, border_radius=10)
        pygame.draw.rect(surface, (90, 150, 210), down_rect, width=2,
                         border_radius=10)
        down_sym = big_font.render("v", True, (255, 255, 255))
        surface.blit(down_sym, down_sym.get_rect(center=down_rect.center))

        total = len(self.lines)
        pos_text = f"{self.scroll_line + 1}-" \
                   f"{min(total, self.scroll_line + visible)}/{total}"
        pos_font = self.app.font("mono", 10)
        pos_surf = pos_font.render(pos_text, True, TEXT_DIM)
        pos_x = down_rect.x + (down_rect.w - pos_surf.get_width()) // 2
        surface.blit(pos_surf, (pos_x, down_rect.bottom + 6))

        if self.path:
            name_font = self.app.font("ui", 11)
            name = truncate_text(self.path.name, name_font, arrow_w + 20)
            ns = name_font.render(name, True, TEXT_DIM)
            surface.blit(ns, (w - ns.get_width() - 12, 22))


# ============================================================================
# КОНСОЛЬ
# ============================================================================

class ConsoleScreen(BaseScreen):
    MAX_LINES = 500

    def __init__(self, app: "App") -> None:
        super().__init__(app)
        self.lines: List[Tuple[str, Tuple[int, int, int]]] = []
        self.cwd = PROJECT_DIR
        self.auto_scroll = True
        self.process: Optional[subprocess.Popen] = None
        self.lock = threading.Lock()
        self.buttons: List[TouchButton] = []
        self.input = TextInput(
            pygame.Rect(0, 0, 1, 1), "Команда...",
            on_submit=self._on_submit, app=app)
        self.run_start_index = 0
        self._build_buttons()
        self._append("Консоль готова. Тапните в поле ввода ниже.", ACCENT)

    def apply_text_input(self, text: str) -> None:
        if self.input.active:
            for ch in text:
                self.input.insert(ch)

    def _append(self, text: str, color: Tuple[int, int, int]) -> None:
        with self.lock:
            self.lines.append((text, color))
            if len(self.lines) > self.MAX_LINES:
                removed = len(self.lines) - self.MAX_LINES
                self.lines = self.lines[-self.MAX_LINES:]
                self.run_start_index = max(0, self.run_start_index - removed)

    def _on_submit(self, cmd: str) -> None:
        if not cmd.strip():
            return
        with self.lock:
            self.run_start_index = len(self.lines)

        self._append(f"> {cmd}", ACCENT)
        self.input.text = ""
        self.app.set_text_focus(self.input)
        LOG.info("CONSOLE", f"> {cmd}")

        parts = cmd.strip().split()
        if parts[0] == "cd":
            try:
                target = Path(parts[1]) if len(parts) > 1 else Path.home()
                if not target.is_absolute():
                    target = self.cwd / target
                target = target.resolve()
                if target.is_dir():
                    self.cwd = target
                    self._append(f"-> {self.cwd}", TEXT_DIM)
                    LOG.info("CONSOLE", f"cd -> {self.cwd}")
                else:
                    self._append(f"Нет каталога: {target}", ERROR)
                    LOG.error("CONSOLE", f"Нет каталога: {target}")
            except Exception as exc:
                self._append(f"Ошибка: {exc}", ERROR)
                LOG.error("CONSOLE", str(exc))
            return
        if parts[0] in ("cls", "clear"):
            with self.lock:
                self.lines.clear()
                self.run_start_index = 0
            return

        def worker() -> None:
            try:
                proc = subprocess.Popen(
                    cmd, shell=True, cwd=str(self.cwd),
                    stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                    text=True, encoding="utf-8", errors="replace", bufsize=1,
                )
                self.process = proc
                assert proc.stdout is not None
                for line in proc.stdout:
                    clean = line.rstrip("\n")
                    self._append(clean, TEXT_BRIGHT)
                    LOG.log("CONSOLE", clean)
                code = proc.wait()
                color = SUCCESS if code == 0 else ERROR
                self._append(f"[{code}]", color)
                LOG.info("CONSOLE", f"Код возврата: {code}")
            except Exception as exc:
                self._append(f"Ошибка: {exc}", ERROR)
                LOG.error("CONSOLE", str(exc))

        threading.Thread(target=worker, daemon=True).start()

    def copy_output(self) -> None:
        use_session = True
        with self.lock:
            if use_session:
                start = max(0, min(self.run_start_index, len(self.lines)))
            else:
                start = 0
            chunk = [(line, color) for line, color in self.lines[start:]
                     if not line.startswith("> ")]
            text = "\n".join(line for line, _ in chunk)
            total_lines = len(chunk)

        if not text.strip():
            self.app.toast("Нечего копировать", WARNING)
            return

        result = copy_to_clipboard(text)
        if result is True:
            self.app.toast(f"Скопировано {total_lines} строк", SUCCESS)
        elif result == "file":
            self.app.toast(
                f"Сохранено в clipboard.txt ({total_lines} стр.)",
                WARNING, duration=3.0,
            )
        else:
            preview = text[:60].replace("\n", " ")
            self.app.toast(f"Не удалось: {preview}...", ERROR, duration=3.0)

    def _build_buttons(self) -> None:
        bh = 36
        gap = 5
        self.buttons = []
        x = 6
        for label, cb, col, bw in [
            ("Очистить", self._clear, (170, 80, 80), 85),
            ("Выполнить", self._run_input, (60, 140, 100), 105),
            ("Копир.", self.copy_output, (60, 140, 100), 75),
        ]:
            self.buttons.append(TouchButton(label, cb, color=col,
                                            rect=pygame.Rect(x, 6, bw, bh)))
            x += bw + gap

    def _clear(self) -> None:
        with self.lock:
            self.lines.clear()
            self.run_start_index = 0

    def _toggle_keyboard(self) -> None:
        if self.app.text_focus is self.input and self.app.vk.visible:
            self.app.clear_text_focus()
        else:
            self.input.focus()

    def _run_input(self) -> None:
        if self.input.text:
            self._on_submit(self.input.text)

    def handle_event(self, event: pygame.event.Event) -> None:
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return
        if self.input.handle_event(event):
            return
        for btn in self.buttons:
            if btn.handle_event(event):
                return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.dragging = True
            self.drag_start_y = event.pos[1]
            self.drag_start_scroll = self.scroll
            self.auto_scroll = False
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            dy = event.pos[1] - self.drag_start_y
            if abs(dy) > 6:
                self.scroll = max(0, self.drag_start_scroll - dy)

    def update(self, dt: float) -> None:
        for b in self.buttons:
            b.update(dt)
        self.input.update(dt)

    def draw(self, surface: pygame.Surface) -> None:
        w, h = surface.get_size()
        surface.fill((10, 12, 16))

        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)

        cwd_font = self.app.font("mono", 11)
        cwd_text = truncate_text(str(self.cwd), cwd_font, w - 200)
        cs = cwd_font.render(cwd_text, True, TEXT_DIM)
        surface.blit(cs, (8, 46))

        with self.lock:
            start_i = max(0, min(self.run_start_index, len(self.lines)))
            copied_lines = sum(1 for line, _ in self.lines[start_i:]
                               if not line.startswith("> "))
        hint_font = self.app.font("ui", 10)
        hint = hint_font.render(f"Копир. -> {copied_lines} стр.",
                                True, TEXT_DIM)
        surface.blit(hint, (w - hint.get_width() - 8, 48))

        vk_h = self.app.vk.rect.height if self.app.vk.visible else 0
        input_h = 42
        out_top = 64
        out_bottom = h - vk_h - input_h - 6 - NAV_BAR_H
        out_rect = pygame.Rect(6, out_top, w - 12, max(60, out_bottom - out_top))
        pygame.draw.rect(surface, (8, 10, 14), out_rect, border_radius=6)

        font = self.app.font("mono", 12)
        line_h = font.get_linesize()
        with self.lock:
            total = len(self.lines)

        visible = out_rect.height // line_h - 1
        if self.auto_scroll:
            self.scroll = max(0, total - visible)
        max_scroll = max(0, total - visible)
        self.scroll = min(self.scroll, max_scroll)

        start = self.scroll
        end = min(total, start + visible + 1)

        prev_clip = surface.get_clip()
        surface.set_clip(out_rect.inflate(-6, -6))
        y = out_rect.y + 6
        with self.lock:
            n = len(self.lines)
            for i in range(start, end):
                if i >= n:
                    break
                line, color = self.lines[i]
                if i >= self.run_start_index and line.strip() \
                        and not line.startswith("> "):
                    pygame.draw.rect(surface, (40, 70, 120),
                                     pygame.Rect(out_rect.x + 2, y, 3,
                                                 line_h - 2))
                line = truncate_text(line, font, out_rect.width - 24)
                ts = font.render(line, True, color)
                surface.blit(ts, (out_rect.x + 12, y))
                y += line_h
        surface.set_clip(prev_clip)

        input_rect = pygame.Rect(6, h - vk_h - input_h - 2 - NAV_BAR_H,
                                 w - 12, input_h)
        self.input.set_rect(input_rect)
        self.input.draw(surface, self.app.font("mono", 13))


# ============================================================================
# ЛОГИ
# ============================================================================

class LogsScreen(BaseScreen):
    def __init__(self, app):
        super().__init__(app)
        self.auto_scroll = False
        self.scroll = 0
        self.max_scroll = 0
        self.buttons = [
            TouchButton("Назад", app.back_to_menu,
                        color=(90, 100, 130),
                        rect=pygame.Rect(6, 6, 80, 36)),
            TouchButton("Обновить", self._reload,
                        color=(60, 120, 180),
                        rect=pygame.Rect(90, 6, 100, 36)),
            TouchButton("Очистить", self._clear,
                        color=(170, 80, 80),
                        rect=pygame.Rect(195, 6, 100, 36)),
            TouchButton("Копир.", self._share,
                        color=(60, 140, 100),
                        rect=pygame.Rect(300, 6, 80, 36)),
        ]
        self.scroll_btn_up: Optional[pygame.Rect] = None
        self.scroll_btn_down: Optional[pygame.Rect] = None

    def _reload(self):
        self.redraw()

    def _clear(self):
        LOG.clear()
        self.app.toast("Логи очищены", SUCCESS)
        self.scroll = 0
        self.redraw()

    def _share(self):
        try:
            text = LOG_FILE.read_text(encoding="utf-8", errors="ignore") if LOG_FILE.exists() else ""
            if not text:
                text = "\n".join(getattr(LOG, "lines", [])[-200:])
            CLIPBOARD_FILE.write_text(text[-50000:], encoding="utf-8")
            try:
                import pyperclip
                pyperclip.copy(text[-20000:])
            except Exception:
                pass
            self.app.toast("Лог скопирован / сохранён", SUCCESS)
            LOG.info("LOGS", "Лог отправлен в буфер/clipboard.txt")
        except Exception as e:
            self.app.toast(f"Не удалось: {e}", ERROR)

    def handle_event(self, event):
        super().handle_event(event)
        if event.type in (pygame.TEXTINPUT, pygame.TEXTEDITING):
            return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if self.scroll_btn_up and self.scroll_btn_up.collidepoint(event.pos):
                self.scroll = max(0, self.scroll - 5)
                return
            if self.scroll_btn_down and self.scroll_btn_down.collidepoint(event.pos):
                self.scroll += 5
                return

        for b in self.buttons:
            if b.handle_event(event):
                return

        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            self.dragging = True
            self.drag_start_y = event.pos[1]
            self.drag_start_scroll = self.scroll
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.dragging = False
        elif event.type == pygame.MOUSEMOTION and self.dragging:
            dy = event.pos[1] - self.drag_start_y
            if abs(dy) > 6:
                self.scroll = max(0, self.drag_start_scroll - dy)

    def update(self, dt):
        for b in self.buttons:
            b.update(dt)

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(PANEL_BG)
        anim = self.animations_on()
        for b in self.buttons:
            b.draw(surface, self.app.font("ui", 12, bold=True),
                   animations=anim)

        log_rect = pygame.Rect(6, 50, w - 12, h - 56 - NAV_BAR_H)
        pygame.draw.rect(surface, (10, 12, 16), log_rect, border_radius=6)

        try:
            if LOG_FILE.exists():
                text = LOG_FILE.read_text(encoding="utf-8", errors="replace")
                lines = text.split("\n")
            else:
                lines = ["Лог пуст"]
        except Exception as e:
            lines = [f"Ошибка чтения: {e}"]

        font = self.app.font("mono", 11)
        line_h = font.get_linesize()
        total = len(lines)
        visible = max(1, (log_rect.height - 12) // line_h)
        self.max_scroll = max(0, total - visible)
        self.scroll = max(0, min(self.scroll, self.max_scroll))

        start = self.scroll
        end = min(total, start + visible + 1)

        prev_clip = surface.get_clip()
        surface.set_clip(log_rect.inflate(-6, -6))
        y = log_rect.y + 6
        for i in range(start, end):
            line = lines[i]
            text = truncate_text(line, font, log_rect.width - 20)
            color = ERROR if "ERROR" in line else \
                WARNING if "WARN" in line else TEXT_BRIGHT
            ts = font.render(text, True, color)
            surface.blit(ts, (log_rect.x + 10, y))
            y += line_h
        surface.set_clip(prev_clip)

        pos_font = self.app.font("mono", 10)
        pos_text = f"{start + 1}-{min(total, start + visible)}/{total}"
        pos_surf = pos_font.render(pos_text, True, TEXT_DIM)
        surface.blit(pos_surf, (w - pos_surf.get_width() - 8, 52))

        arrow_w, arrow_h = 60, 66
        gap = 12
        cx = w - arrow_w - 12
        cy_center = (50 + (h - 6 - NAV_BAR_H)) // 2

        up_rect = pygame.Rect(cx, cy_center - arrow_h - gap // 2,
                              arrow_w, arrow_h)
        down_rect = pygame.Rect(cx, cy_center + gap // 2,
                                arrow_w, arrow_h)
        self.scroll_btn_up = up_rect
        self.scroll_btn_down = down_rect

        label_font = self.app.font("ui", 10, bold=True)
        lbl = label_font.render("ЛОГИ", True, TEXT_DIM)
        surface.blit(lbl, (up_rect.x + (up_rect.w - lbl.get_width()) // 2,
                           up_rect.y - 16))

        pygame.draw.rect(surface, (40, 90, 150), up_rect, border_radius=10)
        pygame.draw.rect(surface, (90, 150, 210), up_rect, width=2,
                         border_radius=10)
        big_font = self.app.font("ui", 36, bold=True)
        up_sym = big_font.render("^", True, (255, 255, 255))
        surface.blit(up_sym, up_sym.get_rect(center=up_rect.center))

        pygame.draw.rect(surface, (40, 90, 150), down_rect, border_radius=10)
        pygame.draw.rect(surface, (90, 150, 210), down_rect, width=2,
                         border_radius=10)
        down_sym = big_font.render("v", True, (255, 255, 255))
        surface.blit(down_sym, down_sym.get_rect(center=down_rect.center))


# ============================================================================
# ВРЕМЯ
# ============================================================================

