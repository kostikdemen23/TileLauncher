from __future__ import annotations

import os
import sys
import traceback
from pathlib import Path

_CANDIDATES = []
try:
    _CANDIDATES.append(Path(__file__).resolve().parent)
except Exception:
    pass
try:
    _CANDIDATES.append(Path.cwd())
except Exception:
    pass
_CANDIDATES += [
    Path("/storage/emulated/0/TileLauncher"),
    Path("/storage/emulated/0/Documents/TileLauncher"),
    Path("/storage/emulated/0/Download/TileLauncher"),
    Path("/sdcard/TileLauncher"),
    Path("/sdcard/Documents/TileLauncher"),
    Path("/sdcard/Download/TileLauncher"),
]

def _find_root() -> Path:
    seen = set()
    for cand in _CANDIDATES:
        try:
            c = cand.resolve()
        except Exception:
            c = cand
        if c in seen:
            continue
        seen.add(c)
        if (c / "system_ui" / "tl_core.py").exists():
            return c
    try:
        return Path(__file__).resolve().parent
    except Exception:
        return Path.cwd()

_ROOT = _find_root()
_SYS = _ROOT / "system_ui"

print(f"[main-22] root = {_ROOT}")
print(f"[main-22] system_ui = {_SYS}")

if str(_SYS) not in sys.path:
    sys.path.insert(0, str(_SYS))
if str(_ROOT) not in sys.path:
    sys.path.insert(0, str(_ROOT))

try:
    import pygame  # noqa: F401
except ImportError:
    print("pygame не найден")
    sys.exit(1)

_required = [
    "tl_core", "tl_keyboard", "tl_widgets", "tl_home",
    "tl_files", "tl_music", "tl_time", "tl_system", "tl_app",
]
_missing = [f"{m}.py" for m in _required if not (_SYS / f"{m}.py").exists()]
if _missing:
    print("НЕТ ФАЙЛОВ В system_ui:")
    for f in _missing:
        print(" -", f)
    print(f"Ожидалось: {_SYS}")
    sys.exit(1)

from tl_core import LOG, APP_NAME, APP_VERSION
from tl_app import App


def main() -> int:
    print(f"{APP_NAME} {APP_VERSION}")
    try:
        return App().run()
    except Exception as exc:
        print("КРИТИЧЕСКАЯ ОШИБКА:", exc, file=sys.stderr)
        try:
            LOG.error("APP", f"{exc}\n{traceback.format_exc()}")
        except Exception:
            pass
        traceback.print_exc()
        return 1


if __name__ == "__main__":
    sys.exit(main())