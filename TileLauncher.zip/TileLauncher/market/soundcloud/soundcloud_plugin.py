#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
SoundCloud — плагин Tile Launcher.
Поиск, избранное, Play в лаунчере / Web.
"""

PLUGIN_APP = True

import json
import re
import ssl
import threading
import urllib.error
import urllib.parse
import urllib.request
import webbrowser
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import pygame

BG = (18, 18, 22)
CARD = (28, 28, 34)
ACCENT = (255, 85, 0)
TEXT = (245, 245, 245)
DIM = (150, 155, 165)
ERR = (220, 80, 80)
ROW_H = 78

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/122.0.0.0 Safari/537.36"
)
FALLBACK_CLIENT_ID = "Pb72ranhoyt6gw7hM7TkzUItXlMWSNSo"

CFG_PATHS = [
    Path("/storage/emulated/0/TileLauncher/market/soundcloud/sc_cfg.json"),
    Path("/storage/emulated/0/TileLauncher/sc_cfg.json"),
    Path(__file__).resolve().parent / "sc_cfg.json",
]

_SSL = ssl.create_default_context()


def _cfg_path() -> Path:
    for p in CFG_PATHS:
        try:
            p.parent.mkdir(parents=True, exist_ok=True)
            return p
        except Exception:
            continue
    return Path(__file__).resolve().parent / "sc_cfg.json"


def _headers(json_accept: bool = True) -> Dict[str, str]:
    h = {
        "User-Agent": UA,
        "Origin": "https://soundcloud.com",
        "Referer": "https://soundcloud.com/",
        "Accept-Language": "en-US,en;q=0.9",
    }
    h["Accept"] = (
        "application/json, text/javascript, */*; q=0.01"
        if json_accept
        else "*/*"
    )
    return h


def _http_get(url: str, timeout: int = 20, json_accept: bool = True) -> bytes:
    req = urllib.request.Request(url, headers=_headers(json_accept))
    try:
        with urllib.request.urlopen(req, timeout=timeout, context=_SSL) as r:
            return r.read()
    except urllib.error.HTTPError as e:
        raise RuntimeError(f"HTTP {e.code}") from e
    except Exception as e:
        raise RuntimeError(str(e)[:80]) from e


def _http_json(url: str, timeout: int = 20) -> Any:
    return json.loads(_http_get(url, timeout, True).decode("utf-8", "replace"))


def fetch_client_id() -> str:
    try:
        html = _http_get("https://soundcloud.com", 15, False).decode("utf-8", "replace")
        scripts = re.findall(
            r'src="(https://a-v2\.sndcdn\.com/assets/[^"]+\.js)"', html
        )
        for src in scripts:
            try:
                js = _http_get(src, 15, False).decode("utf-8", "replace")
            except Exception:
                continue
            m = re.search(r'client_id:"([a-zA-Z0-9]{16,})"', js)
            if m:
                return m.group(1)
    except Exception:
        pass
    return FALLBACK_CLIENT_ID


def load_cfg() -> Dict[str, Any]:
    try:
        p = _cfg_path()
        if p.exists():
            return json.loads(p.read_text(encoding="utf-8"))
    except Exception:
        pass
    return {"client_id": "", "favorites": [], "last_query": ""}


def save_cfg(data: Dict[str, Any]) -> None:
    try:
        _cfg_path().write_text(
            json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8"
        )
    except Exception:
        pass


def ms_to_time(ms: int) -> str:
    try:
        s = max(0, int(ms) // 1000)
    except Exception:
        return "--:--"
    m, s = divmod(s, 60)
    return f"{m}:{s:02d}"


def open_url(url: str) -> None:
    if not url:
        return
    try:
        webbrowser.open(url)
        return
    except Exception:
        pass
    try:
        from jnius import autoclass
        activity = None
        for name in (
            "org.libsdl.app.SDLActivity",
            "org.kivy.android.PythonActivity",
        ):
            try:
                cls = autoclass(name)
                activity = getattr(cls, "mSingleton", None) or getattr(
                    cls, "mActivity", None
                )
                if activity:
                    break
            except Exception:
                continue
        if activity:
            Intent = autoclass("android.content.Intent")
            Uri = autoclass("android.net.Uri")
            activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)))
    except Exception:
        pass



def normalize_sc_url(url: str) -> str:
    """m.soundcloud.com → soundcloud.com (resolve иначе 404)."""
    u = (url or "").strip()
    if not u:
        return u
    u = u.replace("https://m.soundcloud.com", "https://soundcloud.com")
    u = u.replace("http://m.soundcloud.com", "https://soundcloud.com")
    u = u.replace("https://www.soundcloud.com", "https://soundcloud.com")
    # убрать query/fragment мобильного приложения
    if "soundcloud.com" in u:
        u = u.split("?")[0].split("#")[0]
    return u


class SoundCloudPlugin:
    title = "SoundCloud"

    def __init__(self, app):
        self.app = app
        self.cfg = load_cfg()
        self.query = str(self.cfg.get("last_query") or "")
        self.editing = False
        self.loading = False
        self.status = "Ready"
        self.error = ""
        self.client_id = str(self.cfg.get("client_id") or "") or FALLBACK_CLIENT_ID
        self.tracks: List[Dict[str, Any]] = []
        self.scroll = 0
        self.max_scroll = 0
        self.drag_y = None
        self.drag_scroll = 0
        self.row_rects: List[Tuple[pygame.Rect, Dict[str, Any], str]] = []
        self.tab = "search"
        self.playing_title = ""
        self.is_playing = False
        threading.Thread(target=self._init_client, daemon=True).start()

    def _redraw(self) -> None:
        try:
            self.app._needs_redraw = True
        except Exception:
            pass

    def _init_client(self) -> None:
        self.status = "client_id..."
        self._redraw()
        cid = fetch_client_id()
        self.client_id = cid
        self.cfg["client_id"] = cid
        save_cfg(self.cfg)
        self.status = "Ready"
        self._redraw()

    def insert(self, ch: str) -> None:
        if self.editing:
            self.query += ch

    def backspace(self) -> None:
        if self.editing and self.query:
            self.query = self.query[:-1]

    def submit(self) -> None:
        self.editing = False
        try:
            self.app.clear_text_focus()
        except Exception:
            pass
        self.search()

    def apply_text_input(self, text: str) -> None:
        if self.editing:
            self.query += text

    def _api(self, path: str, params: Optional[Dict[str, Any]] = None) -> Any:
        p = dict(params or {})
        p["client_id"] = self.client_id or FALLBACK_CLIENT_ID
        url = "https://api-v2.soundcloud.com" + path + "?" + urllib.parse.urlencode(p)
        return _http_json(url)

    def _norm(self, t: Dict[str, Any]) -> Dict[str, Any]:
        user = t.get("user") or {}
        art = t.get("artwork_url") or user.get("avatar_url") or ""
        if art:
            art = art.replace("-large", "-t200x200")
        return {
            "title": t.get("title") or "Track",
            "artist": user.get("username") or "",
            "permalink_url": t.get("permalink_url") or "",
            "duration": t.get("duration") or 0,
            "artwork": art,
            "id": t.get("id"),
            "streamable": bool(t.get("streamable", True)),
            "media": t.get("media") or {},
        }

    def search(self) -> None:
        q = self.query.strip()
        if not q:
            self.error = "Enter query"
            return
        self.cfg["last_query"] = q
        save_cfg(self.cfg)
        self.loading = True
        self.error = ""
        self.status = "Search..."
        self.tab = "search"
        self.scroll = 0
        self._redraw()

        def work():
            try:
                if not self.client_id:
                    self.client_id = fetch_client_id()
                if "soundcloud.com/" in q:
                    tr = self._resolve(normalize_sc_url(q))
                    self.tracks = [tr] if tr else []
                    self.status = f"Link: {len(self.tracks)}"
                else:
                    data = self._api(
                        "/search/tracks",
                        {"q": q, "limit": 24, "app_locale": "en"},
                    )
                    self.tracks = [
                        self._norm(x) for x in (data.get("collection") or [])
                    ]
                    self.status = f"Found: {len(self.tracks)}"
                if not self.tracks:
                    self.error = "Empty"
            except Exception:
                try:
                    self.client_id = fetch_client_id()
                    self.cfg["client_id"] = self.client_id
                    save_cfg(self.cfg)
                    data = self._api(
                        "/search/tracks",
                        {"q": q, "limit": 24, "app_locale": "en"},
                    )
                    self.tracks = [
                        self._norm(x) for x in (data.get("collection") or [])
                    ]
                    self.status = f"Found: {len(self.tracks)}"
                    self.error = ""
                except Exception as e2:
                    self.tracks = []
                    self.error = str(e2)[:90]
                    self.status = "Search error"
            self.loading = False
            self._redraw()

        threading.Thread(target=work, daemon=True).start()

    def _resolve(self, url: str) -> Optional[Dict[str, Any]]:
        try:
            url = normalize_sc_url(url)
            data = self._api("/resolve", {"url": url})
            if not data:
                return None
            if data.get("tracks"):
                return self._norm(data["tracks"][0])
            return self._norm(data)
        except Exception:
            return {
                "title": "SoundCloud link",
                "artist": "",
                "permalink_url": url,
                "duration": 0,
                "artwork": "",
                "id": None,
                "streamable": False,
                "media": {},
            }

    def _refresh_track(self, track: Dict[str, Any]) -> Dict[str, Any]:
        """Подтянуть media: id → tracks API, иначе resolve по ссылке."""
        merged = dict(track)
        cid = self.client_id or FALLBACK_CLIENT_ID
        errors = []

        def apply(data: Dict[str, Any]) -> None:
            if not isinstance(data, dict):
                return
            if data.get("media"):
                merged["media"] = data["media"]
            if data.get("id") is not None:
                merged["id"] = data["id"]
            if data.get("permalink_url"):
                merged["permalink_url"] = data["permalink_url"]
            if data.get("title"):
                merged["title"] = data["title"]
            if "streamable" in data:
                merged["streamable"] = data["streamable"]

        tid = track.get("id")
        if tid:
            for path in (f"/tracks/{tid}", f"/tracks/soundcloud:tracks:{tid}"):
                try:
                    data = self._api(path)
                    apply(data)
                    if (merged.get("media") or {}).get("transcodings"):
                        return merged
                except Exception as e:
                    errors.append(str(e))

        url = normalize_sc_url(str(track.get("permalink_url") or ""))
        if url and "soundcloud.com" in url:
            try:
                data = self._api("/resolve", {"url": url})
                apply(data)
                if data.get("tracks"):
                    apply(data["tracks"][0])
            except Exception as e:
                errors.append(str(e))

        # уже есть media из поиска — ок
        if (merged.get("media") or {}).get("transcodings"):
            return merged

        # обновить client_id и ещё раз
        try:
            self.client_id = fetch_client_id()
            self.cfg["client_id"] = self.client_id
            save_cfg(self.cfg)
            if tid:
                data = self._api(f"/tracks/{tid}")
                apply(data)
        except Exception as e:
            errors.append(str(e))

        if (merged.get("media") or {}).get("transcodings"):
            return merged

        msg = errors[-1] if errors else "empty"
        raise RuntimeError(f"No media: {msg}")

    def _auth_stream(self, tr: Dict[str, Any], cid: str) -> str:
        u = tr.get("url") or ""
        if not u:
            raise RuntimeError("empty transcoding url")
        if "client_id=" not in u:
            u += ("&" if "?" in u else "?") + "client_id=" + urllib.parse.quote(cid)
        data = _http_json(u, 20)
        stream = data.get("url") or ""
        if not stream.startswith("http"):
            raise RuntimeError("no url in transcoding")
        return stream

    def _progressive_url(self, track: Dict[str, Any]) -> str:
        cid = self.client_id or FALLBACK_CLIENT_ID
        # сначала пробуем media из поиска, потом refresh
        trans = list((track.get("media") or {}).get("transcodings") or [])
        if not trans:
            track = self._refresh_track(track)
            trans = list((track.get("media") or {}).get("transcodings") or [])
        else:
            # дополним, если progressive нет
            has_prog = any(
                (tr.get("format") or {}).get("protocol") == "progressive"
                for tr in trans
            )
            if not has_prog:
                try:
                    track = self._refresh_track(track)
                    trans = list((track.get("media") or {}).get("transcodings") or []) or trans
                except Exception:
                    pass
        if not trans:
            raise RuntimeError("No media (check net / client_id)")

        # 1) progressive mpeg
        ranked = []
        for tr in trans:
            fmt = tr.get("format") or {}
            proto = (fmt.get("protocol") or "").lower()
            mime = (fmt.get("mime_type") or "").lower()
            score = 0
            if proto == "progressive":
                score += 10
            if "mpeg" in mime and "mpegurl" not in mime and "mp4" not in mime:
                score += 5
            if "mpegurl" in mime:
                score -= 20
            if proto == "hls" and "mpeg" in mime and "mpegurl" not in mime:
                score += 2  # иногда это всё же полезный playlist
            ranked.append((score, tr))
        ranked.sort(key=lambda x: -x[0])

        last = None
        for score, tr in ranked:
            if score < 0:
                continue
            fmt = tr.get("format") or {}
            proto = (fmt.get("protocol") or "").lower()
            mime = (fmt.get("mime_type") or "").lower()
            try:
                stream = self._auth_stream(tr, cid)
            except Exception as e:
                last = e
                continue
            # progressive = прямой mp3
            if proto == "progressive" or (
                stream.endswith(".mp3") or ".mp3?" in stream or "cf-media.sndcdn" in stream
            ):
                return stream
            # hls mpeg playlist — собрать сегменты ниже через спец. метод
            if "playlist" in stream or "hls" in stream:
                try:
                    return self._hls_to_mp3_url_or_path(stream)
                except Exception as e:
                    last = e
                    continue
        raise RuntimeError(str(last) if last else "No progressive mp3")

    def _hls_to_mp3_url_or_path(self, playlist_url: str) -> str:
        """Скачать HLS (mpeg) сегменты в один файл, вернуть путь file:// не нужен — путь."""
        text = _http_get(playlist_url, 20, False).decode("utf-8", "replace")
        lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
        media = [ln for ln in lines if not ln.startswith("#")]
        if not media:
            raise RuntimeError("empty HLS")
        # вложенный playlist
        first = media[0]
        if not first.startswith("http"):
            first = urllib.parse.urljoin(playlist_url, first)
        if first.endswith(".m3u8") or "playlist" in first:
            text = _http_get(first, 20, False).decode("utf-8", "replace")
            lines = [ln.strip() for ln in text.splitlines() if ln.strip()]
            media = [ln for ln in lines if not ln.startswith("#")]
            base = first
        else:
            base = playlist_url
        if not media:
            raise RuntimeError("empty HLS segments")
        # ограничим длину — первые ~3 мин (~90 сегментов по ~2с) или 40 сегментов
        segs = media[:40]
        chunks = []
        for seg in segs:
            su = seg if seg.startswith("http") else urllib.parse.urljoin(base, seg)
            chunks.append(_http_get(su, 25, False))
        blob = b"".join(chunks)
        if len(blob) < 2000:
            raise RuntimeError("HLS too short")
        path = self._tmp()
        # иногда ts — pygame может не открыть; пробуем как .mp3 всё равно
        path = path.with_suffix(".mp3")
        path.write_bytes(blob)
        return str(path)

    def _tmp(self) -> Path:
        for base in (
            Path("/storage/emulated/0/TileLauncher"),
            Path(__file__).resolve().parent,
            Path("/tmp"),
        ):
            try:
                base.mkdir(parents=True, exist_ok=True)
                return base / "sc_cache.mp3"
            except Exception:
                continue
        return Path("sc_cache.mp3")

    def play_track(self, track: Dict[str, Any]) -> None:
        self.playing_title = str(track.get("title") or "track")
        self.is_playing = True
        self.error = ""
        self.status = "Loading mp3..."
        self._redraw()

        def work():
            try:
                stream = self._progressive_url(track)
                if stream.startswith("http"):
                    self.status = "Download..."
                    self._redraw()
                    raw = _http_get(stream, 60, False)
                    if len(raw) < 2000:
                        raise RuntimeError("Short response")
                    path = self._tmp()
                    path.write_bytes(raw)
                else:
                    # уже локальный файл из HLS
                    path = Path(stream)
                try:
                    if not pygame.mixer.get_init():
                        pygame.mixer.init(44100, -16, 2, 2048)
                except Exception:
                    pygame.mixer.init()
                try:
                    pygame.mixer.music.stop()
                except Exception:
                    pass
                pygame.mixer.music.load(str(path))
                pygame.mixer.music.play()
                self.is_playing = True
                self.status = "Play: " + self.playing_title[:40]
            except Exception as e:
                self.is_playing = False
                self.status = "Play error"
                self.error = str(e)[:120]
                # сброс client_id для следующей попытки
                try:
                    self.client_id = fetch_client_id()
                    self.cfg["client_id"] = self.client_id
                    save_cfg(self.cfg)
                except Exception:
                    pass
            self._redraw()

        threading.Thread(target=work, daemon=True).start()

    def stop(self) -> None:
        try:
            if pygame.mixer.get_init():
                pygame.mixer.music.stop()
        except Exception:
            pass
        self.is_playing = False
        self.playing_title = ""
        self.status = "Stop"
        self._redraw()

    def toggle_fav(self, track: Dict[str, Any]) -> None:
        favs = list(self.cfg.get("favorites") or [])
        url = track.get("permalink_url") or ""
        if any(isinstance(f, dict) and f.get("permalink_url") == url for f in favs):
            favs = [
                f
                for f in favs
                if not (isinstance(f, dict) and f.get("permalink_url") == url)
            ]
            self.status = "Removed Fav"
        else:
            favs.insert(
                0,
                {
                    "title": track.get("title"),
                    "artist": track.get("artist"),
                    "permalink_url": url,
                    "duration": track.get("duration"),
                    "id": track.get("id"),
                    "media": track.get("media") or {},
                },
            )
            favs = favs[:40]
            self.status = "Saved Fav"
        self.cfg["favorites"] = favs
        save_cfg(self.cfg)
        self._redraw()

    def handle_event(self, event) -> None:
        w, h = self.app.screen.get_size()
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            search = pygame.Rect(12, 48, w - 140, 40)
            go = pygame.Rect(w - 120, 48, 52, 40)
            stop = pygame.Rect(w - 62, 48, 50, 40)
            tab_s = pygame.Rect(12, 96, 100, 32)
            tab_f = pygame.Rect(120, 96, 100, 32)
            if search.collidepoint(event.pos):
                self.editing = True
                try:
                    host = self.app.screens.get("plugin")
                    self.app.set_text_focus(host if host else self)
                except Exception:
                    pass
                return
            if go.collidepoint(event.pos):
                self.editing = False
                try:
                    self.app.clear_text_focus()
                except Exception:
                    pass
                self.search()
                return
            if stop.collidepoint(event.pos):
                self.stop()
                return
            if tab_s.collidepoint(event.pos):
                self.tab = "search"
                self.scroll = 0
                return
            if tab_f.collidepoint(event.pos):
                self.tab = "fav"
                self.scroll = 0
                self.tracks = list(self.cfg.get("favorites") or [])
                self.status = f"Fav: {len(self.tracks)}"
                return
            for rect, track, act in self.row_rects:
                if rect.collidepoint(event.pos):
                    if act == "play":
                        self.play_track(track)
                    elif act == "fav":
                        self.toggle_fav(track)
                    elif act == "open":
                        open_url(track.get("permalink_url") or "")
                        self.status = "Web"
                    return
            self.editing = False
            try:
                self.app.clear_text_focus()
            except Exception:
                pass
            self.drag_y = event.pos[1]
            self.drag_scroll = self.scroll
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.drag_y = None
        elif event.type == pygame.MOUSEMOTION and self.drag_y is not None:
            self.scroll = max(
                0,
                min(self.max_scroll, self.drag_scroll + (self.drag_y - event.pos[1])),
            )
        elif event.type == pygame.MOUSEWHEEL:
            self.scroll = max(0, min(self.max_scroll, self.scroll - event.y * 40))
        elif event.type == pygame.KEYDOWN and self.editing:
            if event.key == pygame.K_BACKSPACE:
                self.backspace()
            elif event.key == pygame.K_RETURN:
                self.submit()
            elif event.unicode and event.unicode.isprintable():
                self.insert(event.unicode)

    def update(self, dt: float) -> None:
        pass

    def draw(self, surface: pygame.Surface) -> None:
        w, h = surface.get_size()
        surface.fill(BG)
        font = self.app.font("ui", 14)
        bold = self.app.font("ui", 16, bold=True)
        small = self.app.font("ui", 12)
        tiny = self.app.font("ui", 11)

        surface.blit(bold.render("SoundCloud", True, ACCENT), (14, 12))
        surface.blit(tiny.render(self.status[:48], True, DIM), (130, 16))

        search = pygame.Rect(12, 48, w - 140, 40)
        pygame.draw.rect(surface, CARD, search, border_radius=12)
        label = self.query if self.query else "Search or link"
        surface.blit(
            font.render(label[:32], True, TEXT if self.query else DIM),
            (search.x + 12, search.y + 10),
        )
        go = pygame.Rect(w - 120, 48, 52, 40)
        pygame.draw.rect(surface, ACCENT, go, border_radius=12)
        surface.blit(font.render("OK", True, TEXT), (go.x + 12, go.y + 10))
        stop = pygame.Rect(w - 62, 48, 50, 40)
        pygame.draw.rect(surface, (90, 45, 40), stop, border_radius=12)
        surface.blit(tiny.render("Stop", True, TEXT), (stop.x + 8, stop.y + 12))

        for rect, name, key in (
            (pygame.Rect(12, 96, 100, 32), "Search", "search"),
            (pygame.Rect(120, 96, 100, 32), "Fav", "fav"),
        ):
            col = ACCENT if self.tab == key else CARD
            pygame.draw.rect(surface, col, rect, border_radius=10)
            surface.blit(small.render(name, True, TEXT), (rect.x + 18, rect.y + 8))

        if self.error:
            surface.blit(font.render(self.error[:55], True, ERR), (14, 136))

        if self.loading:
            surface.blit(bold.render("Loading...", True, TEXT), (20, 170))
            return

        y0 = 148 - self.scroll
        if self.error:
            y0 = 168 - self.scroll
        self.row_rects = []
        items = self.tracks
        if self.tab == "fav" and not items:
            items = list(self.cfg.get("favorites") or [])

        y = y0
        for tr in items:
            row = pygame.Rect(10, y, w - 20, ROW_H - 8)
            if row.bottom >= 140 and row.top < h - 56:
                pygame.draw.rect(surface, CARD, row, border_radius=12)
                pygame.draw.rect(
                    surface, ACCENT, pygame.Rect(row.x, row.y, 4, row.h), border_radius=2
                )
                title = str(tr.get("title") or "?")
                artist = str(tr.get("artist") or "")
                dur = ms_to_time(tr.get("duration") or 0)
                surface.blit(
                    font.render(title[:28], True, TEXT), (row.x + 12, row.y + 10)
                )
                surface.blit(
                    small.render(f"{artist[:22]}  {dur}", True, DIM),
                    (row.x + 12, row.y + 40),
                )
                play = pygame.Rect(row.right - 168, row.y + 20, 52, 32)
                web = pygame.Rect(row.right - 110, row.y + 20, 48, 32)
                fav = pygame.Rect(row.right - 56, row.y + 20, 46, 32)
                pygame.draw.rect(surface, ACCENT, play, border_radius=8)
                pygame.draw.rect(surface, (50, 70, 100), web, border_radius=8)
                pygame.draw.rect(surface, (50, 55, 65), fav, border_radius=8)
                surface.blit(tiny.render("Play", True, TEXT), (play.x + 10, play.y + 8))
                surface.blit(tiny.render("Web", True, TEXT), (web.x + 10, web.y + 8))
                surface.blit(tiny.render("Fav", True, TEXT), (fav.x + 10, fav.y + 8))
                self.row_rects.append((play, tr, "play"))
                self.row_rects.append((web, tr, "open"))
                self.row_rects.append((fav, tr, "fav"))
            y += ROW_H

        if not items and not self.loading:
            surface.blit(font.render("OK = search", True, DIM), (20, 180))

        self.max_scroll = max(0, y + self.scroll - (h - 70))
        if self.playing_title:
            pygame.draw.rect(surface, (40, 28, 20), (0, h - 56, w, 36))
            surface.blit(
                small.render("Play: " + self.playing_title[:36], True, ACCENT),
                (12, h - 48),
            )


def create_plugin(app):
    return SoundCloudPlugin(app)
