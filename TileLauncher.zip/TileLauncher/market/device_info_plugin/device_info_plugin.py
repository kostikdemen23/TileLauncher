#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Характеристики устройства — плагин Tile Launcher."""

PLUGIN_APP = True

import os
import platform
import subprocess
import sys
import threading
from pathlib import Path

import pygame

BG = (18, 22, 30)
CARD = (32, 38, 50)
ACCENT = (0, 120, 215)
TEXT = (240, 245, 255)
DIM = (150, 160, 180)
OK = (90, 200, 120)


def read_text(path: str, default: str = "—") -> str:
    try:
        p = Path(path)
        if p.exists():
            return p.read_text(encoding="utf-8", errors="ignore").strip()
    except Exception:
        pass
    return default


def read_first(path: str, default: str = "—") -> str:
    try:
        p = Path(path)
        if p.exists():
            with p.open(encoding="utf-8", errors="ignore") as fh:
                line = fh.readline().strip()
                return line if line else default
    except Exception:
        pass
    return default


def getprop(key: str, default: str = "—") -> str:
    try:
        out = subprocess.check_output(
            ["getprop", key], text=True,
            stderr=subprocess.DEVNULL, timeout=2,
        ).strip()
        return out if out else default
    except Exception:
        return default


def human_bytes(n: int) -> str:
    x = float(n)
    for u in ("B", "KB", "MB", "GB", "TB"):
        if x < 1024 or u == "TB":
            return f"{int(x)} {u}" if u == "B" else f"{x:.2f} {u}"
        x /= 1024
    return f"{n} B"


def collect() -> list:
    sections = []

    # Устройство
    sections.append(("Устройство", [
        f"Производитель: {getprop('ro.product.manufacturer')}",
        f"Бренд: {getprop('ro.product.brand')}",
        f"Модель: {getprop('ro.product.model')}",
        f"Устройство: {getprop('ro.product.device')}",
        f"Android: {getprop('ro.build.version.release')}",
        f"SDK: {getprop('ro.build.version.sdk')}",
        f"Сборка: {getprop('ro.build.display.id')}",
        f"Платформа: {sys.platform}",
        f"Архитектура: {platform.machine()}",
        f"Python: {sys.version.split()[0]}",
    ]))

    # CPU
    model = "—"
    try:
        text = read_text("/proc/cpuinfo")
        for line in text.splitlines():
            if "Hardware" in line or "model name" in line.lower() or "Processor" in line:
                model = line.split(":", 1)[-1].strip()
                break
    except Exception:
        pass
    if model == "—":
        for key in ("ro.hardware", "ro.board.platform", "ro.product.board", "ro.chipname"):
            v = getprop(key)
            if v != "—":
                model = v
                break
    cpu_lines = [
        f"SoC / модель: {model}",
        f"Ядер (логич.): {os.cpu_count() or '—'}",
    ]
    base = Path("/sys/devices/system/cpu")
    if base.exists():
        try:
            cpus = sorted(
                [p for p in base.iterdir()
                 if p.name.startswith("cpu") and p.name[3:].isdigit()],
                key=lambda p: int(p.name[3:]),
            )
            for cpu in cpus[:8]:
                cur = read_first(str(cpu / "cpufreq" / "scaling_cur_freq"))
                mx = read_first(str(cpu / "cpufreq" / "cpuinfo_max_freq"))
                if cur.isdigit():
                    s = f"{cpu.name}: {int(cur)/1000:.0f}"
                    if mx.isdigit():
                        s += f" / {int(mx)/1000:.0f} МГц"
                    else:
                        s += " МГц"
                    cpu_lines.append(s)
        except Exception:
            pass
    sections.append(("Процессор", cpu_lines))

    # Температура
    therm = []
    tbase = Path("/sys/class/thermal")
    if tbase.exists():
        try:
            zones = sorted(
                [p for p in tbase.iterdir() if p.name.startswith("thermal_zone")],
                key=lambda p: int(p.name.replace("thermal_zone", "") or 0),
            )
            for z in zones[:12]:
                raw = read_first(str(z / "temp"))
                typ = read_first(str(z / "type"), z.name)
                if not raw.lstrip("-").isdigit():
                    continue
                val = int(raw)
                c = val / 1000.0 if abs(val) > 1000 else float(val)
                therm.append(f"{typ}: {c:.1f} °C")
        except Exception as e:
            therm.append(f"ошибка: {e}")
    if not therm:
        therm = ["н/д"]
    sections.append(("Температура", therm))

    # ОЗУ
    mem = []
    try:
        total = avail = free = 0
        with open("/proc/meminfo", encoding="utf-8") as fh:
            for line in fh:
                if line.startswith("MemTotal:"):
                    total = int(line.split()[1]) * 1024
                elif line.startswith("MemAvailable:"):
                    avail = int(line.split()[1]) * 1024
                elif line.startswith("MemFree:"):
                    free = int(line.split()[1]) * 1024
                elif line.startswith("SwapTotal:"):
                    mem.append(f"Swap: {human_bytes(int(line.split()[1]) * 1024)}")
        if total:
            used = total - (avail or free)
            mem = [
                f"Всего: {human_bytes(total)}",
                f"Занято: {human_bytes(used)}",
                f"Свободно: {human_bytes(avail or free)}",
            ] + mem
    except Exception as e:
        mem = [f"ошибка: {e}"]
    sections.append(("ОЗУ", mem or ["н/д"]))

    # Диск
    disk = []
    seen = set()
    for p in ("/", "/data", "/sdcard", "/storage/emulated/0"):
        try:
            if not os.path.exists(p):
                continue
            st = os.statvfs(p)
            total = st.f_blocks * st.f_frsize
            free = st.f_bavail * st.f_frsize
            used = total - free
            key = (total, free)
            if key in seen:
                continue
            seen.add(key)
            disk.append(f"{p}: {human_bytes(used)} / {human_bytes(total)} (своб. {human_bytes(free)})")
        except Exception:
            continue
    sections.append(("Накопитель", disk or ["н/д"]))

    # Батарея
    bat = []
    bdir = Path("/sys/class/power_supply")
    if bdir.exists():
        for name in ("battery", "Battery", "BAT0", "BAT1"):
            d = bdir / name
            if not d.exists():
                continue
            cap = read_first(str(d / "capacity"))
            status = read_first(str(d / "status"))
            temp = read_first(str(d / "temp"))
            tech = read_first(str(d / "technology"))
            volt = read_first(str(d / "voltage_now"))
            if cap != "—":
                bat.append(f"Заряд: {cap}%")
            if status != "—":
                bat.append(f"Статус: {status}")
            if tech != "—":
                bat.append(f"Технология: {tech}")
            if temp.lstrip("-").isdigit():
                t = int(temp)
                bat.append(f"Темп.: {t/10:.1f} °C" if t > 100 else f"Темп.: {t} °C")
            if volt.isdigit():
                bat.append(f"Напряжение: {int(volt)/1_000_000:.2f} В")
            break
    if not bat:
        try:
            out = subprocess.check_output(
                ["dumpsys", "battery"], text=True,
                stderr=subprocess.DEVNULL, timeout=3,
            )
            for line in out.splitlines():
                line = line.strip()
                if any(k in line.lower() for k in
                       ("level", "temperature", "status", "voltage", "technology")):
                    bat.append(line)
        except Exception:
            pass
    sections.append(("Батарея", bat or ["н/д"]))

    return sections


class DeviceInfoPlugin:
    title = "Устройство"

    def __init__(self, app):
        self.app = app
        self.sections = []
        self.loading = True
        self.scroll = 0
        self.max_scroll = 0
        self.drag_y = None
        self.drag_scroll = 0
        self._refresh_async()

    def _refresh_async(self):
        self.loading = True

        def work():
            try:
                self.sections = collect()
            except Exception as e:
                self.sections = [("Ошибка", [str(e)])]
            self.loading = False

        threading.Thread(target=work, daemon=True).start()

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if pygame.Rect(100, 8, 100, 36).collidepoint(event.pos):
                self.scroll = 0
                self._refresh_async()
                return
            self.drag_y = event.pos[1]
            self.drag_scroll = self.scroll
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.drag_y = None
        elif event.type == pygame.MOUSEMOTION and self.drag_y is not None:
            dy = self.drag_y - event.pos[1]
            self.scroll = max(0, min(self.max_scroll, self.drag_scroll + dy))
        elif event.type == pygame.MOUSEWHEEL:
            self.scroll = max(0, min(self.max_scroll, self.scroll - event.y * 40))

    def update(self, dt):
        pass

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(BG)
        bold = self.app.font("ui", 16, bold=True)
        font = self.app.font("ui", 13)
        small = self.app.font("ui", 12)

        surface.blit(bold.render("Об устройстве", True, TEXT), (100, 12))
        pygame.draw.rect(surface, ACCENT, pygame.Rect(100, 8, 100, 36), border_radius=8)
        surface.blit(font.render("Обновить", True, TEXT), (112, 16))

        if self.loading and not self.sections:
            surface.blit(font.render("Сбор данных…", True, ACCENT), (16, 60))
            return

        y = 56 - self.scroll
        for title, lines in self.sections:
            # высота карточки
            ch = 36 + len(lines) * 18 + 12
            if y + ch > 40 and y < h:
                pygame.draw.rect(
                    surface, CARD,
                    pygame.Rect(10, y, w - 20, ch),
                    border_radius=12)
                surface.blit(bold.render(title, True, OK), (22, y + 10))
                ly = y + 36
                for line in lines:
                    surface.blit(small.render(line[:70], True, TEXT), (22, ly))
                    ly += 18
            y += ch + 10

        self.max_scroll = max(0, y + self.scroll - (h - 80))
        if self.max_scroll > 0:
            surface.blit(small.render("свайп — прокрутка", True, DIM), (16, h - 70))


def create_plugin(app):
    return DeviceInfoPlugin(app)
