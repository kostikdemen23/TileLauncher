#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""2048 — плагин Tile Launcher."""

PLUGIN_APP = True

import random
import pygame

BG = (22, 25, 32)
EMPTY = (40, 45, 55)
TEXT = (240, 245, 255)
DIM = (150, 160, 180)

COLORS = {
    2: (80, 90, 110),
    4: (70, 100, 130),
    8: (200, 140, 70),
    16: (210, 120, 60),
    32: (220, 90, 60),
    64: (220, 70, 50),
    128: (200, 170, 60),
    256: (190, 160, 50),
    512: (180, 150, 40),
    1024: (160, 130, 200),
    2048: (120, 200, 120),
}


class Game2048Plugin:
    title = "2048"

    def __init__(self, app):
        self.app = app
        self.reset()
        self.touch0 = None

    def reset(self):
        self.b = [[0] * 4 for _ in range(4)]
        self.score = 0
        self.add()
        self.add()
        self.won = False
        self.over = False

    def add(self):
        empty = [(x, y) for y in range(4) for x in range(4) if self.b[y][x] == 0]
        if not empty:
            return
        x, y = random.choice(empty)
        self.b[y][x] = 4 if random.random() < 0.1 else 2

    def compress(self, row):
        row = [v for v in row if v]
        out, score, skip = [], 0, False
        for i, v in enumerate(row):
            if skip:
                skip = False
                continue
            if i + 1 < len(row) and row[i + 1] == v:
                out.append(v * 2)
                score += v * 2
                skip = True
            else:
                out.append(v)
        while len(out) < 4:
            out.append(0)
        return out, score

    def move_left(self, b):
        nb, sc = [], 0
        for row in b:
            r, s = self.compress(row)
            nb.append(r)
            sc += s
        return nb, sc

    def transpose(self, b):
        return [[b[y][x] for y in range(4)] for x in range(4)]

    def reverse(self, b):
        return [list(reversed(r)) for r in b]

    def move(self, direction):
        b = self.b
        if direction == "left":
            nb, sc = self.move_left(b)
        elif direction == "right":
            nb, sc = self.move_left(self.reverse(b))
            nb = self.reverse(nb)
        elif direction == "up":
            nb, sc = self.move_left(self.transpose(b))
            nb = self.transpose(nb)
        else:
            nb, sc = self.move_left(self.reverse(self.transpose(b)))
            nb = self.transpose(self.reverse(nb))
        if nb != self.b:
            self.b = nb
            self.score += sc
            self.add()
            if any(v == 2048 for row in self.b for v in row):
                self.won = True
            if not self.can_move():
                self.over = True

    def can_move(self):
        for y in range(4):
            for x in range(4):
                if self.b[y][x] == 0:
                    return True
                for dx, dy in ((1, 0), (0, 1)):
                    nx, ny = x + dx, y + dy
                    if nx < 4 and ny < 4 and self.b[ny][nx] == self.b[y][x]:
                        return True
        return False

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            keys = {
                pygame.K_LEFT: "left", pygame.K_a: "left",
                pygame.K_RIGHT: "right", pygame.K_d: "right",
                pygame.K_UP: "up", pygame.K_w: "up",
                pygame.K_DOWN: "down", pygame.K_s: "down",
                pygame.K_r: "reset",
            }
            if event.key in keys:
                if keys[event.key] == "reset":
                    self.reset()
                elif not self.over:
                    self.move(keys[event.key])
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if pygame.Rect(100, 48, 90, 36).collidepoint(event.pos):
                self.reset()
                return
            if self.over:
                self.reset()
                return
            self.touch0 = event.pos
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.touch0:
            dx = event.pos[0] - self.touch0[0]
            dy = event.pos[1] - self.touch0[1]
            if abs(dx) > 25 or abs(dy) > 25:
                if abs(dx) > abs(dy):
                    self.move("right" if dx > 0 else "left")
                else:
                    self.move("down" if dy > 0 else "up")
            self.touch0 = None

    def update(self, dt):
        pass

    def draw(self, surface):
        sw, sh = surface.get_size()
        surface.fill(BG)
        bold = self.app.font("ui", 16, bold=True)
        font = self.app.font("ui", 13)
        surface.blit(bold.render(f"2048  ·  {self.score}", True, TEXT), (100, 12))
        pygame.draw.rect(surface, (0, 120, 215), pygame.Rect(100, 48, 90, 36), border_radius=8)
        surface.blit(font.render("Заново", True, TEXT), (112, 56))
        surface.blit(font.render("свайп / WASD", True, DIM), (200, 56))
        if self.won:
            surface.blit(bold.render("2048!", True, (120, 200, 120)), (320, 54))
        if self.over:
            surface.blit(bold.render("Конец", True, (220, 80, 80)), (320, 54))

        top = 100
        size = min((sw - 40) // 4, (sh - top - 80) // 4)
        ox = (sw - size * 4) // 2
        for y in range(4):
            for x in range(4):
                v = self.b[y][x]
                r = pygame.Rect(ox + x * size + 3, top + y * size + 3, size - 6, size - 6)
                col = COLORS.get(v, EMPTY) if v else EMPTY
                pygame.draw.rect(surface, col, r, border_radius=8)
                if v:
                    t = bold.render(str(v), True, TEXT)
                    surface.blit(t, t.get_rect(center=r.center))


def create_plugin(app):
    return Game2048Plugin(app)
