#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Генератор паролей — плагин Tile Launcher."""

PLUGIN_APP = True

import random
import string
import pygame

BG = (22, 25, 32)
PANEL = (32, 38, 50)
ACCENT = (0, 120, 215)
OK = (60, 160, 100)
TEXT = (240, 245, 255)
DIM = (150, 160, 180)


class PasswordPlugin:
    title = "Пароли"

    def __init__(self, app):
        self.app = app
        self.length = 16
        self.use_digits = True
        self.use_symbols = True
        self.use_upper = True
        self.password = ""
        self.history = []
        self.generate()

    def generate(self):
        chars = string.ascii_lowercase
        pool = [random.choice(string.ascii_lowercase)]
        if self.use_upper:
            chars += string.ascii_uppercase
            pool.append(random.choice(string.ascii_uppercase))
        if self.use_digits:
            chars += string.digits
            pool.append(random.choice(string.digits))
        if self.use_symbols:
            sym = "!@#$%^&*()-_=+[]{}"
            chars += sym
            pool.append(random.choice(sym))
        length = max(4, min(64, self.length))
        while len(pool) < length:
            pool.append(random.choice(chars))
        random.shuffle(pool)
        self.password = "".join(pool[:length])
        self.history.insert(0, self.password)
        self.history = self.history[:8]

    def copy(self):
        try:
            from pathlib import Path
            p = Path("/storage/emulated/0/TileLauncher/clipboard.txt")
            try:
                p.parent.mkdir(parents=True, exist_ok=True)
            except Exception:
                p = Path(__file__).resolve().parent / "clipboard.txt"
            p.write_text(self.password, encoding="utf-8")
            try:
                import pyperclip
                pyperclip.copy(self.password)
            except Exception:
                pass
            self.app.toast("Скопировано", OK)
        except Exception as e:
            self.app.toast(str(e), (230, 90, 90))

    def handle_event(self, event):
        if event.type != pygame.MOUSEBUTTONDOWN or event.button != 1:
            return
        pos = event.pos
        w, _ = self.app.screen.get_size()
        # кнопки
        if pygame.Rect(20, 200, w - 40, 52).collidepoint(pos):
            self.generate()
            return
        if pygame.Rect(20, 262, w - 40, 48).collidepoint(pos):
            self.copy()
            return
        # опции
        opts = [
            (pygame.Rect(20, 140, 100, 40), "digits"),
            (pygame.Rect(130, 140, 100, 40), "symbols"),
            (pygame.Rect(240, 140, 100, 40), "upper"),
        ]
        for r, key in opts:
            if r.collidepoint(pos):
                if key == "digits":
                    self.use_digits = not self.use_digits
                elif key == "symbols":
                    self.use_symbols = not self.use_symbols
                elif key == "upper":
                    self.use_upper = not self.use_upper
                return
        # длина
        if pygame.Rect(20, 90, 50, 40).collidepoint(pos):
            self.length = max(4, self.length - 1)
            return
        if pygame.Rect(140, 90, 50, 40).collidepoint(pos):
            self.length = min(64, self.length + 1)
            return

    def update(self, dt):
        pass

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(BG)
        bold = self.app.font("ui", 18, bold=True)
        font = self.app.font("ui", 14)
        mono = self.app.font("mono", 18, bold=True)
        small = self.app.font("ui", 12)

        surface.blit(bold.render("Генератор паролей", True, TEXT), (100, 12))

        surface.blit(font.render(f"Длина: {self.length}", True, TEXT), (20, 60))
        pygame.draw.rect(surface, PANEL, pygame.Rect(20, 90, 50, 40), border_radius=8)
        surface.blit(bold.render("−", True, TEXT), (36, 94))
        pygame.draw.rect(surface, PANEL, pygame.Rect(140, 90, 50, 40), border_radius=8)
        surface.blit(bold.render("+", True, TEXT), (154, 94))

        def chip(rect, label, on):
            pygame.draw.rect(surface, ACCENT if on else PANEL, rect, border_radius=8)
            surface.blit(small.render(label, True, TEXT), (rect.x + 10, rect.y + 12))

        chip(pygame.Rect(20, 140, 100, 40), "Цифры", self.use_digits)
        chip(pygame.Rect(130, 140, 100, 40), "Символы", self.use_symbols)
        chip(pygame.Rect(240, 140, 100, 40), "A-Z", self.use_upper)

        pygame.draw.rect(surface, PANEL, pygame.Rect(20, 200, w - 40, 52), border_radius=12)
        surface.blit(bold.render("Сгенерировать", True, TEXT), (w // 2 - 80, 212))
        pygame.draw.rect(surface, OK, pygame.Rect(20, 262, w - 40, 48), border_radius=12)
        surface.blit(font.render("Копировать", True, TEXT), (w // 2 - 50, 274))

        pygame.draw.rect(surface, PANEL, pygame.Rect(20, 330, w - 40, 70), border_radius=12)
        pwd = self.password
        if len(pwd) > 28:
            pwd = pwd[:27] + "…"
        ts = mono.render(pwd, True, OK)
        surface.blit(ts, ts.get_rect(center=(w // 2, 365)))

        surface.blit(font.render("История:", True, DIM), (20, 420))
        y = 448
        for item in self.history[1:6]:
            surface.blit(small.render(item[:40], True, DIM), (20, y))
            y += 22


def create_plugin(app):
    return PasswordPlugin(app)
