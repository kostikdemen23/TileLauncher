#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""QR / текст — плагин Tile Launcher."""

PLUGIN_APP = True

import urllib.parse
import pygame

BG = (22, 25, 32)
PANEL = (32, 38, 50)
ACCENT = (0, 120, 215)
TEXT = (240, 245, 255)
DIM = (150, 160, 180)
OK = (60, 160, 100)


class QRPlugin:
    title = "QR"

    def __init__(self, app):
        self.app = app
        self.text = ""
        self.matrix = None
        self.online_url = ""
        self.status = "Введите текст → QR"
        self.scroll = 0

    def build(self):
        text = self.text.strip()
        if not text:
            self.matrix = None
            self.online_url = ""
            self.status = "Пусто"
            return
        self.online_url = (
            "https://api.qrserver.com/v1/create-qr-code/?size=220x220&data="
            + urllib.parse.quote(text[:500])
        )
        self.matrix = None
        try:
            import qrcode
            qr = qrcode.QRCode(border=1, box_size=6)
            qr.add_data(text)
            qr.make(fit=True)
            self.matrix = qr.get_matrix()
            self.status = "QR готов"
        except Exception:
            self.status = "Нет qrcode — показана ссылка / ASCII"
            # простой fallback: не настоящий QR, а сетка-хеш для вида
            self.matrix = self._pseudo_matrix(text)

    def _pseudo_matrix(self, text: str):
        """Визуальная заглушка, если нет библиотеки qrcode."""
        n = 21
        m = [[False] * n for _ in range(n)]
        h = abs(hash(text))
        for y in range(n):
            for x in range(n):
                # finder-like corners
                if (x < 7 and y < 7) or (x >= n - 7 and y < 7) or (x < 7 and y >= n - 7):
                    edge = x in (0, 6) or y in (0, 6) or (2 <= x <= 4 and 2 <= y <= 4)
                    if x >= n - 7:
                        xx = x - (n - 7)
                        edge = xx in (0, 6) or y in (0, 6) or (2 <= xx <= 4 and 2 <= y <= 4)
                    if y >= n - 7:
                        yy = y - (n - 7)
                        edge = x in (0, 6) or yy in (0, 6) or (2 <= x <= 4 and 2 <= yy <= 4)
                    m[y][x] = bool(edge)
                else:
                    m[y][x] = bool((h >> ((x + y * 3) % 30)) & 1)
        return m

    def copy_link(self):
        if not self.online_url:
            self.app.toast("Сначала создайте QR", (230, 90, 90))
            return
        try:
            from pathlib import Path
            p = Path("/storage/emulated/0/TileLauncher/clipboard.txt")
            try:
                p.parent.mkdir(parents=True, exist_ok=True)
            except Exception:
                p = Path(__file__).resolve().parent / "clipboard.txt"
            p.write_text(self.online_url, encoding="utf-8")
            try:
                import pyperclip
                pyperclip.copy(self.online_url)
            except Exception:
                pass
            self.app.toast("Ссылка скопирована", OK)
        except Exception as e:
            self.app.toast(str(e), (230, 90, 90))

    def apply_text_input(self, text: str):
        self.text += text

    def handle_event(self, event):
        w, h = self.app.screen.get_size()
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if pygame.Rect(10, 48, w - 20, 42).collidepoint(event.pos):
                self.app.set_text_focus(self)
                return
            if pygame.Rect(20, 100, (w - 50) // 2, 44).collidepoint(event.pos):
                self.build()
                return
            if pygame.Rect(30 + (w - 50) // 2, 100, (w - 50) // 2, 44).collidepoint(event.pos):
                self.copy_link()
                return
            if pygame.Rect(20, 152, w - 40, 40).collidepoint(event.pos):
                self.text = ""
                self.matrix = None
                self.status = "Очищено"
                return
        elif event.type == pygame.KEYDOWN:
            if event.key == pygame.K_BACKSPACE:
                self.text = self.text[:-1]
            elif event.key == pygame.K_RETURN:
                self.build()
            elif event.unicode and event.unicode.isprintable():
                self.text += event.unicode

    def update(self, dt):
        pass

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(BG)
        bold = self.app.font("ui", 16, bold=True)
        font = self.app.font("ui", 14)
        small = self.app.font("ui", 12)

        surface.blit(bold.render("QR / текст", True, TEXT), (100, 12))

        box = pygame.Rect(10, 48, w - 20, 42)
        pygame.draw.rect(surface, PANEL, box, border_radius=8)
        pygame.draw.rect(surface, ACCENT, box, 1, border_radius=8)
        shown = self.text if self.text else "введите текст или URL…"
        surface.blit(font.render(shown[:48], True, TEXT if self.text else DIM),
                     (box.x + 12, box.y + 10))

        bw = (w - 50) // 2
        pygame.draw.rect(surface, ACCENT, pygame.Rect(20, 100, bw, 44), border_radius=10)
        surface.blit(font.render("Создать QR", True, TEXT), (40, 112))
        pygame.draw.rect(surface, OK, pygame.Rect(30 + bw, 100, bw, 44), border_radius=10)
        surface.blit(font.render("Копир. ссылку", True, TEXT), (40 + bw, 112))
        pygame.draw.rect(surface, PANEL, pygame.Rect(20, 152, w - 40, 40), border_radius=10)
        surface.blit(font.render("Очистить", True, TEXT), (w // 2 - 40, 162))

        surface.blit(small.render(self.status, True, DIM), (20, 205))

        if self.matrix:
            n = len(self.matrix)
            max_side = min(w - 40, h - 280)
            cell = max(2, max_side // n)
            side = cell * n
            ox = (w - side) // 2
            oy = 230
            pygame.draw.rect(surface, (255, 255, 255),
                             pygame.Rect(ox - 6, oy - 6, side + 12, side + 12),
                             border_radius=6)
            for y, row in enumerate(self.matrix):
                for x, on in enumerate(row):
                    if on:
                        pygame.draw.rect(
                            surface, (0, 0, 0),
                            pygame.Rect(ox + x * cell, oy + y * cell, cell, cell))
        elif self.online_url:
            surface.blit(small.render("Онлайн-QR (открой в браузере):", True, DIM),
                         (20, 240))
            # wrap url
            url = self.online_url
            y = 262
            while url and y < h - 80:
                surface.blit(small.render(url[:50], True, ACCENT), (20, y))
                url = url[50:]
                y += 18


def create_plugin(app):
    return QRPlugin(app)
