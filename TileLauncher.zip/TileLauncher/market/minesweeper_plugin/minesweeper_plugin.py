#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Сапёр — плагин Tile Launcher."""

PLUGIN_APP = True

import random
import pygame

W, H, MINES = 8, 8, 10
BG = (22, 25, 32)
CELL_BG = (40, 48, 62)
OPEN_BG = (30, 36, 48)
TEXT = (240, 245, 255)
DIM = (150, 160, 180)
MINE = (220, 80, 80)
FLAG = (240, 190, 80)
ACCENT = (0, 120, 215)


class MinesPlugin:
    title = "Сапёр"

    def __init__(self, app):
        self.app = app
        self.reset()

    def reset(self):
        self.board = [[0] * W for _ in range(H)]
        places = random.sample([(x, y) for x in range(W) for y in range(H)], MINES)
        for x, y in places:
            self.board[y][x] = -1
        for y in range(H):
            for x in range(W):
                if self.board[y][x] == -1:
                    continue
                n = sum(
                    1 for dy in (-1, 0, 1) for dx in (-1, 0, 1)
                    if 0 <= x + dx < W and 0 <= y + dy < H
                    and self.board[y + dy][x + dx] == -1
                )
                self.board[y][x] = n
        self.opened = [[False] * W for _ in range(H)]
        self.flags = set()
        self.dead = False
        self.won = False
        self.mode_flag = False

    def flood(self, x, y):
        stack = [(x, y)]
        while stack:
            cx, cy = stack.pop()
            if not (0 <= cx < W and 0 <= cy < H) or self.opened[cy][cx]:
                continue
            self.opened[cy][cx] = True
            if self.board[cy][cx] != 0:
                continue
            for dy in (-1, 0, 1):
                for dx in (-1, 0, 1):
                    stack.append((cx + dx, cy + dy))

    def check_win(self):
        for y in range(H):
            for x in range(W):
                if self.board[y][x] != -1 and not self.opened[y][x]:
                    return False
        return True

    def cell_rect(self, surface):
        sw, sh = surface.get_size()
        top = 100
        size = min((sw - 20) // W, (sh - top - 80) // H)
        ox = (sw - size * W) // 2
        return ox, top, size

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            pos = event.pos
            sw, sh = self.app.screen.get_size()
            # кнопки
            if pygame.Rect(100, 48, 90, 36).collidepoint(pos):
                self.reset()
                return
            if pygame.Rect(200, 48, 120, 36).collidepoint(pos):
                self.mode_flag = not self.mode_flag
                return
            if self.dead or self.won:
                return
            ox, top, size = self.cell_rect(self.app.screen)
            if size <= 0:
                return
            cx = (pos[0] - ox) // size
            cy = (pos[1] - top) // size
            if not (0 <= cx < W and 0 <= cy < H):
                return
            if self.mode_flag:
                if (cx, cy) in self.flags:
                    self.flags.discard((cx, cy))
                elif not self.opened[cy][cx]:
                    self.flags.add((cx, cy))
                return
            if (cx, cy) in self.flags:
                return
            if self.board[cy][cx] == -1:
                self.opened[cy][cx] = True
                self.dead = True
            else:
                self.flood(cx, cy)
                self.won = self.check_win()

    def update(self, dt):
        pass

    def draw(self, surface):
        sw, sh = surface.get_size()
        surface.fill(BG)
        bold = self.app.font("ui", 16, bold=True)
        font = self.app.font("ui", 13)
        surface.blit(bold.render("Сапёр 8×8", True, TEXT), (100, 12))
        pygame.draw.rect(surface, ACCENT, pygame.Rect(100, 48, 90, 36), border_radius=8)
        surface.blit(font.render("Заново", True, TEXT), (112, 56))
        col = FLAG if self.mode_flag else (70, 80, 100)
        pygame.draw.rect(surface, col, pygame.Rect(200, 48, 120, 36), border_radius=8)
        surface.blit(font.render("Флаг: " + ("ВКЛ" if self.mode_flag else "выкл"),
                                 True, TEXT), (210, 56))
        if self.dead:
            surface.blit(bold.render("Проигрыш", True, MINE), (330, 54))
        elif self.won:
            surface.blit(bold.render("Победа!", True, (90, 200, 120)), (330, 54))

        ox, top, size = self.cell_rect(surface)
        for y in range(H):
            for x in range(W):
                r = pygame.Rect(ox + x * size, top + y * size, size - 2, size - 2)
                if (x, y) in self.flags and not self.opened[y][x]:
                    pygame.draw.rect(surface, CELL_BG, r, border_radius=4)
                    surface.blit(bold.render("F", True, FLAG), r.move(size // 3, size // 4))
                elif not self.opened[y][x] and not (self.dead and self.board[y][x] == -1):
                    pygame.draw.rect(surface, CELL_BG, r, border_radius=4)
                else:
                    pygame.draw.rect(surface, OPEN_BG, r, border_radius=4)
                    v = self.board[y][x]
                    if v == -1:
                        pygame.draw.circle(surface, MINE, r.center, max(4, size // 4))
                    elif v > 0:
                        surface.blit(bold.render(str(v), True, TEXT),
                                     bold.render(str(v), True, TEXT).get_rect(center=r.center))


def create_plugin(app):
    return MinesPlugin(app)
