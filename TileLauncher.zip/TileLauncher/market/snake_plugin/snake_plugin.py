#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Змейка — плагин Tile Launcher (оптимизировано)."""

PLUGIN_APP = True

import random
import pygame

COLS, ROWS = 14, 16
BG = (18, 20, 28)
SNAKE = (60, 180, 90)
HEAD = (90, 220, 120)
FOOD = (220, 80, 80)
TEXT = (240, 245, 255)
DIM = (150, 160, 180)


class SnakePlugin:
    title = "Змейка"

    def __init__(self, app):
        self.app = app
        self.reset()
        self.acc = 0.0
        self.step_t = 0.12  # быстрее и ровнее
        self._grid = None
        self._grid_key = None

    def reset(self):
        cx, cy = COLS // 2, ROWS // 2
        self.snake = [(cx, cy), (cx - 1, cy), (cx - 2, cy)]
        self.dir = (1, 0)
        self.next_dir = (1, 0)
        self.food = self._spawn()
        self.score = 0
        self.alive = True
        self.touch0 = None
        self.step_t = 0.12

    def _spawn(self):
        occupied = set(self.snake)
        free = [(x, y) for x in range(COLS) for y in range(ROWS)
                if (x, y) not in occupied]
        return random.choice(free) if free else (0, 0)

    def turn(self, dx, dy):
        if (dx, dy) == (-self.dir[0], -self.dir[1]):
            return
        self.next_dir = (dx, dy)

    def step(self):
        if not self.alive:
            return
        self.dir = self.next_dir
        hx, hy = self.snake[0]
        nx, ny = hx + self.dir[0], hy + self.dir[1]
        if nx < 0 or ny < 0 or nx >= COLS or ny >= ROWS or (nx, ny) in self.snake:
            self.alive = False
            return
        self.snake.insert(0, (nx, ny))
        if (nx, ny) == self.food:
            self.score += 1
            if self.step_t > 0.07:
                self.step_t = max(0.07, self.step_t - 0.004)
            self.food = self._spawn()
        else:
            self.snake.pop()

    def handle_event(self, event):
        if event.type == pygame.KEYDOWN:
            m = {
                pygame.K_UP: (0, -1), pygame.K_w: (0, -1),
                pygame.K_DOWN: (0, 1), pygame.K_s: (0, 1),
                pygame.K_LEFT: (-1, 0), pygame.K_a: (-1, 0),
                pygame.K_RIGHT: (1, 0), pygame.K_d: (1, 0),
                pygame.K_r: "reset",
            }
            if event.key in m:
                if m[event.key] == "reset":
                    self.reset()
                else:
                    self.turn(*m[event.key])
        elif event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            if not self.alive:
                self.reset()
            else:
                self.touch0 = event.pos
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1 and self.touch0:
            dx = event.pos[0] - self.touch0[0]
            dy = event.pos[1] - self.touch0[1]
            if abs(dx) > 18 or abs(dy) > 18:
                if abs(dx) > abs(dy):
                    self.turn(1 if dx > 0 else -1, 0)
                else:
                    self.turn(0, 1 if dy > 0 else -1)
            self.touch0 = None

    def update(self, dt):
        # фиксированный шаг: не копить лаг
        self.acc += min(dt, 0.05)
        while self.acc >= self.step_t:
            self.acc -= self.step_t
            self.step()

    def _ensure_grid(self, ox, top, cell, sw):
        key = (ox, top, cell, COLS, ROWS)
        if self._grid is not None and self._grid_key == key:
            return
        self._grid_key = key
        surf = pygame.Surface((cell * COLS, cell * ROWS))
        surf.fill(BG)
        # лёгкая сетка — только линии, реже
        line = (32, 36, 46)
        for x in range(0, COLS + 1):
            pygame.draw.line(surf, line, (x * cell, 0), (x * cell, cell * ROWS))
        for y in range(0, ROWS + 1):
            pygame.draw.line(surf, line, (0, y * cell), (cell * COLS, y * cell))
        self._grid = surf

    def draw(self, surface):
        sw, sh = surface.get_size()
        surface.fill(BG)
        bold = self.app.font("ui", 16, bold=True)
        font = self.app.font("ui", 13)
        surface.blit(bold.render(f"Змейка  ·  {self.score}", True, TEXT), (100, 12))
        surface.blit(font.render("свайп · тап = рестарт", True, DIM), (100, 36))

        top = 70
        cell = min((sw - 16) // COLS, (sh - top - 70) // ROWS)
        if cell < 8:
            cell = 8
        ox = (sw - cell * COLS) // 2
        self._ensure_grid(ox, top, cell, sw)
        surface.blit(self._grid, (ox, top))

        fx, fy = self.food
        pad = max(1, cell // 6)
        pygame.draw.rect(
            surface, FOOD,
            pygame.Rect(ox + fx * cell + pad, top + fy * cell + pad,
                        cell - 2 * pad, cell - 2 * pad),
            border_radius=3)
        for i, (x, y) in enumerate(self.snake):
            col = HEAD if i == 0 else SNAKE
            pygame.draw.rect(
                surface, col,
                pygame.Rect(ox + x * cell + 1, top + y * cell + 1,
                            cell - 2, cell - 2),
                border_radius=3)
        if not self.alive:
            msg = bold.render("Game Over — тап", True, FOOD)
            surface.blit(msg, msg.get_rect(center=(sw // 2, 52)))


def create_plugin(app):
    return SnakePlugin(app)
