#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Погода в стиле ColorOS 5 — плагин Tile Launcher.
Крупная температура, мягкий градиент, карточки, час/7 дней.
"""

PLUGIN_APP = True

import json
import threading
import urllib.parse
import urllib.request
from datetime import date, datetime
from pathlib import Path

import pygame

# --- палитра «ColorOS weather» ---
TEXT = (255, 255, 255)
TEXT2 = (230, 240, 255)
DIM = (200, 220, 240)
CARD_A = 55  # альфа карточек

CFG_PATHS = [
    Path("/storage/emulated/0/TileLauncher/market/weather/weather_cfg.json"),
    Path("/storage/emulated/0/TileLauncher/weather_cfg.json"),
    Path(__file__).resolve().parent / "weather_cfg.json",
]

# файл иконки рядом с плагином: weather_icons/
WMO_FILE = {
    0: "sun.jpg",
    1: "partly.jpg",
    2: "clouds.jpg",
    3: "cloud.jpg",
    45: "fog.jpg",
    48: "fog.jpg",
    51: "sun_rain.jpg",
    53: "rain.jpg",
    55: "rain_heavy.jpg",
    61: "rain.jpg",
    63: "rain_heavy.jpg",
    65: "rain_clouds.jpg",
    71: "snow.jpg",
    73: "snow.jpg",
    75: "snow.jpg",
    80: "sun_rain.jpg",
    81: "rain.jpg",
    82: "rain_heavy.jpg",
    95: "thunder.jpg",
    96: "thunder.jpg",
    99: "thunder.jpg",
}

WMO_RU = {
    0: "Ясно", 1: "Преим. ясно", 2: "Облачно", 3: "Пасмурно",
    45: "Туман", 48: "Изморозь",
    51: "Морось", 53: "Морось", 55: "Морось",
    61: "Дождь", 63: "Дождь", 65: "Ливень",
    71: "Снег", 73: "Снег", 75: "Снег",
    80: "Ливень", 81: "Ливень", 82: "Сильный ливень",
    95: "Гроза", 96: "Гроза", 99: "Гроза",
}

WEEK_RU = ["Пн", "Вт", "Ср", "Чт", "Пт", "Сб", "Вс"]

_ICON_CACHE = {}


def _icon_dirs():
    here = Path(__file__).resolve().parent
    return [
        here / "weather_icons",
        here / "icons",
        Path("/storage/emulated/0/TileLauncher/market/weather/weather_icons"),
        Path("/storage/emulated/0/TileLauncher/weather_icons"),
        Path("/storage/emulated/0/TileLauncher/market/weather_icons"),
    ]


def wmo_text(code):
    try:
        return WMO_RU.get(int(code), "—")
    except Exception:
        return "—"


def wmo_icon(code):
    try:
        return WMO_ICON.get(int(code), "•")
    except Exception:
        return "•"


def wmo_icon_key(code, is_day=1):
    try:
        c = int(code)
    except Exception:
        c = 0
    if c == 0 and not is_day:
        return "moon.jpg"
    if c in (1, 2) and not is_day:
        return "cloud.jpg"
    return WMO_FILE.get(c, "cloud.jpg")


def load_weather_icon(code, size=64, is_day=1):
    """Загружает JPG-иконку, кэширует scaled Surface."""
    key = (int(code) if str(code).isdigit() else 0, size, int(is_day))
    if key in _ICON_CACHE:
        return _ICON_CACHE[key]
    fname = wmo_icon_key(code, is_day)
    path = None
    for d in _icon_dirs():
        cand = d / fname
        if cand.exists():
            path = cand
            break
        # без расширения
        for alt in d.glob(fname.split(".")[0] + ".*"):
            path = alt
            break
        if path:
            break
    if path is None:
        _ICON_CACHE[key] = None
        return None
    try:
        img = pygame.image.load(str(path)).convert_alpha()
    except Exception:
        try:
            img = pygame.image.load(str(path)).convert()
        except Exception:
            _ICON_CACHE[key] = None
            return None
    try:
        img = pygame.transform.smoothscale(img, (size, size))
    except Exception:
        img = pygame.transform.scale(img, (size, size))
    _ICON_CACHE[key] = img
    return img


def blit_weather_icon(surface, code, pos, size=64, is_day=1, font=None):
    """Рисует картинку или emoji-fallback."""
    ic = load_weather_icon(code, size, is_day)
    if ic is not None:
        surface.blit(ic, pos)
        return size
    if font is not None:
        s = font.render(wmo_icon(code), True, TEXT)
        surface.blit(s, pos)
        return s.get_width()
    return 0


def sky_colors(code, is_day=1):
    """Градиент фона как в ColorOS — под погоду."""
    try:
        c = int(code)
    except Exception:
        c = 0
    if not is_day:
        return (18, 28, 55), (8, 12, 28)
    if c == 0:
        return (70, 150, 230), (40, 110, 200)
    if c in (1, 2):
        return (90, 150, 210), (55, 100, 170)
    if c == 3:
        return (110, 130, 155), (70, 85, 110)
    if c in (45, 48):
        return (120, 135, 150), (80, 90, 105)
    if c in (51, 53, 55, 61, 63, 80, 81):
        return (75, 105, 145), (45, 65, 100)
    if c in (65, 82, 95, 96, 99):
        return (55, 70, 100), (30, 40, 65)
    if c in (71, 73, 75, 85, 86):
        return (150, 175, 200), (100, 130, 165)
    return (70, 140, 210), (40, 100, 180)


def wind_dir(deg):
    try:
        deg = float(deg) % 360
    except Exception:
        return ""
    names = ["С", "СВ", "В", "ЮВ", "Ю", "ЮЗ", "З", "СЗ"]
    return names[int((deg + 22.5) / 45) % 8]


def pick_geo_result(results, prefer_country=None, prefer_admin=None):
    """Выбор города: сначала совпадение страны (KZ), иначе первый."""
    if not results:
        return None
    pref = (prefer_country or "").strip().lower()
    # Казахстан по умолчанию, если не указано иное и есть вариант KZ
    codes_kz = ("kz", "kazakhstan", "казахстан")
    admin_pref = (prefer_admin or "").strip().lower()

    def score(g):
        s = 0
        cc = (g.get("country_code") or "").lower()
        cname = (g.get("country") or "").lower()
        admin = (g.get("admin1") or "").lower()
        if pref:
            if cc == pref or pref in cname:
                s += 100
        else:
            if cc == "kz" or any(x in cname for x in codes_kz):
                s += 50  # лёгкий приоритет KZ для неоднозначных имён
        if admin_pref and admin_pref in admin:
            s += 30
        # население — крупнее чуть предпочтительнее только как tie-break
        try:
            s += min(10, int(g.get("population") or 0) // 50000)
        except Exception:
            pass
        return s

    ranked = sorted(results, key=score, reverse=True)
    return ranked[0]



def get_gps_location(timeout_sec=8.0):
    """Попытка GPS через Android (jnius). (lat, lon) или None."""
    try:
        from jnius import autoclass
        from time import time, sleep
        Loop = autoclass("android.os.Looper")
        if Loop.myLooper() is None:
            try:
                Loop.prepare()
            except Exception:
                pass
        Context = autoclass("android.content.Context")
        LocationManager = autoclass("android.location.LocationManager")
        # activity
        activity = None
        for name in (
            "org.libsdl.app.SDLActivity",
            "org.kivy.android.PythonActivity",
            "org.renpy.android.PythonActivity",
        ):
            try:
                cls = autoclass(name)
                activity = getattr(cls, "mSingleton", None) or getattr(cls, "mActivity", None)
                if activity is not None:
                    break
            except Exception:
                continue
        if activity is None:
            return None
        lm = activity.getSystemService(Context.LOCATION_SERVICE)
        providers = []
        try:
            if lm.isProviderEnabled(LocationManager.GPS_PROVIDER):
                providers.append(LocationManager.GPS_PROVIDER)
        except Exception:
            pass
        try:
            if lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER):
                providers.append(LocationManager.NETWORK_PROVIDER)
        except Exception:
            pass
        if not providers:
            providers = [LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER]
        # last known
        best = None
        for prov in providers:
            try:
                loc = lm.getLastKnownLocation(prov)
                if loc is not None:
                    if best is None or loc.getTime() > best.getTime():
                        best = loc
            except Exception:
                continue
        if best is not None:
            return float(best.getLatitude()), float(best.getLongitude())
    except Exception:
        return None
    return None


def get_ip_location():
    """Грубое местоположение по IP (если GPS недоступен)."""
    urls = (
        "https://ipapi.co/json/",
        "http://ip-api.com/json/?fields=status,lat,lon,city,regionName,country",
    )
    for url in urls:
        try:
            with urllib.request.urlopen(url, timeout=8) as r:
                data = json.loads(r.read().decode())
            if "latitude" in data and "longitude" in data:
                return (
                    float(data["latitude"]),
                    float(data["longitude"]),
                    str(data.get("city") or ""),
                    str(data.get("region") or data.get("regionName") or ""),
                    str(data.get("country_name") or data.get("country") or ""),
                )
            if data.get("status") == "success" or ("lat" in data and "lon" in data):
                return (
                    float(data["lat"]),
                    float(data["lon"]),
                    str(data.get("city") or ""),
                    str(data.get("regionName") or data.get("region") or ""),
                    str(data.get("country") or ""),
                )
        except Exception:
            continue
    return None


def reverse_geocode(lat, lon):
    """Название места по координатам (Open-Meteo)."""
    try:
        url = (
            "https://geocoding-api.open-meteo.com/v1/reverse"
            f"?latitude={lat}&longitude={lon}&language=ru&format=json"
        )
        with urllib.request.urlopen(url, timeout=10) as r:
            data = json.loads(r.read().decode())
        results = data.get("results") or []
        if results:
            g = results[0]
            return {
                "name": g.get("name") or "Моё место",
                "country": g.get("country") or "",
                "country_code": g.get("country_code") or "",
                "admin1": g.get("admin1") or "",
                "lat": lat,
                "lon": lon,
                "timezone": g.get("timezone") or "auto",
            }
    except Exception:
        pass
    return {
        "name": "Моё место",
        "country": "",
        "country_code": "",
        "admin1": "",
        "lat": lat,
        "lon": lon,
        "timezone": "auto",
    }


class WeatherPlugin:
    title = "Погода"

    def __init__(self, app):
        self.app = app
        self.city_input = ""
        self.editing = False
        self.loading = False
        self.error = None
        self.data = None
        self.place = ""
        self.places = []  # [{city, name, lat, lon, timezone}, ...]
        self.place_i = 0
        self.place_rects = []
        self.scroll = 0
        self.max_scroll = 0
        self.drag_y = None
        self.drag_scroll = 0
        self.hour_scroll = 0
        self.hour_max = 0
        self.hour_rect = None
        self.drag_hour = False
        self.drag_x0 = 0
        self.drag_hour_scroll = 0
        self._bg = None
        self._bg_key = None
        self._load_saved()

    # ---------- config ----------
    def _cfg_path(self) -> Path:
        for p in CFG_PATHS:
            try:
                p.parent.mkdir(parents=True, exist_ok=True)
                return p
            except Exception:
                continue
        return Path(__file__).resolve().parent / "weather_cfg.json"

    def _load_saved(self):
        for p in CFG_PATHS:
            try:
                if not p.exists():
                    continue
                cfg = json.loads(p.read_text(encoding="utf-8"))
                places = cfg.get("places")
                if isinstance(places, list) and places:
                    self.places = places
                    self.place_i = int(cfg.get("place_i") or 0) % len(self.places)
                    cur = self.places[self.place_i]
                    self.city_input = str(cur.get("name") or cur.get("city") or "")
                else:
                    name = str(cfg.get("city") or cfg.get("name") or "")
                    self.city_input = name
                    if name:
                        self.places = [{
                            "city": name,
                            "name": cfg.get("name") or name,
                            "lat": cfg.get("lat"),
                            "lon": cfg.get("lon"),
                            "timezone": cfg.get("timezone", "auto"),
                        }]
                return
            except Exception:
                continue

    def _save(self, city, info):
        try:
            entry = {
                "city": city,
                "name": info.get("name") or city,
                "lat": info["lat"],
                "lon": info["lon"],
                "timezone": info.get("timezone", "auto"),
                "country": info.get("country") or "",
                "country_code": info.get("country_code") or "",
                "admin1": info.get("admin1") or "",
            }
            # обновить или добавить место
            key = (round(float(info["lat"]), 3), round(float(info["lon"]), 3))
            found = False
            for i, pl in enumerate(self.places):
                try:
                    k2 = (round(float(pl.get("lat") or 0), 3),
                          round(float(pl.get("lon") or 0), 3))
                except Exception:
                    k2 = None
                if k2 == key or str(pl.get("name")) == entry["name"]:
                    self.places[i] = entry
                    self.place_i = i
                    found = True
                    break
            if not found:
                self.places.append(entry)
                self.place_i = len(self.places) - 1
            path = self._cfg_path()
            path.write_text(json.dumps({
                "city": entry["name"],
                "name": entry["name"],
                "lat": entry["lat"],
                "lon": entry["lon"],
                "timezone": entry["timezone"],
                "places": self.places,
                "place_i": self.place_i,
            }, ensure_ascii=False, indent=2), encoding="utf-8")
        except Exception:
            pass

    def _city(self) -> str:
        if self.city_input.strip():
            return self.city_input.strip()
        return "Almaty"

    def locate_here(self):
        """Определить место по GPS / сети и показать погоду."""
        self.loading = True
        self.error = None
        self.scroll = 0

        def work():
            try:
                lat = lon = None
                gps = get_gps_location()
                if gps:
                    lat, lon = gps
                meta = None
                if lat is None:
                    ip = get_ip_location()
                    if ip:
                        lat, lon = ip[0], ip[1]
                        meta = {
                            "name": ip[2] or "Моё место",
                            "admin1": ip[3],
                            "country": ip[4],
                            "country_code": "",
                            "lat": lat,
                            "lon": lon,
                            "timezone": "auto",
                        }
                if lat is None or lon is None:
                    self.error = "Не удалось определить место (GPS/сеть)"
                    self.loading = False
                    return
                info = reverse_geocode(lat, lon)
                if meta and not info.get("name"):
                    info.update({k: meta[k] for k in meta if meta.get(k)})
                if meta and info.get("name") in ("", "Моё место") and meta.get("name"):
                    info["name"] = meta["name"]
                    info["admin1"] = meta.get("admin1") or info.get("admin1")
                    info["country"] = meta.get("country") or info.get("country")
                self._save(info.get("name") or "Моё место", info)
                # погода по координатам
                self.fetch(info.get("name") or "Моё место", use_place=info)
            except Exception as e:
                self.error = str(e)
                self.loading = False

        threading.Thread(target=work, daemon=True).start()

    # ---------- network ----------
    def fetch(self, city: str = None, use_place=None):
        city = (city or self._city()).strip() or "Almaty"
        self.loading = True
        self.error = None
        self.scroll = 0

        def work():
            try:
                info = None
                # 1) явные координаты места
                if use_place and use_place.get("lat") is not None                         and use_place.get("lon") is not None:
                    info = {
                        "name": use_place.get("name") or use_place.get("city") or city,
                        "country": use_place.get("country") or "",
                        "admin1": use_place.get("admin1") or "",
                        "lat": use_place["lat"],
                        "lon": use_place["lon"],
                        "timezone": use_place.get("timezone") or "auto",
                    }
                # 2) то же имя уже сохранено с lat/lon — не ищем заново
                if info is None and self.places:
                    for pl in self.places:
                        nm = str(pl.get("name") or pl.get("city") or "").lower()
                        if nm == city.lower() and pl.get("lat") is not None                                 and pl.get("lon") is not None:
                            info = {
                                "name": pl.get("name") or pl.get("city") or city,
                                "country": pl.get("country") or "",
                                "admin1": pl.get("admin1") or "",
                                "lat": pl["lat"],
                                "lon": pl["lon"],
                                "timezone": pl.get("timezone") or "auto",
                            }
                            break
                # 3) геокодер: несколько результатов, приоритет Казахстан
                if info is None:
                    q = urllib.parse.quote(city)
                    geo_url = (
                        "https://geocoding-api.open-meteo.com/v1/search"
                        f"?name={q}&count=10&language=ru&format=json"
                    )
                    with urllib.request.urlopen(geo_url, timeout=12) as r:
                        geo = json.loads(r.read().decode())
                    results = geo.get("results") or []
                    if not results:
                        self.error = "Город не найден"
                        self.loading = False
                        return
                    # если среди сохранённых уже есть страна — предпочитаем её
                    prefer = None
                    for pl in self.places:
                        cc = (pl.get("country_code") or pl.get("country") or "")
                        if cc:
                            prefer = str(cc)
                            break
                    g = pick_geo_result(results, prefer_country=prefer or "KZ")
                    info = {
                        "name": g.get("name"),
                        "country": g.get("country", ""),
                        "country_code": g.get("country_code", ""),
                        "admin1": g.get("admin1", ""),
                        "lat": g["latitude"],
                        "lon": g["longitude"],
                        "timezone": g.get("timezone", "auto"),
                    }
                self._save(city, info)

                params = urllib.parse.urlencode({
                    "latitude": info["lat"],
                    "longitude": info["lon"],
                    "current": ",".join([
                        "temperature_2m", "relative_humidity_2m",
                        "apparent_temperature", "is_day", "weather_code",
                        "cloud_cover", "pressure_msl",
                        "wind_speed_10m", "wind_direction_10m", "wind_gusts_10m",
                        "precipitation",
                    ]),
                    "hourly": ",".join([
                        "temperature_2m", "weather_code",
                        "precipitation_probability", "wind_speed_10m",
                    ]),
                    "daily": ",".join([
                        "weather_code", "temperature_2m_max", "temperature_2m_min",
                        "sunrise", "sunset", "precipitation_sum",
                        "precipitation_probability_max", "uv_index_max",
                        "wind_speed_10m_max",
                        "relative_humidity_2m_max", "relative_humidity_2m_min",
                        "rain_sum", "showers_sum", "snowfall_sum",
                    ]),
                    "timezone": info["timezone"],
                    "forecast_days": 7,
                    "forecast_hours": 24,
                })
                with urllib.request.urlopen(
                        "https://api.open-meteo.com/v1/forecast?" + params,
                        timeout=14) as r:
                    self.data = json.loads(r.read().decode())

                place = info["name"]
                if info.get("admin1"):
                    place += f", {info['admin1']}"
                if info.get("country"):
                    place += f", {info['country']}"
                self.place = place
                self.city_input = info["name"] or city
                self.error = None
            except Exception as e:
                self.error = str(e)
            self.loading = False

        threading.Thread(target=work, daemon=True).start()

    # ---------- input ----------
    def apply_text_input(self, text: str):
        if self.editing:
            self.city_input += text

    def insert(self, ch: str):
        if self.editing:
            self.city_input += ch

    def backspace(self):
        if self.editing and self.city_input:
            self.city_input = self.city_input[:-1]

    def submit(self):
        self.editing = False
        try:
            self.app.clear_text_focus()
        except Exception:
            pass
        self.fetch()

    def handle_event(self, event):
        w, h = self.app.screen.get_size()
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            search = pygame.Rect(16, 44, w - 156, 40)
            go = pygame.Rect(w - 132, 44, 56, 40)
            gps_btn = pygame.Rect(w - 70, 44, 54, 40)
            if search.collidepoint(event.pos):
                self.editing = True
                try:
                    # фокус на host — надёжнее для VK
                    host = self.app.screens.get("plugin")
                    self.app.set_text_focus(host if host is not None else self)
                except Exception:
                    try:
                        self.app.set_text_focus(self)
                    except Exception:
                        pass
                return
            if go.collidepoint(event.pos):
                self.editing = False
                try:
                    self.app.clear_text_focus()
                except Exception:
                    pass
                self.fetch()
                return
            if gps_btn.collidepoint(event.pos):
                self.editing = False
                try:
                    self.app.clear_text_focus()
                except Exception:
                    pass
                self.locate_here()
                return
            # переключение сохранённых мест
            for r, idx in self.place_rects:
                if r.collidepoint(event.pos):
                    if idx == -1:
                        # добавить: фокус в поиск
                        self.editing = True
                        self.city_input = ""
                        try:
                            host = self.app.screens.get("plugin")
                            self.app.set_text_focus(host if host is not None else self)
                        except Exception:
                            try:
                                self.app.set_text_focus(self)
                            except Exception:
                                pass
                        return
                    if 0 <= idx < len(self.places):
                        self.place_i = idx
                        pl = self.places[idx]
                        self.city_input = str(pl.get("name") or pl.get("city") or "")
                        self.fetch(self.city_input, use_place=pl)
                    return
            self.editing = False
            try:
                self.app.clear_text_focus()
            except Exception:
                pass
            # горизонтальный свайп по ленте «по часам»
            if self.hour_rect and self.hour_rect.collidepoint(event.pos):
                self.drag_hour = True
                self.drag_x0 = event.pos[0]
                self.drag_hour_scroll = self.hour_scroll
                self.drag_y = None
                return
            self.drag_hour = False
            self.drag_y = event.pos[1]
            self.drag_scroll = self.scroll
        elif event.type == pygame.MOUSEBUTTONUP and event.button == 1:
            self.drag_y = None
            self.drag_hour = False
        elif event.type == pygame.MOUSEMOTION:
            if self.drag_hour:
                dx = self.drag_x0 - event.pos[0]
                self.hour_scroll = max(0, min(self.hour_max,
                                              self.drag_hour_scroll + dx))
            elif self.drag_y is not None:
                self.scroll = max(0, min(self.max_scroll,
                                         self.drag_scroll + (self.drag_y - event.pos[1])))
        elif event.type == pygame.MOUSEWHEEL:
            # колесо над лентой часов — горизонтально
            if self.hour_rect and pygame.mouse.get_pos()[1] >= self.hour_rect.top and                     pygame.mouse.get_pos()[1] <= self.hour_rect.bottom:
                self.hour_scroll = max(0, min(self.hour_max,
                                              self.hour_scroll - event.y * 40))
            else:
                self.scroll = max(0, min(self.max_scroll, self.scroll - event.y * 36))
        elif event.type == pygame.KEYDOWN and self.editing:
            if event.key == pygame.K_BACKSPACE:
                self.city_input = self.city_input[:-1]
            elif event.key == pygame.K_RETURN:
                self.editing = False
                self.fetch()
            elif event.unicode and event.unicode.isprintable():
                self.city_input += event.unicode

    def update(self, dt):
        pass

    # ---------- draw helpers ----------
    def _gradient(self, surface, top, bottom):
        w, h = surface.get_size()
        key = (w, h, top, bottom)
        if self._bg is not None and self._bg_key == key:
            surface.blit(self._bg, (0, 0))
            return
        bg = pygame.Surface((w, h))
        for y in range(h):
            t = y / max(1, h - 1)
            col = (
                int(top[0] + (bottom[0] - top[0]) * t),
                int(top[1] + (bottom[1] - top[1]) * t),
                int(top[2] + (bottom[2] - top[2]) * t),
            )
            pygame.draw.line(bg, col, (0, y), (w, y))
        self._bg = bg
        self._bg_key = key
        surface.blit(bg, (0, 0))

    def _card(self, surface, rect, alpha=CARD_A):
        s = pygame.Surface((rect.w, rect.h), pygame.SRCALPHA)
        s.fill((255, 255, 255, alpha))
        surface.blit(s, rect.topleft)
        # тонкая обводка
        pygame.draw.rect(surface, (255, 255, 255, 40), rect, 1, border_radius=16)
        # скругление имитация: поверх углов не критично на мобиле
        pygame.draw.rect(surface, (255, 255, 255), rect, 1, border_radius=16)

    def draw(self, surface):
        w, h = surface.get_size()
        cur = (self.data or {}).get("current") or {}
        code = cur.get("weather_code", 0)
        is_day = cur.get("is_day", 1)
        top, bottom = sky_colors(code, is_day)
        self._gradient(surface, top, bottom)

        bold = self.app.font("ui", 18, bold=True)
        font = self.app.font("ui", 14)
        small = self.app.font("ui", 12)
        huge = self.app.font("ui", 64, bold=True)
        mid = self.app.font("ui", 22, bold=True)
        mono = self.app.font("mono", 13)

        # --- поиск города (как шапка ColorOS) ---
        search = pygame.Rect(16, 44, w - 156, 40)
        go = pygame.Rect(w - 132, 44, 56, 40)
        gps_btn = pygame.Rect(w - 70, 44, 54, 40)
        srf = pygame.Surface((search.w, search.h), pygame.SRCALPHA)
        srf.fill((255, 255, 255, 40))
        surface.blit(srf, search.topleft)
        pygame.draw.rect(surface, (255, 255, 255, 80), search, 1, border_radius=20)
        label = self.city_input if self.city_input else "Город…"
        surface.blit(font.render(label[:22], True, TEXT if self.city_input else DIM),
                     (search.x + 16, search.y + 10))
        gr = pygame.Surface((go.w, go.h), pygame.SRCALPHA)
        gr.fill((255, 255, 255, 50))
        surface.blit(gr, go.topleft)
        surface.blit(font.render("OK", True, TEXT), (go.x + 14, go.y + 10))
        gg = pygame.Surface((gps_btn.w, gps_btn.h), pygame.SRCALPHA)
        gg.fill((255, 255, 255, 55))
        surface.blit(gg, gps_btn.topleft)
        surface.blit(font.render("GPS", True, TEXT), (gps_btn.x + 8, gps_btn.y + 10))

        # сохранённые места + «+»
        self.place_rects = []
        px = 16
        py = 90
        for i, pl in enumerate(self.places[:8]):
            nm = str(pl.get("name") or pl.get("city") or "?")[:12]
            tw = small.size(nm)[0] + 20
            rr = pygame.Rect(px, py - self.scroll, tw, 28)
            active = (i == self.place_i)
            s = pygame.Surface((rr.w, rr.h), pygame.SRCALPHA)
            s.fill((255, 255, 255, 90 if active else 40))
            surface.blit(s, rr.topleft)
            surface.blit(small.render(nm, True, TEXT), (rr.x + 10, rr.y + 6))
            self.place_rects.append((rr, i))
            px += tw + 6
        add_r = pygame.Rect(px, py - self.scroll, 36, 28)
        s = pygame.Surface((add_r.w, add_r.h), pygame.SRCALPHA)
        s.fill((255, 255, 255, 50))
        surface.blit(s, add_r.topleft)
        surface.blit(small.render("+", True, TEXT), (add_r.x + 12, add_r.y + 6))
        self.place_rects.append((add_r, -1))

        y0 = 128 - self.scroll

        if self.loading:
            surface.blit(mid.render("Обновление…", True, TEXT), (24, y0 + 40))
            return
        if self.error:
            surface.blit(font.render(self.error, True, (255, 220, 220)), (24, y0 + 20))
            surface.blit(small.render("Проверьте сеть и название города", True, DIM),
                         (24, y0 + 48))
            return
        if not self.data:
            surface.blit(mid.render("Погода", True, TEXT), (24, y0 + 30))
            surface.blit(font.render("Введите город и нажмите OK", True, DIM),
                         (24, y0 + 70))
            # автозагрузка при первом открытии, если есть город
            if not getattr(self, "_auto", False):
                self._auto = True
                if self.city_input:
                    pl = None
                    if self.places and 0 <= self.place_i < len(self.places):
                        pl = self.places[self.place_i]
                    self.fetch(self.city_input, use_place=pl)
                else:
                    self.locate_here()
            return

        # --- главный блок (ColorOS: город + огромная температура) ---
        surface.blit(bold.render(self.place or self.city_input, True, TEXT), (24, y0))
        y = y0 + 36

        temp = cur.get("temperature_2m")
        feels = cur.get("apparent_temperature")
        desc = wmo_text(code)

        # большая иконка + температура
        icon_sz = 88
        blit_weather_icon(surface, code, (24, y), icon_sz, is_day, mid)
        surface.blit(huge.render(f"{temp:.0f}°" if temp is not None else "—", True, TEXT),
                     (24 + icon_sz + 12, y + 4))
        surface.blit(mid.render(desc, True, TEXT2), (24 + icon_sz + 12, y + 78))
        surface.blit(font.render(
            f"Ощущается как {feels:.0f}°" if feels is not None else "",
            True, DIM), (24 + icon_sz + 12, y + 108))
        y += max(150, icon_sz + 24)

        # --- детали в 2 колонки (карточки) ---
        items = [
            ("Влажность", f"{cur.get('relative_humidity_2m', '—')}%"),
            ("Ветер", f"{cur.get('wind_speed_10m', '—')} км/ч {wind_dir(cur.get('wind_direction_10m'))}"),
            ("Порывы", f"{cur.get('wind_gusts_10m', '—')} км/ч"),
            ("Давление", f"{cur.get('pressure_msl', '—')} гПа"),
            ("Облачность", f"{cur.get('cloud_cover', '—')}%"),
            ("Осадки", f"{cur.get('precipitation', 0)} мм"),
        ]
        gap = 10
        cw = (w - 48 - gap) // 2
        ch = 64
        for i, (title, val) in enumerate(items):
            col = i % 2
            row = i // 2
            rx = 16 + col * (cw + gap)
            ry = y + row * (ch + gap)
            self._card(surface, pygame.Rect(rx, ry, cw, ch), 45)
            surface.blit(small.render(title, True, DIM), (rx + 14, ry + 12))
            surface.blit(font.render(str(val), True, TEXT), (rx + 14, ry + 34))
        y += 3 * (ch + gap) + 8

        # --- по часам (горизонтальная лента ColorOS) ---
        surface.blit(bold.render("По часам", True, TEXT), (20, y))
        y += 30
        hourly = (self.data.get("hourly") or {})
        times = hourly.get("time") or []
        temps = hourly.get("temperature_2m") or []
        codes = hourly.get("weather_code") or []
        probs = hourly.get("precipitation_probability") or []
        n = min(24, len(times))
        card_w, card_h = 68, 118
        icon_sz = 28
        gap = 8
        total_w = n * (card_w + gap) - gap if n else 0
        view_w = w - 32
        self.hour_max = max(0, total_w - view_w)
        self.hour_scroll = max(0, min(self.hour_max, self.hour_scroll))
        strip = pygame.Surface((max(total_w, 1), card_h), pygame.SRCALPHA)
        for i in range(n):
            x = i * (card_w + gap)
            cell = pygame.Rect(x, 0, card_w, card_h)
            c = pygame.Surface((card_w, card_h), pygame.SRCALPHA)
            c.fill((255, 255, 255, 40))
            strip.blit(c, cell.topleft)
            hh = times[i][11:16] if len(times[i]) >= 16 else times[i]
            hs = small.render(hh, True, DIM)
            strip.blit(hs, (x + (card_w - hs.get_width()) // 2, 6))
            cc = codes[i] if i < len(codes) else 0
            ix = x + (card_w - icon_sz) // 2
            blit_weather_icon(strip, cc, (ix, 26), icon_sz, is_day, font)
            tval = temps[i] if i < len(temps) else 0
            ts = font.render(f"{tval:.0f}°", True, TEXT)
            strip.blit(ts, (x + (card_w - ts.get_width()) // 2, 26 + icon_sz + 4))
            pr = probs[i] if i < len(probs) else 0
            ps = small.render(f"{pr}%", True, DIM)
            strip.blit(ps, (x + (card_w - ps.get_width()) // 2, 26 + icon_sz + 26))
        # видимое окно с горизонтальным сдвигом
        self.hour_rect = pygame.Rect(16, y, view_w, card_h)
        view = pygame.Surface((view_w, card_h), pygame.SRCALPHA)
        view.blit(strip, (-int(self.hour_scroll), 0))
        surface.blit(view, (16, y))
        if self.hour_max > 0:
            surface.blit(small.render("< Двигай >", True, DIM),
                         (w - 90, y + card_h - 14))
        y += card_h + 20

        # --- 7 дней ---
        surface.blit(bold.render("На 7 дней", True, TEXT), (20, y))
        y += 28
        daily = self.data.get("daily") or {}
        days = daily.get("time") or []
        tmax = daily.get("temperature_2m_max") or []
        tmin = daily.get("temperature_2m_min") or []
        dcodes = daily.get("weather_code") or []
        dprob = daily.get("precipitation_probability_max") or []
        dprec = daily.get("precipitation_sum") or []
        dhum_max = daily.get("relative_humidity_2m_max") or []
        dhum_min = daily.get("relative_humidity_2m_min") or []
        dwind = daily.get("wind_speed_10m_max") or []
        sunr = daily.get("sunrise") or []
        suns = daily.get("sunset") or []

        for i, day in enumerate(days):
            try:
                d = date.fromisoformat(day)
                title = "Сегодня" if d == date.today() else WEEK_RU[d.weekday()]
                if d != date.today():
                    title = f"{title}, {d.day:02d}"
            except Exception:
                title = day

            row = pygame.Rect(16, y, w - 32, 96)
            self._card(surface, row, 40)
            surface.blit(font.render(title, True, TEXT), (row.x + 14, row.y + 8))
            dc = dcodes[i] if i < len(dcodes) else 0
            blit_weather_icon(surface, dc, (row.x + 14, row.y + 32), 36, 1, mid)
            surface.blit(small.render(wmo_text(dc), True, DIM),
                         (row.x + 56, row.y + 36))

            hi = tmax[i] if i < len(tmax) else 0
            lo = tmin[i] if i < len(tmin) else 0
            tr = mid.render(f"{hi:.0f}°", True, TEXT)
            surface.blit(tr, (row.right - 14 - tr.get_width(), row.y + 8))
            tr2 = font.render(f"{lo:.0f}°", True, DIM)
            surface.blit(tr2, (row.right - 14 - tr2.get_width(), row.y + 36))

            # всегда: осадки, влажность, ветер
            pr = dprob[i] if i < len(dprob) else 0
            ps = dprec[i] if i < len(dprec) else 0
            try:
                pr = int(pr or 0)
            except Exception:
                pr = 0
            try:
                ps = float(ps or 0)
            except Exception:
                ps = 0.0
            hm = dhum_max[i] if i < len(dhum_max) else None
            hl = dhum_min[i] if i < len(dhum_min) else None
            if hm is not None and hl is not None:
                hum_s = f"Влажность {hl:.0f}–{hm:.0f}%"
            elif hm is not None:
                hum_s = f"Влажность {hm:.0f}%"
            else:
                hum_s = "Влажность —"
            wind = dwind[i] if i < len(dwind) else None
            wind_s = f"Ветер {wind:.0f} км/ч" if wind is not None else ""
            surface.blit(small.render(
                f"Дождь {pr}% · {ps:.1f} мм", True, DIM),
                (row.x + 60, row.y + 56))
            surface.blit(small.render(hum_s, True, DIM),
                         (row.x + 56, row.y + 74))
            if wind_s:
                surface.blit(small.render(wind_s, True, DIM),
                             (row.x + 160, row.y + 74))

            if sunr and suns and i < len(sunr) and i < len(suns):
                sr = sunr[i][11:16] if len(str(sunr[i])) >= 16 else ""
                ss = suns[i][11:16] if len(str(suns[i])) >= 16 else ""
                if sr or ss:
                    surface.blit(small.render(f"Восход {sr} Закат {ss}", True, DIM),
                                 (row.right - 180, row.y + 56))
            y += 104

        y += 30
        self.max_scroll = max(0, y + self.scroll - (h - 70))
        if self.max_scroll > 0 and self.scroll < 8:
            surface.blit(small.render("свайп вверх — ещё", True, DIM), (24, h - 72))


def create_plugin(app):
    return WeatherPlugin(app)
