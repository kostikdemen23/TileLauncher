#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Плагин Tile Launcher (уровень лаунчера, НЕ subprocess).

Положи в TileLauncher/market/calc_plugin.py
Обязательно: def create_plugin(app)

Не вызывай pygame.display.set_mode — окно уже у лаунчера.
"""

PLUGIN_APP = True

import pygame

BG = (22, 25, 32)
BTN = (40, 48, 62)
BTN_OP = (0, 110, 190)
BTN_EQ = (50, 150, 90)
BTN_CLR = (170, 70, 70)
TEXT = (240, 245, 255)

KEYS = [
    ["C", "←", "%", "/"],
    ["7", "8", "9", "*"],
    ["4", "5", "6", "-"],
    ["1", "2", "3", "+"],
    ["±", "0", ".", "="],
]


class CalcPlugin:
    title = "Калькулятор"

    def __init__(self, app):
        self.app = app
        self.expr = ""
        self.display = "0"
        self.error = False
        self._btns = []

    def press(self, key: str) -> None:
        if self.error and key != "C":
            self.expr = ""
            self.display = "0"
            self.error = False
        if key == "C":
            self.expr = ""
            self.display = "0"
            self.error = False
        elif key == "←":
            self.expr = self.expr[:-1]
            self.display = self.expr or "0"
        elif key == "=":
            try:
                src = self.expr.replace("×", "*").replace("÷", "/")
                val = eval(src or "0", {"__builtins__": {}}, {})
                if isinstance(val, float) and val == int(val):
                    val = int(val)
                self.expr = str(val)
                self.display = self.expr
            except Exception:
                self.display = "Ошибка"
                self.error = True
                self.expr = ""
        elif key == "±":
            if self.expr.startswith("-"):
                self.expr = self.expr[1:]
            elif self.expr:
                self.expr = "-" + self.expr
            self.display = self.expr or "0"
        elif key == "%":
            try:
                val = float(eval(self.expr or "0", {"__builtins__": {}}, {})) / 100
                self.expr = str(val)
                self.display = self.expr
            except Exception:
                self.display = "Ошибка"
                self.error = True
        else:
            if self.display == "0" and key not in ".+-*/":
                self.expr = key
            else:
                self.expr += key
            self.display = self.expr

    def handle_event(self, event):
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            for rect, key in self._btns:
                if rect.collidepoint(event.pos):
                    self.press(key)
                    return

    def update(self, dt):
        pass

    def draw(self, surface):
        w, h = surface.get_size()
        surface.fill(BG)
        # дисплей
        pygame.draw.rect(surface, (30, 34, 44),
                         pygame.Rect(10, 50, w - 20, 70), border_radius=12)
        font = self.app.font("mono", 26, bold=True)
        disp = self.display
        if len(disp) > 14:
            disp = "…" + disp[-13:]
        ts = font.render(disp, True, TEXT)
        surface.blit(ts, (w - 24 - ts.get_width(), 70))

        top = 140
        margin, gap = 10, 8
        rows, cols = 5, 4
        bw = (w - 2 * margin - (cols - 1) * gap) // cols
        bh = min(64, (h - top - 70 - (rows - 1) * gap) // rows)
        self._btns = []
        for r, row in enumerate(KEYS):
            for c, key in enumerate(row):
                x = margin + c * (bw + gap)
                y = top + r * (bh + gap)
                rect = pygame.Rect(x, y, bw, bh)
                self._btns.append((rect, key))
                if key == "C":
                    col = BTN_CLR
                elif key == "=":
                    col = BTN_EQ
                elif key in "+-*/%":
                    col = BTN_OP
                else:
                    col = BTN
                pygame.draw.rect(surface, col, rect, border_radius=10)
                lab = self.app.font("ui", 20, bold=True).render(key, True, TEXT)
                surface.blit(lab, lab.get_rect(center=rect.center))


def create_plugin(app):
    """Точка входа для Tile Launcher."""
    return CalcPlugin(app)
